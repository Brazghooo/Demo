export type UserRole = 'Admin' | 'User';

export interface Branch {
  id: string;
  name: string;
  location: string;
  code: string;
  createdDate: string;
}

export interface User {
  id: string;
  name: string;
  position: string;
  branch: string; // branch name or ID
  email: string;
  phone: string;
  password?: string;
  role: UserRole;
  permissions: string[];
  activeStatus: 'Active' | 'Inactive';
  createdDate: string;
  lastActive?: string;
}

export interface SheetLink {
  id: string;
  title: string;
  url: string;
  addedBy: string;
  addedDate: string;
  lastUpdated: string;
  recordCount: number;
  branchName?: string;
}

export interface FinancialRecord {
  id: string;
  date: string;
  borrowerName: string;
  branchName: string;
  amountDisbursed: number;
  expectedRepayment: number;
  actualRepayment: number;
  interestRate: number; // in percent
  expenses: number;
  status: 'On Time' | 'Delayed' | 'Default';
  uploadedBy: string;
  sheetSourceId?: string;
  bankedAmount?: number;
  remainingCash?: number;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  assignedToEmail: string;
  assignedToName: string;
  assignedTo?: string; // custom lookup display name
  priority?: 'High' | 'Medium' | 'Low';
  assignedBy: string;
  status: 'Pending' | 'In Progress' | 'Completed';
  progress: number; // 0 to 100
  dueDate: string;
  createdDate: string;
  activityLog: {
    timestamp: string;
    note: string;
    author: string;
  }[];
}

export interface AlertNotification {
  id: string;
  title: string;
  description: string;
  type: 'loss' | 'default' | 'expense' | 'system' | 'general';
  severity: 'Critical' | 'Warning' | 'Info';
  timestamp: string;
  isRead: boolean;
  branchName?: string;
}

export interface CommunicationMessage {
  id: string;
  senderEmail: string;
  senderName: string;
  senderRole?: string; // officer designation
  recipientEmail: string; // "All" or user email
  recipientName: string;
  message: string;
  channel?: string; // selected regional channel
  timestamp: string;
}

export interface AuditLog {
  id: string;
  userEmail: string;
  userName: string;
  role?: string; // security visibility role
  action: string;
  timestamp: string;
  ipAddress?: string;
}

export interface FinanceSubmissionTemplate {
  id: string;
  title: string;
  instructions: string;
  requiredColumns: string[]; 
  targetInterestRate: number; 
  maxDisbursedAmount: number; 
  updatedAt: string;
  createdBy: string;
}

export interface LoanAttachment {
  id: string;
  name: string;
  date: string;
  borrowerName: string;
  details: string;
  fileType: string;
  fileSize: string;
  fileData: string; // base64 encoded
  uploadedBy: string;
  createdAt: string;
  branchName?: string;
}
