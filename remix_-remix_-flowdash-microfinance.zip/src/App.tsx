import React, { useState, useEffect } from 'react';
import {
  INITIAL_BRANCHES,
  INITIAL_USERS,
  INITIAL_SHEET_LINKS,
  INITIAL_RECORDS,
  INITIAL_TASKS,
  INITIAL_ALERTS,
  INITIAL_COMMUNICATIONS,
  INITIAL_AUDITS
} from './mockData';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import LoginScreen from './components/LoginScreen';
import DashboardOverview from './components/DashboardOverview';
import SheetsAnalyzer from './components/SheetsAnalyzer';
import BranchesManager from './components/BranchesManager';
import DutiesTasks from './components/DutiesTasks';
import TeamComms from './components/TeamComms';
import SecurityAudits from './components/SecurityAudits';
import SystemSettings from './components/SystemSettings';
import { User, Branch, SheetLink, FinancialRecord, Task, AlertNotification, CommunicationMessage, AuditLog, FinanceSubmissionTemplate, LoanAttachment } from './types';
import { 
  collection, 
  onSnapshot, 
  setDoc, 
  doc, 
  deleteDoc, 
  getDocs,
  getDocFromServer
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './firebase';

// Metadata capability tag
const MAJOR_CAPABILITY_SERVER_SIDE_GEMINI_API = true;

export default function App() {
  // Session Access
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const cached = localStorage.getItem('flowdash_current_user');
    return cached ? JSON.parse(cached) : null;
  });

  const [firebaseAuthReady] = useState(true);

  const [currentTab, setCurrentTab] = useState<string>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState<boolean>(false);
  const [currentFilterBranch, setCurrentFilterBranch] = useState<string>('All');

  // Core Data Registries
  const [branches, setBranches] = useState<Branch[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [sheetLinks, setSheetLinks] = useState<SheetLink[]>([]);
  const [records, setRecords] = useState<FinancialRecord[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [alerts, setAlerts] = useState<AlertNotification[]>([]);
  const [messages, setMessages] = useState<CommunicationMessage[]>([]);
  const [audits, setAudits] = useState<AuditLog[]>([]);
  const [activeTemplate, setActiveTemplate] = useState<FinanceSubmissionTemplate | null>(null);

  const [darkMode, setDarkMode] = useState<boolean>(() => {
    const cached = localStorage.getItem('flowdash_dark_mode');
    return cached === 'true';
  });

  const [manualFlows, setManualFlows] = useState<Record<string, { openingCash: number; bankedAmount: number }>>({});
  const [loanAttachments, setLoanAttachments] = useState<LoanAttachment[]>([]);

  useEffect(() => {
    localStorage.setItem('pacific_finance_cash_flows', JSON.stringify(manualFlows));
  }, [manualFlows]);

  const handleSetManualFlows: React.Dispatch<
    React.SetStateAction<Record<string, { openingCash: number; bankedAmount: number }>>
  > = async (value) => {
    let nextValue: Record<string, { openingCash: number; bankedAmount: number }> = {};
    if (typeof value === 'function') {
      nextValue = value(manualFlows);
    } else {
      nextValue = value;
    }

    // Sync any edits or creations to Firestore manualFlows collection
    for (const [key, val] of Object.entries(nextValue)) {
      const prev = manualFlows[key];
      if (!prev || prev.openingCash !== val.openingCash || prev.bankedAmount !== val.bankedAmount) {
        try {
          await setDoc(doc(db, 'manualFlows', key), {
            openingCash: val.openingCash,
            bankedAmount: val.bankedAmount
          });
        } catch (err) {
          handleFirestoreError(err, OperationType.WRITE, `manualFlows/${key}`);
        }
      }
    }

    // Capture deletions and delete from Firestore
    for (const key of Object.keys(manualFlows)) {
      if (!(key in nextValue)) {
        try {
          await deleteDoc(doc(db, 'manualFlows', key));
        } catch (err) {
          handleFirestoreError(err, OperationType.DELETE, `manualFlows/${key}`);
        }
      }
    }

    // Let state update immediately so inputs feel fast
    setManualFlows(nextValue);
  };

  // Test Server Connection
  useEffect(() => {
    async function testConnection() {
      try {
        await getDocFromServer(doc(db, 'test', 'connection'));
      } catch (error) {
        if (error instanceof Error && error.message.includes('the client is offline')) {
          console.error("Please check your Firebase configuration.");
        }
      }
    }
    testConnection();
  }, []);

  // Sync state loops to LocalStorage and Class styling for darkMode
  useEffect(() => {
    localStorage.setItem('flowdash_dark_mode', String(darkMode));
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  useEffect(() => {
    localStorage.setItem('flowdash_current_user', currentUser ? JSON.stringify(currentUser) : '');
  }, [currentUser]);

  // Unified real-time Firestore synchronization sync loops with no auto-bootstrapping
  useEffect(() => {
    if (!firebaseAuthReady) return;
    const unsubscribe = onSnapshot(collection(db, 'branches'), (snapshot) => {
      const list: Branch[] = [];
      snapshot.forEach((doc) => {
        list.push(doc.data() as Branch);
      });
      setBranches(list);
    }, (err) => {
      handleFirestoreError(err, OperationType.GET, 'branches');
    });
    return unsubscribe;
  }, [firebaseAuthReady]);

  useEffect(() => {
    if (!firebaseAuthReady) return;
    const unsubscribe = onSnapshot(collection(db, 'users'), (snapshot) => {
      const list: User[] = [];
      snapshot.forEach((doc) => {
        list.push(doc.data() as User);
      });
      setUsers(list);
    }, (err) => {
      handleFirestoreError(err, OperationType.GET, 'users');
    });
    return unsubscribe;
  }, [firebaseAuthReady]);

  useEffect(() => {
    if (!firebaseAuthReady || !currentUser) return;
    const unsubscribe = onSnapshot(collection(db, 'sheetLinks'), (snapshot) => {
      const list: SheetLink[] = [];
      snapshot.forEach((doc) => {
        list.push(doc.data() as SheetLink);
      });
      setSheetLinks(list);
    }, (err) => {
      handleFirestoreError(err, OperationType.GET, 'sheetLinks');
    });
    return unsubscribe;
  }, [firebaseAuthReady, currentUser]);

  useEffect(() => {
    if (!firebaseAuthReady || !currentUser) return;
    const unsubscribe = onSnapshot(collection(db, 'records'), (snapshot) => {
      const list: FinancialRecord[] = [];
      snapshot.forEach((doc) => {
        list.push(doc.data() as FinancialRecord);
      });
      // Sort by date descending
      list.sort((a, b) => b.date.localeCompare(a.date));
      setRecords(list);
    }, (err) => {
      handleFirestoreError(err, OperationType.GET, 'records');
    });
    return unsubscribe;
  }, [firebaseAuthReady, currentUser]);

  useEffect(() => {
    if (!firebaseAuthReady || !currentUser) return;
    const unsubscribe = onSnapshot(collection(db, 'tasks'), (snapshot) => {
      const list: Task[] = [];
      snapshot.forEach((doc) => {
        list.push(doc.data() as Task);
      });
      setTasks(list);
    }, (err) => {
      handleFirestoreError(err, OperationType.GET, 'tasks');
    });
    return unsubscribe;
  }, [firebaseAuthReady, currentUser]);

  useEffect(() => {
    if (!firebaseAuthReady || !currentUser) return;
    const unsubscribe = onSnapshot(collection(db, 'alerts'), (snapshot) => {
      const list: AlertNotification[] = [];
      snapshot.forEach((doc) => {
        list.push(doc.data() as AlertNotification);
      });
      setAlerts(list);
    }, (err) => {
      handleFirestoreError(err, OperationType.GET, 'alerts');
    });
    return unsubscribe;
  }, [firebaseAuthReady, currentUser]);

  useEffect(() => {
    if (!firebaseAuthReady || !currentUser) return;
    const unsubscribe = onSnapshot(collection(db, 'messages'), (snapshot) => {
      const list: CommunicationMessage[] = [];
      snapshot.forEach((doc) => {
        list.push(doc.data() as CommunicationMessage);
      });
      list.sort((a, b) => a.timestamp.localeCompare(b.timestamp));
      setMessages(list);
    }, (err) => {
      handleFirestoreError(err, OperationType.GET, 'messages');
    });
    return unsubscribe;
  }, [firebaseAuthReady, currentUser]);

  useEffect(() => {
    if (!firebaseAuthReady || !currentUser || currentUser.role !== 'Admin') return;
    const unsubscribe = onSnapshot(collection(db, 'audits'), (snapshot) => {
      const list: AuditLog[] = [];
      snapshot.forEach((doc) => {
        list.push(doc.data() as AuditLog);
      });
      list.sort((a, b) => b.timestamp.localeCompare(a.timestamp));
      setAudits(list);
    }, (err) => {
      handleFirestoreError(err, OperationType.GET, 'audits');
    });
    return unsubscribe;
  }, [firebaseAuthReady, currentUser]);

  useEffect(() => {
    if (!firebaseAuthReady || !currentUser) return;
    const unsubscribe = onSnapshot(doc(db, 'templates', 'active_finance'), (docSnap) => {
      if (docSnap.exists()) {
        setActiveTemplate(docSnap.data() as FinanceSubmissionTemplate);
      } else {
        const defaultTemplate: FinanceSubmissionTemplate = {
          id: 'active_finance',
          title: 'Malawi Microfinance Standard Ledger Submission Template',
          instructions: 'Please ensure borrower name is fully specified. Do not exceed the standard cap rate of 15% interest. Align columns meticulously.',
          requiredColumns: ['Borrower', 'Disbursed', 'Expected', 'Received', 'Status', 'Expenses'],
          targetInterestRate: 15,
          maxDisbursedAmount: 10000,
          updatedAt: new Date().toISOString(),
          createdBy: 'mchagunda@microfinance.mw'
        };
        setDoc(doc(db, 'templates', 'active_finance'), defaultTemplate).catch(err => {
          console.error("Default template write failed in sync loop: ", err);
        });
      }
    }, (err) => {
      console.warn("Unable to fetch template or permission denied in sync: ", err);
    });
    return unsubscribe;
  }, [firebaseAuthReady, currentUser]);

  useEffect(() => {
    if (!firebaseAuthReady || !currentUser) return;
    const unsubscribe = onSnapshot(collection(db, 'manualFlows'), (snapshot) => {
      const data: Record<string, { openingCash: number; bankedAmount: number }> = {};
      snapshot.forEach((doc) => {
        const item = doc.data();
        data[doc.id] = {
          openingCash: Number(item.openingCash) || 0,
          bankedAmount: Number(item.bankedAmount) || 0
        };
      });
      setManualFlows(data);
    }, (err) => {
      handleFirestoreError(err, OperationType.GET, 'manualFlows');
    });
    return unsubscribe;
  }, [firebaseAuthReady, currentUser]);

  useEffect(() => {
    if (!firebaseAuthReady || !currentUser) return;
    const unsubscribe = onSnapshot(collection(db, 'loanAttachments'), (snapshot) => {
      const list: LoanAttachment[] = [];
      snapshot.forEach((doc) => {
        list.push(doc.data() as LoanAttachment);
      });
      // Sort by createdAt descending
      list.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
      setLoanAttachments(list);
    }, (err) => {
      handleFirestoreError(err, OperationType.GET, 'loanAttachments');
    });
    return unsubscribe;
  }, [firebaseAuthReady, currentUser]);

  // Global action audit logging handler
  const handleRunAuditLog = async (action: string) => {
    if (!currentUser) return;
    const freshLog: AuditLog = {
      id: `aud-${Math.floor(1000 + Math.random() * 9000)}`,
      userEmail: currentUser.email,
      userName: currentUser.name,
      action,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19).concat(' UTC'),
      ipAddress: '197.221.' + Math.floor(10 + Math.random() * 80) + '.' + Math.floor(1 + Math.random() * 250)
    };
    
    try {
      await setDoc(doc(db, 'audits', freshLog.id), freshLog);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `audits/${freshLog.id}`);
    }

    // Check if new action creates any systemic alarms automatically!
    if (action.toLowerCase().includes('sheet') || action.toLowerCase().includes('disburs')) {
      const freshAlert: AlertNotification = {
        id: `alt-${Math.floor(100 + Math.random() * 900)}`,
        title: 'System Activity Logged',
        description: `${currentUser.name} performed operational ledger adjustment: "${action}"`,
        type: 'system',
        severity: 'Info',
        timestamp: new Date().toISOString().substring(11, 16),
        isRead: false,
        branchName: currentUser.branch
      };
      
      try {
        await setDoc(doc(db, 'alerts', freshAlert.id), freshAlert);
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, `alerts/${freshAlert.id}`);
      }
    }
  };

  // Login handler
  const handleLoginSuccess = async (verifiedUser: User) => {
    setCurrentUser(verifiedUser);
    setCurrentTab('dashboard');
    
    // Log login audit
    const freshLog: AuditLog = {
      id: `aud-login-${Math.floor(100 + Math.random() * 900)}`,
      userEmail: verifiedUser.email,
      userName: verifiedUser.name,
      action: `Officer session opened at physical branch: ${verifiedUser.branch}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19).concat(' UTC'),
      ipAddress: '197.221.' + Math.floor(30 + Math.random() * 60) + '.45'
    };

    try {
      await setDoc(doc(db, 'audits', freshLog.id), freshLog);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `audits/${freshLog.id}`);
    }
  };

  const handleLogout = () => {
    if (currentUser) {
      handleRunAuditLog('Active session logged out.');
    }
    setCurrentUser(null);
    setCurrentTab('dashboard');
  };

  const handleRegisterUser = async (newUser: User) => {
    try {
      await setDoc(doc(db, 'users', newUser.id), newUser);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `users/${newUser.id}`);
    }
  };

  // Sheet handlers
  const handleAddSheetLink = async (title: string, url: string) => {
    const freshLink: SheetLink = {
      id: `s-${Math.floor(100 + Math.random() * 900)}`,
      title,
      url,
      addedBy: currentUser?.email || 'officer@microfinance.mw',
      addedDate: new Date().toISOString().split('T')[0],
      lastUpdated: new Date().toISOString().replace('T', ' ').substring(0, 16),
      recordCount: 4
    };

    try {
      await setDoc(doc(db, 'sheetLinks', freshLink.id), freshLink);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `sheetLinks/${freshLink.id}`);
    }
  };

  const handleRemoveSheetLink = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'sheetLinks', id));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `sheetLinks/${id}`);
    }
  };

  const handleUpdateSheetLink = async (updated: SheetLink) => {
    try {
      await setDoc(doc(db, 'sheetLinks', updated.id), updated);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `sheetLinks/${updated.id}`);
    }
  };

  const handleAddLoanAttachment = async (attachment: LoanAttachment) => {
    try {
      await setDoc(doc(db, 'loanAttachments', attachment.id), attachment);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `loanAttachments/${attachment.id}`);
    }
  };

  const handleDeleteLoanAttachment = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'loanAttachments', id));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `loanAttachments/${id}`);
    }
  };

  // Add parsed or seed records
  const handleAddRecords = async (newRecs: FinancialRecord[]) => {
    for (const rec of newRecs) {
      try {
        await setDoc(doc(db, 'records', rec.id), rec);
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, `records/${rec.id}`);
      }
    }

    // Automatically trigger high overhead warning alert if any seeded expense exceeds $350
    const expensive = newRecs.find(r => r.expenses > 350);
    if (expensive) {
      const overloadAlert: AlertNotification = {
        id: `alt-exp-${Math.floor(100 + Math.random() * 900)}`,
        title: 'Extreme Operating Expense logged',
        description: `Overhead fee MWK ${expensive.expenses} reported under account ${expensive.borrowerName} at ${expensive.branchName}.`,
        type: 'expense',
        severity: 'Warning',
        timestamp: new Date().toISOString().substring(11, 16),
        isRead: false,
        branchName: expensive.branchName
      };

      try {
        await setDoc(doc(db, 'alerts', overloadAlert.id), overloadAlert);
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, `alerts/${overloadAlert.id}`);
      }
    }
  };

  const handleDeleteRecord = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'records', id));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `records/${id}`);
    }
  };

  const handleUpdateRecord = async (updated: FinancialRecord) => {
    try {
      await setDoc(doc(db, 'records', updated.id), updated);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `records/${updated.id}`);
    }
  };

  // Branch creation
  const handleAddBranch = async (newBranch: Branch) => {
    try {
      await setDoc(doc(db, 'branches', newBranch.id), newBranch);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `branches/${newBranch.id}`);
    }
  };

  // Task Handlers
  const handleAddTask = async (newTask: Task) => {
    try {
      await setDoc(doc(db, 'tasks', newTask.id), newTask);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `tasks/${newTask.id}`);
    }
  };

  const handleUpdateTaskStatus = async (taskId: string, status: Task['status']) => {
    const taskToUpdate = tasks.find(t => t.id === taskId);
    if (taskToUpdate) {
      const updated = {
        ...taskToUpdate,
        status,
        progress: status === 'Completed' ? 100 : status === 'In Progress' ? 50 : 0
      };
      try {
        await setDoc(doc(db, 'tasks', taskId), updated);
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, `tasks/${taskId}`);
      }
    }
  };

  const handleDeleteTask = async (taskId: string) => {
    try {
      await deleteDoc(doc(db, 'tasks', taskId));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `tasks/${taskId}`);
    }
  };

  // Communication memos sender with flexible recipient targeting
  const handleSendMessage = async (
    senderName: string, 
    senderRole: string, 
    content: string, 
    channel: string,
    recipientEmail = 'All',
    recipientName = 'All Staff Office'
  ) => {
    const freshMemo: CommunicationMessage = {
      id: `memo-${Math.floor(1000 + Math.random() * 9000)}`,
      senderEmail: currentUser?.email || 'officer@microfinance.mw',
      senderName,
      senderRole,
      recipientEmail,
      recipientName,
      message: content,
      channel,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16)
    };

    try {
      await setDoc(doc(db, 'messages', freshMemo.id), freshMemo);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `messages/${freshMemo.id}`);
    }
  };

  // Branch CRUD operations
  const handleDeleteBranch = async (branchId: string) => {
    try {
      await deleteDoc(doc(db, 'branches', branchId));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `branches/${branchId}`);
    }
  };

  const handleUpdateBranch = async (updatedBranch: Branch) => {
    try {
      await setDoc(doc(db, 'branches', updatedBranch.id), updatedBranch);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `branches/${updatedBranch.id}`);
    }
  };

  // User Staff actions
  const handleDeleteUser = async (userId: string) => {
    try {
      await deleteDoc(doc(db, 'users', userId));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `users/${userId}`);
    }
  };

  const handleUpdateUser = async (updatedUser: User) => {
    try {
      await setDoc(doc(db, 'users', updatedUser.id), updatedUser);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `users/${updatedUser.id}`);
    }
  };

  // Alerts/Alarms actions
  const handleDeleteAlert = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'alerts', id));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `alerts/${id}`);
    }
  };

  const handleCreateAlert = async (newAlert: AlertNotification) => {
    try {
      await setDoc(doc(db, 'alerts', newAlert.id), newAlert);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `alerts/${newAlert.id}`);
    }
  };

  const handleUpdateAlert = async (updatedAlert: AlertNotification) => {
    try {
      await setDoc(doc(db, 'alerts', updatedAlert.id), updatedAlert);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `alerts/${updatedAlert.id}`);
    }
  };

  const handleUpdateActiveTemplate = async (template: FinanceSubmissionTemplate) => {
    try {
      await setDoc(doc(db, 'templates', 'active_finance'), template);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'templates/active_finance');
    }
  };

  // Clear alarms read
  const handleMarkNotificationRead = async (id: string) => {
    const alertToUpdate = alerts.find(a => a.id === id);
    if (alertToUpdate) {
      try {
        await setDoc(doc(db, 'alerts', id), { ...alertToUpdate, isRead: true });
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, `alerts/${id}`);
      }
    }
  };

  // RBAC permissions updates
  const handleUpdateUserRoleAndPermissions = async (userId: string, role: User['role'], permissions: string[]) => {
    const userToUpdate = users.find(u => u.id === userId);
    if (userToUpdate) {
      const updated = {
        ...userToUpdate,
        role,
        permissions
      };
      try {
        await setDoc(doc(db, 'users', userId), updated);
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, `users/${userId}`);
      }
    }
  };

  // Hard clear restore seeds
  const handleClearDatabase = async () => {
    const collectionsToReset = ['sheetLinks', 'records', 'tasks', 'alerts', 'messages', 'audits', 'branches', 'users', 'manualFlows'];
    for (const colName of collectionsToReset) {
      try {
        const snap = await getDocs(collection(db, colName));
        for (const docItem of snap.docs) {
          try {
            await deleteDoc(doc(db, colName, docItem.id));
          } catch (err) {}
        }
      } catch (err) {}
    }
  };


  // Render the selected tab
  const renderSelectedTab = () => {
    switch (currentTab) {
      case 'dashboard':
        return (
          <DashboardOverview
            records={records}
            users={users}
            alerts={alerts}
            audits={audits}
            branches={branches}
            currentUser={currentUser}
            currentFilterBranch={currentFilterBranch}
            setCurrentFilterBranch={setCurrentFilterBranch}
            onNavigateToTab={setCurrentTab}
            onUpdateRecord={handleUpdateRecord}
            onDeleteRecord={handleDeleteRecord}
            onRunAuditLog={handleRunAuditLog}
            manualFlows={manualFlows}
            setManualFlows={handleSetManualFlows}
          />
        );
      case 'sheet-analyzer':
        return (
          <SheetsAnalyzer
            sheetLinks={sheetLinks}
            onAddSheetLink={handleAddSheetLink}
            onRemoveSheetLink={handleRemoveSheetLink}
            onUpdateSheetLink={handleUpdateSheetLink}
            records={records}
            onAddRecords={handleAddRecords}
            onDeleteRecord={handleDeleteRecord}
            onUpdateRecord={handleUpdateRecord}
            currentUser={currentUser}
            onRunAuditLog={handleRunAuditLog}
            activeTemplate={activeTemplate}
            onUpdateActiveTemplate={handleUpdateActiveTemplate}
            manualFlows={manualFlows}
            setManualFlows={handleSetManualFlows}
            branches={branches}
            loanAttachments={loanAttachments}
            onAddLoanAttachment={handleAddLoanAttachment}
            onDeleteLoanAttachment={handleDeleteLoanAttachment}
          />
        );
      case 'branches-staff':
        return (
          <BranchesManager
            branches={branches}
            onAddBranch={handleAddBranch}
            onDeleteBranch={handleDeleteBranch}
            onUpdateBranch={handleUpdateBranch}
            users={users}
            onUpdateUserRoleAndPermissions={handleUpdateUserRoleAndPermissions}
            onDeleteUser={handleDeleteUser}
            onUpdateUser={handleUpdateUser}
            currentUser={currentUser}
            onRunAuditLog={handleRunAuditLog}
          />
        );
      case 'task-board':
        return (
          <DutiesTasks
            tasks={tasks}
            onAddTask={handleAddTask}
            onUpdateTaskStatus={handleUpdateTaskStatus}
            onDeleteTask={handleDeleteTask}
            users={users}
            currentUser={currentUser}
            onRunAuditLog={handleRunAuditLog}
          />
        );
      case 'communications':
        return (
          <TeamComms
            messages={messages}
            onSendMessage={handleSendMessage}
            currentUser={currentUser}
            onRunAuditLog={handleRunAuditLog}
            users={users}
            branches={branches}
          />
        );
      case 'security-audits':
        return (
          <SecurityAudits
            audits={audits}
            onClearAudits={() => setAudits([])}
            currentUser={currentUser}
          />
        );
      case 'system-settings':
        return (
          <SystemSettings
            currentUser={currentUser}
            branches={branches}
            alerts={alerts}
            onDeleteAlert={handleDeleteAlert}
            onCreateAlert={handleCreateAlert}
            onUpdateAlert={handleUpdateAlert}
            activeTemplate={activeTemplate}
            onUpdateActiveTemplate={handleUpdateActiveTemplate}
            onAddRecords={handleAddRecords}
            onClearDatabase={handleClearDatabase}
            onRunAuditLog={handleRunAuditLog}
          />
        );
      default:
        return (
          <div className="py-20 text-center text-gray-400">
            <p className="text-sm font-bold">Workspace frame not initialized.</p>
          </div>
        );
    }
  };

  // Check login stage
  if (!currentUser) {
    return (
      <LoginScreen
        onLoginSuccess={handleLoginSuccess}
        branches={branches}
        users={users}
        onRegisterUser={handleRegisterUser}
      />
    );
  }

  const unreadAlertCount = alerts.filter(a => !a.isRead).length;

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-700 antialiased selection:bg-blue-600 selection:text-white flex print:bg-white print:text-black">
      {/* Physical Regional Sidebar */}
      <Sidebar
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        isOpen={sidebarOpen}
        setIsOpen={setSidebarOpen}
        currentUser={currentUser}
        onLogout={handleLogout}
        unreadAlertCount={unreadAlertCount}
      />

      {/* Main body viewport */}
      <div className="lg:pl-68 flex-1 flex flex-col min-h-screen min-w-0">
        <Header
          onMenuToggle={() => setSidebarOpen(!sidebarOpen)}
          currentUser={currentUser}
          alerts={alerts}
          onMarkNotificationRead={handleMarkNotificationRead}
          onNavigateToTab={setCurrentTab}
          onLogout={handleLogout}
          darkMode={darkMode}
          onToggleDarkMode={() => setDarkMode(prev => !prev)}
        />

        <main className="flex-1 p-6 max-w-[1600px] 2xl:max-w-[1800px] xl:px-8 mx-auto w-full space-y-6 print:p-0">
          {renderSelectedTab()}
        </main>

        <footer className="mt-auto px-6 py-4 border-t border-gray-200/60 bg-white text-center text-[11px] text-gray-400 font-mono select-none print:hidden flex justify-between items-center">
          <span>&copy; 2026 Pacific Finance LTD. Security Audit sequences compliant under statutory act FIS-304.</span>
          <span className="text-[10px] text-blue-500 font-bold uppercase tracking-wider">Secure Audit Active</span>
        </footer>
      </div>
    </div>
  );
}
