import React from 'react';
import { ShieldCheck, Lock, EyeOff, KeyRound, Terminal, Trash2, CheckCircle2, Server, HelpCircle, Activity } from 'lucide-react';
import { AuditLog, User } from '../types';

interface SecurityAuditsProps {
  audits: AuditLog[];
  onClearAudits: () => void;
  currentUser: User | null;
}

export default function SecurityAudits({
  audits,
  onClearAudits,
  currentUser
}: SecurityAuditsProps) {
  const isAdmin = currentUser?.role === 'Admin';

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold font-sans text-gray-950 tracking-tight">Data Integrity & Security Auditing Logs</h1>
          <p className="text-xs text-gray-400 font-medium">Verify security protocol sequences, watch officer access trails, and monitor legal compliance statuses actively</p>
        </div>

        {isAdmin && audits.length > 0 && (
          <button
            onClick={() => {
              if (window.confirm('Are you absolutely sure you want to hard delete all historical security logs? This is irreversible.')) {
                onClearAudits();
              }
            }}
            className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-red-200 bg-red-50 px-3 text-xs font-bold text-red-700 hover:bg-red-100"
          >
            <Trash2 className="h-3.5 w-3.5" />
            <span>Purge Vault Logs</span>
          </button>
        )}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Left: Security protocols checklist */}
        <div className="space-y-6 lg:col-span-1">
          <div className="rounded-xl border border-gray-200 bg-slate-900 p-5 text-slate-100 relative overflow-hidden">
            {/* Ambient terminal shine */}
            <div className="absolute top-0 right-0 w-48 h-48 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />

            <h3 className="text-xs font-bold font-mono tracking-wider text-emerald-450 text-emerald-400 uppercase mb-3 flex items-center gap-2">
              <ShieldCheck className="h-4.5 w-4.5" />
              <span>ACTIVE VAULT PROTECTION</span>
            </h3>

            <div className="space-y-3.5 pt-1.5 text-xs font-mono font-medium">
              <div className="flex justify-between items-center bg-slate-950/40 p-2.5 rounded border border-slate-800">
                <span className="flex items-center gap-1.5 text-slate-400">
                  <Lock className="h-3.5 w-3.5 text-emerald-400" />
                  SQL Injection Shield
                </span>
                <span className="text-[10px] text-emerald-400 font-bold bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-900">SECURE</span>
              </div>

              <div className="flex justify-between items-center bg-slate-950/40 p-2.5 rounded border border-slate-800">
                <span className="flex items-center gap-1.5 text-slate-400">
                  <EyeOff className="h-3.5 w-3.5 text-indigo-400" />
                  Client Credential Hash
                </span>
                <span className="text-[10px] text-indigo-400 font-bold bg-indigo-950/60 px-2 py-0.5 rounded border border-indigo-900 font-bold">SHA-256</span>
              </div>

              <div className="flex justify-between items-center bg-slate-950/40 p-2.5 rounded border border-slate-800">
                <span className="flex items-center gap-1.5 text-slate-400">
                  <KeyRound className="h-3.5 w-3.5 text-amber-400" />
                  RBAC Filtration Code
                </span>
                <span className="text-[10px] text-amber-400 font-bold bg-amber-950/60 px-2 py-0.5 rounded border border-amber-900">STRICT</span>
              </div>

              <div className="flex justify-between items-center bg-slate-950/40 p-2.5 rounded border border-slate-800">
                <span className="flex items-center gap-1.5 text-slate-400">
                  <Server className="h-3.5 w-3.5 text-sky-450 text-sky-450 text-blue-400" />
                  Cloud Run Secure Server
                </span>
                <span className="text-[10px] text-blue-400 font-bold bg-blue-950/60 px-2 py-0.5 rounded border border-blue-900">TLS 1.3</span>
              </div>
            </div>

            <p className="mt-5 text-[10px] leading-relaxed text-slate-400 font-sans">
              *Pacific Finance adheres to the Malawi Banking Act FIS-304. Access to reports, ledger logs, and analytics metrics is strictly audited for protection against institutional leakages.
            </p>
          </div>

          <div className="rounded-xl border border-gray-200 bg-white p-5 shadow-sm space-y-3">
            <h4 className="text-xs font-bold text-gray-800 uppercase tracking-wider flex items-center gap-1.5">
              <Activity className="h-4.5 w-4.5 text-blue-500" />
              <span>Session Surveillance Rules</span>
            </h4>
            <p className="text-[11px] text-gray-400 leading-normal">
              Any actions like connecting google sheets, updating task markers, or updating worker privileges trigger automatic log stamps matching user emails.
            </p>
            <div className="p-3 bg-gray-50 rounded-lg text-xs leading-normal font-sans text-slate-650 font-medium">
              If an anomaly is spotted during syncing (such as column misalignment inside custom sheets), an automated alarm is issued to the dashboard immediately.
            </div>
          </div>
        </div>

        {/* Right: Security audits shell console logs list */}
        <div className="space-y-4 lg:col-span-2">
          <div className="rounded-xl border border-gray-200 bg-slate-950 p-5 shadow-md relative h-132 flex flex-col justify-start">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4 shrink-0">
              <span className="text-xs font-mono font-bold text-slate-200 flex items-center gap-2">
                <Terminal className="h-4.5 w-4.5 text-emerald-400 animate-pulse" />
                SECURE SECURITY JOURNAL STREAM (SYS_LOG)
              </span>
              <span className="text-[9px] font-mono text-emerald-405 text-emerald-400 flex items-center gap-1">
                <span className="h-1.5 w-1.5 bg-emerald-500 rounded-full animate-pulse" />
                ONLINE AUDITING ACTIVE
              </span>
            </div>

            <div className="flex-1 overflow-y-auto space-y-3 font-mono text-[10.5px] text-slate-350 text-slate-400 custom-scrollbar pr-1">
              {audits.length === 0 ? (
                <div className="text-center py-20 text-slate-500">
                  <span>[SYSTEM]: Operational clean state. Security auditing files are currently empty.</span>
                </div>
              ) : (
                audits.map((log) => (
                  <div key={log.id} className="border-b border-slate-900 pb-2 flex-col flex hover:bg-slate-900/40 p-2 rounded transition-all">
                    <div className="flex items-center justify-between font-bold text-slate-250 text-slate-200">
                      <span>✓ {log.userName} ({log.role})</span>
                      <span className="text-[9.5px] text-slate-500">{log.timestamp}</span>
                    </div>
                    <p className="mt-1 text-slate-350 text-slate-300 leading-relaxed">{log.action}</p>
                    <div className="mt-1 flex items-center justify-between text-[8px] text-slate-600">
                      <span>Node SHA Ref: {log.id.toUpperCase()}</span>
                      <span>Staged IP: {log.ipAddress || '192.168.12.80'}</span>
                    </div>
                  </div>
                ))
              )}
            </div>

            <p className="mt-3.5 border-t border-slate-800/80 pt-2.5 text-[9.5px] font-mono text-slate-500 leading-none shrink-0 text-center">
              Encryption Sequence: SSL_PROXY_STAGING // LOCALSTORAGE_SECURE_STAMP
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
