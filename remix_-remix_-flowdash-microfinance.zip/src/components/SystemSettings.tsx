import React, { useState } from 'react';
import { Sliders, Download, CheckCircle, HelpCircle, Key, Landmark, ShieldCheck, Mail, Sparkles, Building2, BellRing, Trash2, Plus, Edit2, CheckSquare } from 'lucide-react';
import { User, Branch, AlertNotification, FinanceSubmissionTemplate } from '../types';

interface SystemSettingsProps {
  currentUser: User | null;
  branches: Branch[];
  alerts: AlertNotification[];
  onDeleteAlert: (id: string) => void;
  onCreateAlert: (newAlert: AlertNotification) => void;
  onUpdateAlert: (updatedAlert: AlertNotification) => void;
  activeTemplate: FinanceSubmissionTemplate | null;
  onUpdateActiveTemplate: (template: FinanceSubmissionTemplate) => void;
  onAddRecords: (records: any[]) => void;
  onClearDatabase: () => void;
  onRunAuditLog: (action: string) => void;
}

export default function SystemSettings({
  currentUser,
  branches,
  alerts,
  onDeleteAlert,
  onCreateAlert,
  onUpdateAlert,
  activeTemplate,
  onUpdateActiveTemplate,
  onAddRecords,
  onClearDatabase,
  onRunAuditLog
}: SystemSettingsProps) {
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [instName, setInstName] = useState('Pacific Finance LTD');
  const [interestTarget, setInterestTarget] = useState('15');

  const isAdmin = currentUser?.role === 'Admin';

  // Alerts configuration inputs
  const [altTitle, setAltTitle] = useState('');
  const [altDesc, setAltDesc] = useState('');
  const [altType, setAltType] = useState<AlertNotification['type']>('general');
  const [altSeverity, setAltSeverity] = useState<AlertNotification['severity']>('Info');
  const [altBranch, setAltBranch] = useState('All Branches');

  // Templates configuration inputs (initialize from activeTemplate or defaults)
  const [tmplTitle, setTmplTitle] = useState(activeTemplate?.title || 'Required Microfinance Monthly Ledger Format');
  const [tmplInstructions, setTmplInstructions] = useState(
    activeTemplate?.instructions || 'Standardize ledger reporting columns exactly. Must maintain valid numeric disbursals and actual repayment fields.'
  );
  const [tmplTargetRate, setTmplTargetRate] = useState(activeTemplate?.targetInterestRate?.toString() || '15');
  const [tmplMaxDisbursed, setTmplMaxDisbursed] = useState(activeTemplate?.maxDisbursedAmount?.toString() || '15000');
  const [tmplCols, setTmplCols] = useState<string[]>(
    activeTemplate?.requiredColumns || ['borrowerName', 'date', 'amountDisbursed', 'expectedRepayment', 'actualRepayment', 'interestRate', 'expenses', 'status']
  );

  const handleCreateCustomNotification = (e: React.FormEvent) => {
    e.preventDefault();
    if (!altTitle.trim() || !altDesc.trim()) return;
    const newAlert: AlertNotification = {
      id: `alert-${Math.floor(1000 + Math.random() * 9000)}`,
      title: altTitle.trim(),
      description: altDesc.trim(),
      type: altType,
      severity: altSeverity,
      timestamp: new Date().toISOString(),
      isRead: false,
      branchName: altBranch === 'All Branches' ? undefined : altBranch
    };
    onCreateAlert(newAlert);
    onRunAuditLog(`Broadcasted security/financial notification alert: "${altTitle}"`);
    setAltTitle('');
    setAltDesc('');
    setSuccessMsg(`Corporate security notification broadcasted to [${altBranch}]!`);
    setTimeout(() => setSuccessMsg(null), 3000);
  };

  const handleSaveFinanceTemplate = (e: React.FormEvent) => {
    e.preventDefault();
    const upTmpl: FinanceSubmissionTemplate = {
      id: 'active_finance',
      title: tmplTitle.trim() || 'Required Microfinance Monthly Ledger Format',
      instructions: tmplInstructions.trim(),
      requiredColumns: tmplCols,
      targetInterestRate: parseFloat(tmplTargetRate) || 15,
      maxDisbursedAmount: parseFloat(tmplMaxDisbursed) || 15000,
      updatedAt: new Date().toISOString().substring(0, 16).replace('T', ' '),
      createdBy: currentUser?.name || 'Administrator Director'
    };
    onUpdateActiveTemplate(upTmpl);
    onRunAuditLog(`Configured standard physical microfinance template specifications: "${upTmpl.title}"`);
    setSuccessMsg('Active finance submission template successfully saved & published!');
    setTimeout(() => setSuccessMsg(null), 3500);
  };

  const toggleTmplCol = (colVal: string) => {
    if (tmplCols.includes(colVal)) {
      setTmplCols(tmplCols.filter(c => c !== colVal));
    } else {
      setTmplCols([...tmplCols, colVal]);
    }
  };

  // Load sample simulation dataset to fill the charts if empty!
  const handleSeedSimulation = () => {
    const simulationRecs = [
      {
        id: 'rec-sim-101',
        date: '2026-05-18',
        borrowerName: 'Lilongwe Agro Cooperative',
        branchName: 'Lilongwe Plaza Branch',
        amountDisbursed: 5000,
        expectedRepayment: 5750,
        actualRepayment: 5750,
        interestRate: 15,
        expenses: 120,
        status: 'On Time' as const,
        uploadedBy: 'system-seed@microfinance.co.mw'
      },
      {
        id: 'rec-sim-102',
        date: '2026-05-19',
        borrowerName: 'Phiri Poultry Hub',
        branchName: 'Blantyre Central Branch',
        amountDisbursed: 2200,
        expectedRepayment: 2530,
        actualRepayment: 2530,
        interestRate: 15,
        expenses: 90,
        status: 'On Time' as const,
        uploadedBy: 'system-seed@microfinance.co.mw'
      },
      {
        id: 'rec-sim-103',
        date: '2026-05-20',
        borrowerName: 'Zomba Fishing Co',
        branchName: 'Zomba District Desk',
        amountDisbursed: 8000,
        expectedRepayment: 9200,
        actualRepayment: 3000,
        interestRate: 15,
        expenses: 450,
        status: 'Delayed' as const,
        uploadedBy: 'system-seed@microfinance.co.mw'
      },
      {
        id: 'rec-sim-104',
        date: '2026-05-21',
        borrowerName: 'Mzuzu Agro Dealers',
        branchName: 'Mzuzu Northern Station',
        amountDisbursed: 3500,
        expectedRepayment: 4025,
        actualRepayment: 0,
        interestRate: 15,
        expenses: 300,
        status: 'Default' as const,
        uploadedBy: 'system-seed@microfinance.co.mw'
      }
    ];

    onAddRecords(simulationRecs);
    onRunAuditLog('Imported bulk simulated credit books to examine visual graphs and AI thresholds.');
    setSuccessMsg('Bulk simulation books loaded. Visit the Overview Dashboard to examine recharts trend displays and request AI summaries on Sheets Portal!');
    setTimeout(() => setSuccessMsg(null), 4000);
  };

  const handleResetDatabase = () => {
    if (window.confirm('WARNING: You are about to wipe all linked spreadsheet memory and clear credit records. This restores the database to direct baseline seeds. Continue?')) {
      onClearDatabase();
      onRunAuditLog('Issued dynamic credit database reset sequence.');
      setSuccessMsg('Corporate ledger memory wiped and reset to core seeds.');
      setTimeout(() => setSuccessMsg(null), 3500);
    }
  };

  const handleSaveInstitution = (e: React.FormEvent) => {
    e.preventDefault();
    onRunAuditLog(`Updated corporate configuration: InstName=${instName}, IntRate=${interestTarget}%`);
    setSuccessMsg('Institution criteria updated successfully!');
    setTimeout(() => setSuccessMsg(null), 3000);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold font-sans text-gray-950 tracking-tight">System Configuration & Data Export Presets</h1>
        <p className="text-xs text-gray-400 font-medium">Configure corporate parameters, manage bulk simulation seed datasets, and examine CSV / PDF guidelines</p>
      </div>

      {successMsg && (
        <div className="p-3.5 rounded-xl border border-emerald-200 bg-emerald-50 text-xs font-semibold text-emerald-800 flex gap-1.5 items-center">
          <CheckCircle className="h-4.5 w-4.5 text-emerald-500 shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Left: Institution form configuration */}
        <div className="rounded-xl border border-gray-200 bg-white p-5 shadow-sm lg:col-span-1 space-y-4">
          <h3 className="text-xs font-bold font-sans text-gray-800 uppercase tracking-wider mb-1 flex items-center gap-1.5">
            <Landmark className="h-4.5 w-4.5 text-blue-600" />
            <span>Institution Parameters</span>
          </h3>
          <p className="text-[11px] text-gray-450 text-gray-400 leading-normal">
            Adjust general settings for reports generation metrics and interest rates offsets.
          </p>

          <form onSubmit={handleSaveInstitution} className="space-y-4">
            <div>
              <label className="block text-[10px] text-gray-500 font-bold mb-1">Institution Legal Name</label>
              <input
                type="text"
                value={instName}
                onChange={(e) => setInstName(e.target.value)}
                className="w-full rounded-lg border border-gray-250 bg-gray-50 px-3 py-2 text-xs text-gray-850 outline-none focus:bg-white focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-[10px] text-gray-500 font-bold mb-1">Standard Interest Rate Targeting (%)</label>
              <input
                type="number"
                value={interestTarget}
                onChange={(e) => setInterestTarget(e.target.value)}
                className="w-full rounded-lg border border-gray-250 bg-gray-50 px-3 py-2 text-xs text-gray-850 outline-none focus:bg-white focus:border-blue-500 font-mono"
              />
            </div>

            <button
              type="submit"
              className="w-full h-9 inline-flex items-center justify-center gap-1.5 rounded-lg bg-blue-600 text-xs font-bold text-white hover:bg-blue-500 shadow transition-all"
            >
              <span>Update Legal Criteria</span>
            </button>
          </form>

          <div className="border-t border-gray-100 pt-3 flex flex-col gap-1.5 text-[10.5px] text-gray-500 leading-normal font-sans">
            <span className="font-bold flex items-center gap-1 text-slate-700">
              <Building2 className="h-4 w-4 text-emerald-500" />
              Physical Active Branches: {branches.length}
            </span>
            <span className="text-[10px] text-gray-400">Kasungu Plain outlet, Blantyre Central, Zomba Desk, Lilongwe Office, Mzuzu station.</span>
          </div>
        </div>

        {/* Right: Data Management guidelines and PDF export guides */}
        <div className="rounded-xl border border-gray-200 bg-white p-5 shadow-sm lg:col-span-2 space-y-5">
          <div>
            <h3 className="text-xs font-bold font-sans text-gray-800 uppercase tracking-wider mb-1 flex items-center gap-1.5">
              <Sliders className="h-4.5 w-4.5 text-blue-600" />
              <span>Diagnostic Audits & Simulation Tools</span>
            </h3>
            <p className="text-[11px] text-gray-450 text-gray-400 leading-normal">
              Need validation testing? Use the simulator below to seed high-contrast credit lines of wipe cache.
            </p>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            {/* Simulation load */}
            <div className="border rounded-xl p-4 bg-gray-50/50 hover:bg-white transition-all space-y-3.5">
              <h4 className="text-xs font-bold text-gray-900 font-sans flex items-center gap-1.5">
                <Sparkles className="h-4.5 w-4.5 text-indigo-500" />
                Seed Sample Ledger Records
              </h4>
              <p className="text-[11px] text-slate-500 leading-normal">
                Quickly loads 4 representative multi-branch loanee records to examine visual recharts performance and trigger Gemini audits easily.
              </p>
              <button
                onClick={handleSeedSimulation}
                className="inline-flex h-8 items-center justify-center gap-1 rounded bg-blue-600 hover:bg-blue-500 text-white text-[10px] font-bold px-3 transition-colors shrink-0"
              >
                <span>Trigger Simulation Seed</span>
              </button>
            </div>

            {/* Clear reset database */}
            <div className="border rounded-xl p-4 bg-gray-50/50 hover:bg-white transition-all space-y-3.5">
              <h4 className="text-xs font-bold text-gray-900 font-sans flex items-center gap-1.5">
                <Sliders className="h-4.5 w-4.5 text-rose-500" />
                Wipe Corporate Records Cache
              </h4>
              <p className="text-[11px] text-slate-500 leading-normal">
                Wipes linked Google spreadsheet identifiers and clears out all temporary local loanee journals. Returns workspace back to start.
              </p>
              <button
                onClick={handleResetDatabase}
                className="inline-flex h-8 items-center justify-center gap-1 rounded bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 text-[10px] font-bold px-3 transition-colors shrink-0"
              >
                <span>Hard Reset Workspace</span>
              </button>
            </div>
          </div>

          <div className="border-t pt-4 space-y-3">
            <h4 className="text-xs font-bold text-gray-800 uppercase tracking-widest font-mono flex items-center gap-1.5">
              <HelpCircle className="h-4.5 w-4.5 text-blue-500" />
              <span>CSV & Printed PDF Export Protocols</span>
            </h4>

            <div className="space-y-2.5 text-[11px] leading-relaxed text-slate-500 font-sans font-medium">
              <p>
                <strong>📊 CSV Compilation:</strong> When you hit the "Export CSV" trigger in the analyzer view, the browser stitches current record fields into a standard comma-separated cell row array. The download triggers a local download buffer file with standard headers matching Excel or Sheets imports immediately.
              </p>
              <p>
                <strong>🖨️ PDF Generation Desk:</strong> When clicking "Print/PDF Export", Pacific Finance triggers standard physical network CSS printers. The layout hides unnecessary margins, buttons, sidebar elements, and headers dynamically, resulting in an eye-safe, professional, standalone tabular report format for physical desk deliveries.
              </p>
            </div>
          </div>
        </div>
      </div>

      {isAdmin && (
        <div className="grid gap-6 md:grid-cols-2 pt-4">
          {/* Finance Submission Template configuration card */}
          <div className="rounded-xl border border-gray-200 bg-white p-5 shadow-sm space-y-4">
            <div className="flex items-center gap-1.5 border-b pb-2">
              <CheckSquare className="h-4.5 w-4.5 text-blue-600" />
              <div>
                <h3 className="text-xs font-bold font-sans text-gray-800 uppercase tracking-wider">
                  Finance Submission Template Designer
                </h3>
                <p className="text-[10px] text-gray-400">Define columns & guidelines for branch reports submissions</p>
              </div>
            </div>

            <form onSubmit={handleSaveFinanceTemplate} className="space-y-3">
              <div>
                <label className="block text-[10px] text-gray-500 font-bold mb-1">Template Title</label>
                <input
                  type="text"
                  required
                  value={tmplTitle}
                  onChange={(e) => setTmplTitle(e.target.value)}
                  className="w-full rounded-lg border border-gray-250 bg-gray-50 px-3 py-1.8 text-xs text-gray-850 outline-none focus:bg-white focus:border-blue-500 font-medium"
                  placeholder="e.g. Active Microfinance Monthly Ledger Guidelines"
                />
              </div>

              <div>
                <label className="block text-[10px] text-gray-500 font-bold mb-1">Clerk Action Instructions</label>
                <textarea
                  required
                  rows={2}
                  value={tmplInstructions}
                  onChange={(e) => setTmplInstructions(e.target.value)}
                  className="w-full rounded-lg border border-gray-250 bg-gray-50 px-3 py-1.8 text-xs text-gray-850 outline-none focus:bg-white focus:border-blue-500 font-medium leading-normal animate-none transition-all duration-150"
                  placeholder="Enter custom instructions to display to regular users on upload..."
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] text-gray-500 font-bold mb-1">Target Interest Rate (%)</label>
                  <input
                    type="number"
                    required
                    value={tmplTargetRate}
                    onChange={(e) => setTmplTargetRate(e.target.value)}
                    className="w-full rounded-lg border border-gray-250 bg-gray-50 px-3 py-1.8 text-xs text-gray-850 outline-none focus:bg-white focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-gray-500 font-bold mb-1">Max Loan Limit</label>
                  <input
                    type="number"
                    required
                    value={tmplMaxDisbursed}
                    onChange={(e) => setTmplMaxDisbursed(e.target.value)}
                    className="w-full rounded-lg border border-gray-250 bg-gray-50 px-3 py-1.8 text-xs text-gray-850 outline-none focus:bg-white focus:border-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] text-gray-500 font-bold mb-1">Required Schema Fields Presence</label>
                <p className="text-[10px] text-gray-400 mb-2 leading-relaxed">Select columns which regular office users are prompted to upload inside spreadsheets.</p>
                
                <div className="grid grid-cols-2 gap-1.5 pt-1">
                  {[
                    { val: 'borrowerName', label: 'Borrower Full Name' },
                    { val: 'date', label: 'Disbursal Date' },
                    { val: 'amountDisbursed', label: 'Amount Disbursed' },
                    { val: 'expectedRepayment', label: 'Expected Repay' },
                    { val: 'actualRepayment', label: 'Actual Repay' },
                    { val: 'interestRate', label: 'Interest Rate' },
                    { val: 'expenses', label: 'Added Expenses' },
                    { val: 'status', label: 'Status Category' }
                  ].map(c => {
                    const isChecked = tmplCols.includes(c.val);
                    return (
                      <div
                        key={c.val}
                        onClick={() => toggleTmplCol(c.val)}
                        className={`flex items-center gap-1.5 p-1.5 border rounded-lg text-[11px] font-semibold cursor-pointer select-none transition-all ${
                          isChecked ? 'bg-blue-50/55 border-blue-400 text-blue-700' : 'bg-gray-50 text-gray-500 border-gray-200'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          readOnly
                          className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 w-3.5 h-3.5"
                        />
                        <span>{c.label}</span>
                      </div>
                    );
                  })}
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg text-xs shadow-sm flex items-center justify-center gap-1.5"
              >
                <CheckCircle className="h-4 w-4" />
                <span>Publish Active Template</span>
              </button>
            </form>
          </div>

          {/* System Notifications, Broadcast alerts, & local Red flags creator card */}
          <div className="rounded-xl border border-gray-200 bg-white p-5 shadow-sm space-y-4">
            <div className="flex items-center gap-1.5 border-b pb-2">
              <BellRing className="h-4.5 w-4.5 text-blue-600" />
              <div>
                <h3 className="text-xs font-bold font-sans text-gray-800 uppercase tracking-wider">
                  Alarms & Announcements Broadcaster
                </h3>
                <p className="text-[10px] text-gray-400">Post system warnings or localized alerts across physical regions</p>
              </div>
            </div>

            {/* Creation tool */}
            <form onSubmit={handleCreateCustomNotification} className="space-y-3 border-b pb-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] text-gray-500 font-bold mb-1">Notice Category</label>
                  <select
                    value={altType}
                    onChange={(e) => setAltType(e.target.value as any)}
                    className="w-full rounded-lg border border-gray-250 bg-gray-50 px-2.5 py-1.8 text-xs font-medium text-gray-800 outline-none focus:bg-white"
                  >
                    <option value="general">Announcements</option>
                    <option value="loss">Impaired Loans Warning</option>
                    <option value="default">Default Risk Warning</option>
                    <option value="expense">Expense Threshold Warning</option>
                    <option value="system">System Updates</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] text-gray-500 font-bold mb-1">Red Flag Severity</label>
                  <select
                    value={altSeverity}
                    onChange={(e) => setAltSeverity(e.target.value as any)}
                    className="w-full rounded-lg border border-gray-250 bg-gray-50 px-2.5 py-1.8 text-xs font-medium text-gray-800 outline-none focus:bg-white"
                  >
                    <option value="Info">Low (Info)</option>
                    <option value="Warning">Medium (Warning)</option>
                    <option value="Critical">Immediate Risk (Critical)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[10px] text-gray-500 font-bold mb-1">Target Station Audience</label>
                <select
                  value={altBranch}
                  onChange={(e) => setAltBranch(e.target.value)}
                  className="w-full rounded-lg border border-gray-250 bg-gray-50 px-2.5 py-1.8 text-xs font-medium text-gray-800 outline-none focus:bg-white"
                >
                  <option value="All Branches">Unrestricted Board (All Branches)</option>
                  {branches.map(br => (
                    <option key={br.id} value={br.name}>{br.name}</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-1 gap-2.5">
                <div>
                  <label className="block text-[10px] text-gray-500 font-bold mb-1">Alert Headline Title</label>
                  <input
                    type="text"
                    required
                    value={altTitle}
                    onChange={(e) => setAltTitle(e.target.value)}
                    className="w-full rounded-lg border border-gray-250 bg-gray-50 px-3 py-1.8 text-xs text-gray-850 outline-none focus:bg-white focus:border-blue-500 font-bold"
                    placeholder="e.g. Kasungu Plains Delinquency Spike"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-gray-500 font-bold mb-1">Detailed Description Body</label>
                  <input
                    type="text"
                    required
                    value={altDesc}
                    onChange={(e) => setAltDesc(e.target.value)}
                    className="w-full rounded-lg border border-gray-250 bg-gray-50 px-3 py-1.8 text-xs text-gray-850 outline-none focus:bg-white focus:border-blue-500"
                    placeholder="Detailed audit directives text..."
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg text-xs shadow-sm flex items-center justify-center gap-1"
              >
                <Plus className="h-4 w-4" />
                <span>Dispatch Broadcast Notice</span>
              </button>
            </form>

            {/* List to active notices on the system */}
            <div className="space-y-2 max-h-56 overflow-y-auto pt-1">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono block">
                Active System Bulletins ({alerts.length})
              </span>
              {alerts.length === 0 ? (
                <p className="text-[11px] text-slate-400 font-medium">No live notices currently registered.</p>
              ) : (
                alerts.map(al => (
                  <div key={al.id} className="p-2 border border-gray-150 rounded-lg bg-gray-50/50 flex justify-between items-start gap-1.5 text-[11px]">
                    <div className="space-y-0.5 animate-none">
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-gray-900 font-sans">{al.title}</span>
                        <span className={`px-1 py-0.2 rounded font-mono text-[8px] font-bold uppercase ${
                          al.severity === 'Critical' ? 'bg-red-50 text-red-600 border border-red-100' : 'bg-slate-100 text-slate-600 border'
                        }`}>
                          {al.severity}
                        </span>
                      </div>
                      <p className="text-gray-500 leading-normal font-sans">{al.description}</p>
                      <span className="block text-[8px] text-slate-400 font-mono">
                        Outlet Scope: {al.branchName || 'All Outlets'} • {al.timestamp.substring(0, 10)}
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        if (confirm(`Do you want to permanently purge notice "${al.title}"?`)) {
                          onDeleteAlert(al.id);
                          onRunAuditLog(`Deleted active notification bulletin: "${al.title}"`);
                        }
                      }}
                      className="text-slate-400 hover:text-red-600 p-1 shrink-0 cursor-pointer"
                    >
                      <Trash2 className="h-3 w-3" />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
