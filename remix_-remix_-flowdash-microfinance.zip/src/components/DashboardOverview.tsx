import React, { useState } from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer, 
  LineChart, 
  Line,
  Cell,
  PieChart,
  Pie
} from 'recharts';
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  AlertOctagon, 
  Home, 
  Layers, 
  UserPlus, 
  Activity, 
  Target, 
  MapPin, 
  Users,
  Briefcase,
  AlertTriangle,
  Edit2,
  Trash2,
  X,
  Check,
  BookOpen,
  Search,
  Download,
  Printer,
  FileText
} from 'lucide-react';
import { FinancialRecord, User, AlertNotification, AuditLog, Branch } from '../types';

interface DashboardOverviewProps {
  records: FinancialRecord[];
  users: User[];
  alerts: AlertNotification[];
  audits: AuditLog[];
  branches: Branch[];
  currentUser: User | null;
  currentFilterBranch: string;
  setCurrentFilterBranch: (b: string) => void;
  onNavigateToTab: (t: string) => void;
  onUpdateRecord?: (updated: FinancialRecord) => void;
  onDeleteRecord?: (id: string) => void;
  onRunAuditLog?: (action: string) => void;
  manualFlows: Record<string, { openingCash: number; bankedAmount: number }>;
  setManualFlows?: React.Dispatch<
    React.SetStateAction<Record<string, { openingCash: number; bankedAmount: number }>>
  >;
}

export default function DashboardOverview({
  records,
  users,
  alerts,
  audits,
  branches,
  currentUser,
  currentFilterBranch,
  setCurrentFilterBranch,
  onNavigateToTab,
  onUpdateRecord,
  onDeleteRecord,
  onRunAuditLog,
  manualFlows,
  setManualFlows
}: DashboardOverviewProps) {

  // Role access helpers
  const isAdmin = currentUser?.role === 'Admin';

  // State to filter dashboard metrics by a specific reporting day sheet
  const [selectedDashboardDate, setSelectedDashboardDate] = useState<string>('All');

  // Record editing states
  const [editingRecord, setEditingRecord] = useState<FinancialRecord | null>(null);
  const [editBorrowerName, setEditBorrowerName] = useState('');
  const [editBranchName, setEditBranchName] = useState('');
  const [editAmountDisbursed, setEditAmountDisbursed] = useState<number>(0);
  const [editExpectedRepayment, setEditExpectedRepayment] = useState<number>(0);
  const [editActualRepayment, setEditActualRepayment] = useState<number>(0);
  const [editInterestRate, setEditInterestRate] = useState<number>(0);
  const [editExpenses, setEditExpenses] = useState<number>(0);
  const [editStatus, setEditStatus] = useState<'On Time' | 'Delayed' | 'Default'>('On Time');

  // Interactive Search & Intelligent Reporter states
  const [globalSearchQuery, setGlobalSearchQuery] = useState('');
  const [showReportModal, setShowReportModal] = useState(false);

  const handleStartEditRecord = (rec: FinancialRecord) => {
    setEditingRecord(rec);
    setEditBorrowerName(rec.borrowerName);
    setEditBranchName(rec.branchName);
    setEditAmountDisbursed(rec.amountDisbursed);
    setEditExpectedRepayment(rec.expectedRepayment);
    setEditActualRepayment(rec.actualRepayment);
    setEditInterestRate(rec.interestRate);
    setEditExpenses(rec.expenses);
    setEditStatus(rec.status);
  };

  const handleSaveRecord = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingRecord) return;

    const updated: FinancialRecord = {
      ...editingRecord,
      borrowerName: editBorrowerName,
      branchName: editBranchName,
      amountDisbursed: Number(editAmountDisbursed),
      expectedRepayment: Number(editExpectedRepayment),
      actualRepayment: Number(editActualRepayment),
      interestRate: Number(editInterestRate),
      expenses: Number(editExpenses),
      status: editStatus,
    };

    if (onUpdateRecord) {
      onUpdateRecord(updated);
    }
    if (onRunAuditLog) {
      onRunAuditLog(`Admin updated credit ledger record for loanee: ${editBorrowerName} at branch: ${editBranchName}`);
    }
    setEditingRecord(null);
  };

  const handleDeleteRecordClick = (rec: FinancialRecord) => {
    if (onDeleteRecord) {
      onDeleteRecord(rec.id);
    }
    if (onRunAuditLog) {
      onRunAuditLog(`Admin permanently deleted credit liability ledger record of borrower: ${rec.borrowerName} (${rec.branchName})`);
    }
  };

  // Apply branch filter (Admins can filter, Users are bound to their branch by default)
  const activeBranchFilter = isAdmin ? currentFilterBranch : (currentUser?.branch || 'All');
  
  const filteredRecords = records.filter(r => {
    if (activeBranchFilter === 'All') return true;
    return r.branchName === activeBranchFilter;
  });

  const filteredAlerts = alerts.filter(a => {
    if (activeBranchFilter === 'All') return true;
    return a.branchName === activeBranchFilter;
  });

  // Compile unique dates for dropdown listing
  const manualDatesList = Object.keys(manualFlows).map(k => k.includes('_') ? k.split('_').pop()! : k);
  const uniqueDashboardDates = Array.from(new Set([
    ...records.map(r => r.date),
    ...manualDatesList
  ].filter(Boolean))).sort((a, b) => b.localeCompare(a)); // Newest descending for select option

  // Calculate Key aggregates with option to isolate by a specific Sheet Date
  let totalDisbursed = 0;
  let totalExpected = 0;
  let totalRepayments = 0;
  let totalExpenses = 0;
  let defaultCount = 0;
  let delayedCount = 0;
  let onTimeCount = 0;

  filteredRecords.forEach(r => {
    if (selectedDashboardDate !== 'All' && r.date !== selectedDashboardDate) return;
    totalDisbursed += r.amountDisbursed;
    totalExpected += r.expectedRepayment;
    totalRepayments += r.actualRepayment;
    totalExpenses += r.expenses;
    if (r.status === 'Default') defaultCount++;
    if (r.status === 'Delayed') delayedCount++;
    if (r.status === 'On Time') onTimeCount++;
  });

  // Profit calculations
  // Net Yield = actual repayment - expenses
  const netProfitLoss = totalRepayments - totalExpenses - totalDisbursed;
  // Let's compute actual revenues which represents recovered interests:
  // Interest recovered + principal recovered - expenses - disbursed
  const simpleRevenue = totalRepayments;
  const financialMargin = simpleRevenue - totalExpenses;
  const isCompanyMakingGood = (totalRepayments - totalExpenses) >= totalDisbursed;

  // Compile daily cash flows map sequentially to ensure solid chronology & opening balances carry forward
  const dailyCashFlowsMap: Record<string, {
    opening: number;
    collected: number;
    disbursed: number;
    banked: number;
    closing: number;
  }> = {};

  const activeBranchList = branches.map(b => b.name);
  if (!activeBranchList.includes('Zomba District Desk')) activeBranchList.push('Zomba District Desk');
  if (!activeBranchList.includes('Blantyre Central Branch')) activeBranchList.push('Blantyre Central Branch');
  if (!activeBranchList.includes('Lilongwe Plaza Branch')) activeBranchList.push('Lilongwe Plaza Branch');
  if (!activeBranchList.includes('Lilongwe Head Office')) activeBranchList.push('Lilongwe Head Office');
  if (!activeBranchList.includes('Mzuzu Northern Station')) activeBranchList.push('Mzuzu Northern Station');

  let totalBanked = 0;
  let finalClosingCash = 0;
  let computedOpeningBalance = 0;

  if (activeBranchFilter === 'All') {
    // Collect all dates
    const allDates = Array.from(new Set([
      ...records.map(r => r.date),
      ...manualDatesList,
      selectedDashboardDate !== 'All' ? selectedDashboardDate : ''
    ].filter(Boolean))).sort((a, b) => a.localeCompare(b));

    const branchTrailingCash: Record<string, number> = {};
    activeBranchList.forEach(bName => {
      branchTrailingCash[bName] = 0;
    });

    allDates.forEach(date => {
      let dayOpeningSum = 0;
      let dayCollectedSum = 0;
      let dayDisbursedSum = 0;
      let dayBankedSum = 0;
      let dayClosingSum = 0;

      activeBranchList.forEach(bName => {
        const dayRecords = records.filter(r => r.branchName === bName && r.date === date);
        const collected = dayRecords.reduce((sum, r) => sum + r.actualRepayment, 0);
        const disbursed = dayRecords.reduce((sum, r) => sum + r.amountDisbursed, 0);

        const manualKey = `${bName}_${date}`;
        const manual = manualFlows[manualKey] || manualFlows[date];

        const prevCash = branchTrailingCash[bName] !== undefined ? branchTrailingCash[bName] : 0;
        const opening = manual && manual.openingCash !== undefined ? manual.openingCash : prevCash;
        // The banked interest formula: Interest portion of paid amount from 25% interest rate. (P = Paid / 1.25; Interest = Paid - P)
        const banked = Math.round(collected - (collected / 1.25));
        const closing = opening + collected - disbursed - banked;

        branchTrailingCash[bName] = closing;

        dayOpeningSum += opening;
        dayCollectedSum += collected;
        dayDisbursedSum += disbursed;
        dayBankedSum += banked;
        dayClosingSum += closing;
      });

      dailyCashFlowsMap[date] = {
        opening: dayOpeningSum,
        collected: dayCollectedSum,
        disbursed: dayDisbursedSum,
        banked: dayBankedSum,
        closing: dayClosingSum
      };

      totalBanked += dayBankedSum;
      finalClosingCash = dayClosingSum;
    });

    if (allDates.length > 0) {
      computedOpeningBalance = dailyCashFlowsMap[allDates[allDates.length - 1]]?.opening || 0;
    }
  } else {
    // Single branch specific sequence
    const bName = activeBranchFilter;
    const branchRecords = records.filter(r => r.branchName === bName);
    const branchDates = Array.from(new Set([
      ...branchRecords.map(r => r.date),
      ...manualDatesList,
      selectedDashboardDate !== 'All' ? selectedDashboardDate : ''
    ].filter(Boolean))).sort((a, b) => a.localeCompare(b));

    let trailingCash = 0;

    branchDates.forEach(date => {
      const dayRecords = branchRecords.filter(r => r.date === date);
      const collected = dayRecords.reduce((sum, r) => sum + r.actualRepayment, 0);
      const disbursed = dayRecords.reduce((sum, r) => sum + r.amountDisbursed, 0);

      const manualKey = `${bName}_${date}`;
      const manual = manualFlows[manualKey] || manualFlows[date];

      const opening = manual && manual.openingCash !== undefined ? manual.openingCash : trailingCash;
      // The banked interest formula: Interest portion of paid amount from 25% interest rate. (P = Paid / 1.25; Interest = Paid - P)
      const banked = Math.round(collected - (collected / 1.25));
      const closing = opening + collected - disbursed - banked;

      dailyCashFlowsMap[date] = {
        opening,
        collected,
        disbursed,
        banked,
        closing
      };

      totalBanked += banked;
      finalClosingCash = closing;
      trailingCash = closing;
    });

    if (branchDates.length > 0) {
      computedOpeningBalance = dailyCashFlowsMap[branchDates[branchDates.length - 1]]?.opening || 0;
    }
  }

  // Adjust metrics based on selected date if it's NOT 'All'
  let displayOpeningBalance = computedOpeningBalance;
  if (selectedDashboardDate !== 'All') {
    const cf = dailyCashFlowsMap[selectedDashboardDate] || {
      opening: 0,
      collected: 0,
      disbursed: 0,
      banked: 0,
      closing: 0
    };
    displayOpeningBalance = cf.opening;
    totalBanked = cf.banked;
    finalClosingCash = cf.closing;
  }

  const defaultRate = filteredRecords.length > 0 ? (defaultCount / filteredRecords.length) : 0;
  const recoveryEfficiency = totalExpected > 0 ? (totalRepayments / totalExpected) * 100 : 0;

  // Compile Recharts charts source data
  // 1. Profit vs expenses trajectory
  const timelinePerformanceData = filteredRecords.reduce((acc: any[], r) => {
    const dateStr = r.date;
    const existing = acc.find(item => item.date === dateStr);
    
    const profitSegment = r.actualRepayment - r.amountDisbursed;
    
    if (existing) {
      existing.Disbursed += r.amountDisbursed;
      existing.Received += r.actualRepayment;
      existing.Expenses += r.expenses;
    } else {
      acc.push({
        date: dateStr,
        Disbursed: r.amountDisbursed,
        Received: r.actualRepayment,
        Expenses: r.expenses
      });
    }
    return acc;
  }, []).sort((a,b) => a.date.localeCompare(b.date));

  // 2. Branch distribution comparison chart data
  const branchChartData = branches.map(b => {
    const branchRecs = records.filter(r => r.branchName === b.name);
    let disb = 0;
    let rec = 0;
    let exp = 0;
    branchRecs.forEach(r => {
      disb += r.amountDisbursed;
      rec += r.actualRepayment;
      exp += r.expenses;
    });
    return {
      name: b.name.replace(' Branch', '').replace(' Station', '').replace(' Desk', ''),
      Disbursed: disb,
      Recovered: rec,
      Overhead: exp,
      NetMargin: rec - exp - disb
    };
  });

  // 3. Credit status breakdown chart data
  const statusPieData = [
    { name: 'On Time Repayments', value: onTimeCount, color: '#10B981' },
    { name: 'Delayed Collections', value: delayedCount, color: '#F59E0B' },
    { name: 'Active Default Losses', value: defaultCount, color: '#EF4444' }
  ].filter(p => p.value > 0);

  // Compile matched query datasets (transactions and daily sheets)
  const queryNormalized = globalSearchQuery.trim().toLowerCase();

  // 1. Individual Transactions matching search query
  const queryMatchedRecords = filteredRecords.filter(r => {
    if (!queryNormalized) return true;
    return (
      r.borrowerName.toLowerCase().includes(queryNormalized) ||
      r.branchName.toLowerCase().includes(queryNormalized) ||
      r.date.includes(queryNormalized) ||
      r.status.toLowerCase().includes(queryNormalized) ||
      String(r.amountDisbursed).includes(queryNormalized) ||
      String(r.expectedRepayment).includes(queryNormalized) ||
      String(r.actualRepayment).includes(queryNormalized) ||
      String(r.expenses).includes(queryNormalized)
    );
  });

  // 2. Daily Cash Flow Balance Sheets matching search query
  const queryMatchedCashFlows = Object.entries(dailyCashFlowsMap).map(([date, cf]) => ({
    date,
    ...cf
  })).filter(cf => {
    if (!queryNormalized) return true;
    return (
      cf.date.includes(queryNormalized) ||
      String(cf.opening).includes(queryNormalized) ||
      String(cf.collected).includes(queryNormalized) ||
      String(cf.disbursed).includes(queryNormalized) ||
      String(cf.banked).includes(queryNormalized) ||
      String(cf.closing).includes(queryNormalized)
    );
  });

  // --- INTERACTIVE AUDIT DOWNLOAD AND EXPORT SUITE ---

  // 1. Export summary + detail ledger datastores to CSV format
  const handleExportCSV = () => {
    let csvContent = "";
    csvContent += "PACIFIC FINANCE SYSTEM CENTRAL AUDIT LEDGER REPORT\n";
    csvContent += `Generated At: ${new Date().toISOString()} | Search Query: ${globalSearchQuery || "Global All-Time"}\n\n`;
    
    csvContent += "=== 1. DAILY CASH FLOW BALANCE SUMMARIES ===\n";
    csvContent += "Date,Opening Cash (MWK),Collected Inflows (MWK),Disbursed Outflows (MWK),Banked Interest (MWK),Closing Vault Cash (MWK)\n";
    queryMatchedCashFlows.forEach(cf => {
      csvContent += `${cf.date},${cf.opening},${cf.collected},${cf.disbursed},${cf.banked},${cf.closing}\n`;
    });
    
    csvContent += "\n=== 2. INDIVIDUAL TRANSACTION LEDGERS ===\n";
    csvContent += "Borrower Loanee,Operating Branch,Date,Disbursed (MWK),Expected Repayment (MWK),Actual Repayment (MWK),Status\n";
    queryMatchedRecords.forEach(r => {
      csvContent += `"${r.borrowerName}","${r.branchName}",${r.date},${r.amountDisbursed},${r.expectedRepayment},${r.actualRepayment},"${r.status}"\n`;
    });
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `pacific_report_${globalSearchQuery.replace(/[^a-z0-9]/gi, '_') || 'global'}_ledger.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    if (onRunAuditLog) {
      onRunAuditLog(`Exported central ledger report to CSV matching: "${globalSearchQuery || 'All'}"`);
    }
  };

  // 2. Export reported structure as JSON package
  const handleExportJSON = () => {
    const payload = {
      reportTitle: "Pacific Finance System Central Audit Ledger Report",
      exportedAt: new Date().toISOString(),
      searchQuery: globalSearchQuery,
      summaryCashFlows: queryMatchedCashFlows,
      transactionDetails: queryMatchedRecords
    };
    
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `pacific_report_${globalSearchQuery.replace(/[^a-z0-9]/gi, '_') || 'global'}_ledger.json`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    if (onRunAuditLog) {
      onRunAuditLog(`Exported central datastore payloads in JSON matching filter: "${globalSearchQuery || 'All'}"`);
    }
  };

  // 3. Export to Stand-alone fully styled Printable HTML file (best offline vector PDF generator ever devised)
  const handleDownloadStandaloneReport = () => {
    const totalMatchedDisbursed = queryMatchedRecords.reduce((sum, r) => sum + r.amountDisbursed, 0);
    const totalMatchedCollected = queryMatchedRecords.reduce((sum, r) => sum + r.actualRepayment, 0);
    const totalMatchedExpected = queryMatchedRecords.reduce((sum, r) => sum + r.expectedRepayment, 0);

    const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Pacific Finance - Ledger Audit Report</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    @media print {
      .no-print { display: none !important; }
      body { color: #000; background: #fff; }
      @page { margin: 1.5cm; }
    }
  </style>
</head>
<body class="bg-gray-50 text-slate-900 font-sans p-8">
  <div class="max-w-4xl mx-auto bg-white shadow-lg border border-gray-200 p-8 rounded-2xl">
    
    <!-- Top Action Headers (unprinted) -->
    <div class="no-print flex justify-between items-center bg-emerald-50 border border-emerald-100 p-4 rounded-xl mb-8">
      <div>
        <h4 class="text-xs font-black text-[#00923A] uppercase tracking-wider">OFFLINE REPORT GENERATED</h4>
        <p class="text-[10px] text-slate-500 font-medium">This document is packaged for offline vector PDF printing and records filing.</p>
      </div>
      <button onclick="window.print()" class="px-4 py-2 bg-[#00923A] hover:bg-emerald-700 text-white text-xs font-bold rounded-lg shadow-sm transition-all flex items-center gap-2">
        <span>Click to Print / Save as PDF</span>
      </button>
    </div>

    <!-- Official Brand Header -->
    <div class="flex justify-between items-start border-b border-gray-200 pb-6 mb-8">
      <div class="space-y-1">
        <h1 class="text-2xl font-black text-[#00923A] tracking-wider uppercase font-sans">PACIFIC FINANCE</h1>
        <p class="text-xs font-bold tracking-widest text-amber-500 uppercase">Microfinance Credit Operations & Audit Desk</p>
        <p class="text-[10px] text-slate-500 font-medium font-mono">Head Office: Lilongwe, Malawi • Global Administrative Archive</p>
      </div>
      <div class="text-right space-y-1">
        <span class="inline-flex rounded bg-[#00923A]/10 px-2.5 py-1 text-xs font-bold font-sans text-[#00923A] border border-[#00923A]/15 uppercase font-medium">OFFICIAL LEDGER DOCUMENT</span>
        <p class="text-[10px] font-mono font-bold text-slate-500 mt-2">Export Date: \${new Date().toUTCString()}</p>
        <p class="text-[10px] font-mono text-slate-400">Search Filter: "\${globalSearchQuery || "Global All-Time"}"</p>
      </div>
    </div>

    <!-- Upper General Stats Cards -->
    <div class="grid grid-cols-3 gap-4 mb-8">
      <div class="border border-slate-200 bg-slate-50/50 rounded-xl p-4 text-center">
        <span class="text-[9.5px] font-bold uppercase tracking-wider text-slate-500 block">Invested Disbursements</span>
        <span class="text-lg font-black font-mono text-slate-900 block mt-1">MWK \${totalMatchedDisbursed.toLocaleString()}</span>
      </div>
      <div class="border border-slate-200 bg-slate-50/50 rounded-xl p-4 text-center">
        <span class="text-[9.5px] font-bold uppercase tracking-wider block text-[#00923A]">Recovered Collected</span>
        <span class="text-lg font-black font-mono text-[#00923A] block mt-1">MWK \${totalMatchedCollected.toLocaleString()}</span>
      </div>
      <div class="border border-slate-200 bg-slate-50/50 rounded-xl p-4 text-center">
        <span class="text-[9.5px] font-bold uppercase tracking-wider text-amber-500 block">Total Expected Repayment</span>
        <span class="text-lg font-black font-mono text-slate-900 block mt-1">MWK \${totalMatchedExpected.toLocaleString()}</span>
      </div>
    </div>

    <!-- 1. Daily Balance Sheets summaries -->
    <div class="mb-8">
      <h3 class="text-xs font-black text-[#00923A] uppercase tracking-wider border-b border-dashed border-slate-200 pb-2 mb-4">
        1. Daily Vault Cash Flow Balance Sheets Summaries
      </h3>
      <table class="w-full text-left text-[11px] border-collapse">
        <thead>
          <tr class="bg-gray-100/80 border-b border-gray-300 font-bold text-gray-750">
            <th class="py-2.5 px-3">Date</th>
            <th class="py-2.5 px-3 text-right">Opening Cash</th>
            <th class="py-2.5 px-3 text-right">Collections (Inflow)</th>
            <th class="py-2.5 px-3 text-right">Disbursements (Outflow)</th>
            <th class="py-2.5 px-3 text-right">Banked Interest</th>
            <th class="py-2.5 px-3 text-right">Closing vault Cash</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-gray-200">
          \${queryMatchedCashFlows.map(cf => \`
            <tr>
              <td class="py-2 px-3 font-mono font-bold">\${cf.date}</td>
              <td class="py-2 px-3 text-right font-mono">MWK \${cf.opening.toLocaleString()}</td>
              <td class="py-2 px-3 text-right font-mono text-emerald-600 font-bold">MWK \${cf.collected.toLocaleString()}</td>
              <td class="py-2 px-3 text-right font-mono">MWK \${cf.disbursed.toLocaleString()}</td>
              <td class="py-2 px-3 text-right font-mono text-amber-600">MWK \${cf.banked.toLocaleString()}</td>
              <td class="py-2 px-3 text-right font-mono font-bold text-slate-900">MWK \${cf.closing.toLocaleString()}</td>
            </tr>
          \`).join('')}
        </tbody>
      </table>
    </div>

    <!-- 2. Individual Transaction Ledgers -->
    <div class="mb-12">
      <h3 class="text-xs font-black text-[#00923A] uppercase tracking-wider border-b border-dashed border-slate-200 pb-2 mb-4">
        2. Individual Logged Ledger Credit Liabilities
      </h3>
      <table class="w-full text-left text-[11px] border-collapse">
        <thead>
          <tr class="bg-gray-100/80 border-b border-gray-300 font-bold text-gray-755">
            <th class="py-2.5 px-3">Borrower Client</th>
            <th class="py-2.5 px-3">Operating Branch</th>
            <th class="py-2.5 px-3 text-right">Amount Disbursed</th>
            <th class="py-2.5 px-3 text-right">Expected Recovery</th>
            <th class="py-2.5 px-3 text-right">Recovered Amount</th>
            <th class="py-2.5 px-3 text-center">Status</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-gray-200">
          \${queryMatchedRecords.map(r => \`
            <tr>
              <td class="py-2 px-3 font-bold text-slate-900">\${r.borrowerName}</td>
              <td class="py-2 px-3">\${r.branchName}</td>
              <td class="py-2 px-3 text-right font-mono">MWK \${r.amountDisbursed.toLocaleString()}</td>
              <td class="py-2 px-3 text-right font-mono">MWK \${r.expectedRepayment.toLocaleString()}</td>
              <td class="py-2 px-3 text-right font-mono text-[#00923A] font-bold">MWK \${r.actualRepayment.toLocaleString()}</td>
              <td class="py-2 px-3 text-center">
                <span class="px-2 py-0.5 rounded border text-[9px] font-bold \${
                  r.status === 'On Time' 
                    ? 'border-emerald-200 bg-emerald-50 text-emerald-700' 
                    : r.status === 'Delayed' 
                      ? 'border-amber-200 bg-amber-50 text-amber-700' 
                      : 'border-red-200 bg-red-50 text-red-700'
                }">
                  \${r.status}
                </span>
              </td>
            </tr>
          \`).join('')}
        </tbody>
      </table>
    </div>

    <!-- Official Validation Sign-off -->
    <div class="mt-16 pt-8 border-t border-gray-200 grid grid-cols-2 gap-8 text-xs font-medium text-slate-650">
      <div>
        <p class="text-slate-400 font-bold uppercase text-[9px] tracking-wide mb-12">Internal Credit Auditor Vetting Sign-off</p>
        <div class="border-b border-slate-400 w-48 mb-1"></div>
        <p class="font-bold">Authorized Officer Signature</p>
        <p class="text-[10px] text-slate-400 mt-1">Date Signature Affixed: ___________________________</p>
      </div>
      <div class="text-right">
        <p class="text-slate-400 font-bold uppercase text-[9px] tracking-wide mb-12">System Verification Timestamp</p>
        <p class="font-bold text-slate-800 font-mono">HASH: MD5-\${Math.floor(1e8 + Math.random() * 9e8).toString(16)}</p>
        <p class="text-[10px] text-slate-400 mt-1">Status: SECURE ARCHIVAL ENVELOPE RECORDED</p>
      </div>
    </div>

  </div>
</body>
</html>`;

    const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `pacific_report_${globalSearchQuery.replace(/[^a-z0-9]/gi, '_') || 'global'}_ledger.html`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    if (onRunAuditLog) {
      onRunAuditLog(`Generated physical high-fidelity HTML/PDF printable report filter: "${globalSearchQuery || 'All'}"`);
    }
  };

  return (
    <div className="space-y-6">
      {/* Upper overview stats bar and branch selector */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold font-sans text-gray-950 tracking-tight">Pacific Finance Central Analytics</h1>
          <p className="text-xs text-gray-400 font-medium">
            Active view: <span className="text-blue-600 font-bold">{activeBranchFilter} Ledger Index</span> • Real-time status reporting
          </p>
        </div>

        {/* Filters Controls */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Calendar Selector (Reporting Day Sheet) */}
          <div className="flex items-center gap-2 bg-slate-50 p-1.5 rounded-lg border border-slate-205">
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider font-mono">Reporting Day Sheet:</span>
            <select
              value={selectedDashboardDate}
              onChange={(e) => setSelectedDashboardDate(e.target.value)}
              className="rounded bg-white px-2 py-1 text-xs font-bold text-slate-800 border border-gray-200 outline-none cursor-pointer"
            >
              <option value="All">All Sheets Cumulative (All-Time)</option>
              {uniqueDashboardDates.map(d => (
                <option key={d} value={d}>Sheet Page: {d}</option>
              ))}
            </select>
          </div>

          {/* Admin specific branch filter dropdown */}
          {isAdmin && (
            <div className="flex items-center gap-2 bg-slate-50 p-1.5 rounded-lg border border-slate-205">
              <span className="text-[10px] font-bold text-slate-557 text-slate-500 uppercase tracking-wider font-mono">Vetting Station:</span>
              <select
                value={currentFilterBranch}
                onChange={(e) => setCurrentFilterBranch(e.target.value)}
                className="rounded-lg border border-gray-250 bg-white px-3 py-1 text-xs font-semibold text-gray-800 outline-none focus:border-blue-500"
              >
                <option value="All">All Physical Branches (Global)</option>
                {branches.map(b => (
                  <option key={b.id} value={b.name}>{b.name}</option>
                ))}
              </select>
            </div>
          )}
        </div>
      </div>

      {/* CORE FIVE STRATEGIC KEY METRIC CARDS (including Opening Balance) */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        {/* New 🔑 Opening Balance */}
        <div className="rounded-xl border border-gray-200 bg-white p-5 shadow-sm">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-[10px] font-bold uppercase font-mono tracking-wider text-gray-400">Opening Balance</p>
              <h3 className="text-xl font-bold font-mono text-gray-900 mt-1.5">MWK {displayOpeningBalance.toLocaleString()}</h3>
            </div>
            <div className="rounded-lg bg-slate-50 p-2 text-slate-600">
              <BookOpen className="h-5 w-5" />
            </div>
          </div>
          <div className="mt-4 flex items-center gap-1.5 text-xs">
            <span className="text-gray-400 font-medium font-sans">Vault key active</span>
            <span className="font-bold text-gray-800 font-mono">
              {selectedDashboardDate === 'All' ? 'Latest sheet' : selectedDashboardDate}
            </span>
          </div>
        </div>

        {/* Core disbursements ledger */}
        <div className="rounded-xl border border-gray-200 bg-white p-5 shadow-sm">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-[10px] font-bold uppercase font-mono tracking-wider text-gray-400">Total Disbursements</p>
              <h3 className="text-xl font-bold font-mono text-gray-900 mt-1.5">MWK {totalDisbursed.toLocaleString()}</h3>
            </div>
            <div className="rounded-lg bg-blue-50 p-2 text-blue-600">
              <Layers className="h-5 w-5" />
            </div>
          </div>
          <div className="mt-4 flex items-center gap-1.5 text-xs">
            <span className="text-gray-400 font-medium font-sans">Logged across</span>
            <span className="font-bold text-gray-800 font-mono">{filteredRecords.length} records</span>
          </div>
        </div>

        {/* Cumulative yields recovery */}
        <div className="rounded-xl border border-gray-200 bg-white p-5 shadow-sm">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-[10px] font-bold uppercase font-mono tracking-wider text-gray-400">Yield Recovered</p>
              <h3 className="text-xl font-bold font-mono text-emerald-600 mt-1.5">MWK {totalRepayments.toLocaleString()}</h3>
            </div>
            <div className="rounded-lg bg-emerald-50 p-2 text-emerald-600">
              <DollarSign className="h-5 w-5" />
            </div>
          </div>
          <div className="mt-4 flex items-center gap-1.5 text-xs">
            <span className={`inline-flex items-center gap-0.5 font-bold ${recoveryEfficiency >= 80 ? 'text-emerald-600' : 'text-amber-600'}`}>
              {recoveryEfficiency.toFixed(1)}%
            </span>
            <span className="text-slate-400 font-medium font-sans">efficiency against expected</span>
          </div>
        </div>

        {/* Banked metrics */}
        <div id="kpi-card-banked" className="rounded-xl border border-amber-200 bg-amber-50/10 p-5 shadow-sm">
          <div id="kpi-card-banked-header" className="flex justify-between items-start">
            <div>
              <p className="text-[10px] font-bold uppercase font-mono tracking-wider text-amber-805 flex items-center gap-1">
                <span className="flex h-1.5 w-1.5 rounded-full bg-amber-500 animate-pulse" />
                Banked
              </p>
              <h3 id="kpi-card-banked-value" className="text-xl font-bold font-mono text-amber-950 mt-1.5">MWK {totalBanked.toLocaleString()}</h3>
            </div>
            <div className="rounded-lg bg-amber-50 p-2 text-amber-600">
              <TrendingUp className="h-5 w-5" />
            </div>
          </div>
          <div className="mt-4 flex items-center gap-1.5 text-xs">
            <span className="font-bold text-amber-700 font-mono">
              {((totalBanked / (totalRepayments || 1)) * 100).toFixed(1)}%
            </span>
            <span className="text-amber-900/60 font-medium font-sans">of recovered yield has been banked</span>
          </div>
        </div>

        {/* Closing Balance (Cash Remaining at Office) */}
        <div className="rounded-xl border border-blue-200 bg-blue-50/10 p-5 shadow-sm">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-[10px] font-bold uppercase font-sans tracking-wide text-blue-800 flex items-center gap-1">
                <span className="flex h-1.5 w-1.5 rounded-full bg-blue-500 animate-pulse" />
                Closing Balance
              </p>
              <h3 className="text-xl font-bold font-mono text-blue-950 mt-1.5">MWK {finalClosingCash.toLocaleString()}</h3>
            </div>
            <div className="rounded-lg bg-blue-50 p-2 text-blue-600">
              <Layers className="h-5 w-5" />
            </div>
          </div>
          <div className="mt-4 flex items-center gap-1.5 text-xs font-sans">
            <span className="font-bold text-blue-700 font-mono">
              MWK {finalClosingCash.toLocaleString()}
            </span>
            <span className="text-blue-900/65 font-medium font-sans">cash remaining in Vault</span>
          </div>
        </div>
      </div>

      {/* 🏛️ ADMIN ONLY: BRANCH OPENING BALANCE ALLOCATION HUB */}
      {isAdmin && (
        <div className="rounded-xl border border-blue-100 bg-white p-6 text-slate-800 shadow-sm space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-gray-150 pb-3">
            <div>
              <h3 className="text-xs font-black uppercase tracking-widest text-[#00923A] flex items-center gap-1.5 font-sans">
                <span className="flex h-2 w-2 rounded-full bg-amber-500 animate-pulse" />
                🏛️ Branch Float and Opening Balance Allocation Hub
              </h3>
              <p className="text-[10px] text-slate-500 font-semibold mt-0.5">
                Distribute and assign starting vault cash parameters to discrete physical desks for sequence propagation.
              </p>
            </div>
            <div className="flex items-center gap-2 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-205">
              <span className="text-[10px] font-bold font-mono text-amber-705 text-amber-700 uppercase tracking-wider">Target Date:</span>
              <input
                type="date"
                value={selectedDashboardDate === 'All' ? new Date().toISOString().split('T')[0] : selectedDashboardDate}
                onChange={(e) => {
                  setSelectedDashboardDate(e.target.value);
                }}
                className="rounded bg-white border border-slate-200 px-2 py-0.5 text-xs text-slate-800 font-bold outline-none focus:border-[#00923A] cursor-pointer"
              />
            </div>
          </div>

          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4 font-sans">
            {branches.map(br => {
              const activeDate = selectedDashboardDate === 'All' ? new Date().toISOString().split('T')[0] : selectedDashboardDate;
              const branchKey = `${br.name}_${activeDate}`;
              const val = manualFlows[branchKey]?.openingCash || 0;
              return (
                <div key={br.id} className="bg-slate-50/55 border border-slate-200 rounded-lg p-3.5 space-y-2 hover:border-[#00923A]/60 hover:bg-white transition-all duration-150">
                  <div className="flex justify-between items-center gap-2">
                    <span className="text-[10.5px] font-bold text-slate-800 truncate max-w-[140px]" title={br.name}>
                      {br.name}
                    </span>
                    <span className="text-[8.5px] font-mono font-bold bg-[#00923A]/10 text-[#00923A] px-1.5 py-0.5 rounded border border-[#00923A]/25">
                      {br.code}
                    </span>
                  </div>
                  <div className="relative mt-1">
                    <span className="absolute left-2.5 top-2 text-[9px] text-slate-450 font-bold font-mono">MWK</span>
                    <input
                      type="number"
                      value={val || ''}
                      placeholder="0"
                      onChange={(e) => {
                        if (!setManualFlows) return;
                        const v = Math.max(0, parseFloat(e.target.value) || 0);
                        setManualFlows(prev => ({
                          ...prev,
                          [branchKey]: {
                            openingCash: v,
                            bankedAmount: prev[branchKey]?.bankedAmount || 0
                          }
                        }));
                        if (onRunAuditLog) {
                          onRunAuditLog(`Allocated starting vault cash MWK ${v} for ${br.name} on ${activeDate}`);
                        }
                      }}
                      className="w-full rounded border border-slate-200 bg-white pl-10 pr-2 py-1 text-xs text-slate-800 font-bold font-mono outline-none focus:border-[#00923A] focus:ring-1 focus:ring-[#00923A] placeholder-slate-400 hover:border-slate-350 transition-colors"
                      disabled={!setManualFlows}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* CORE CHARTS: TRENDS VISUALIZER */}
      <h3 className="text-xs font-bold font-sans text-gray-800 uppercase tracking-wider mt-4">Microfinance Portfolio Trends</h3>
      <div className="grid gap-6 lg:grid-cols-3">
        {/* Trajectory comparison timeline graph */}
        <div className="rounded-xl border border-gray-200 bg-white p-5 shadow-sm lg:col-span-2 space-y-3">
          <div>
            <h3 className="text-xs font-bold font-sans text-gray-800 uppercase tracking-widest font-mono">Ledger Yield Trajectory</h3>
            <p className="text-[10px] text-gray-400 font-medium">Comparison of disbursement capital outflows vs live repayment yields recovered</p>
          </div>

          <div className="h-72 w-full pt-2">
            {timelinePerformanceData.length === 0 ? (
              <div className="h-full flex items-center justify-center text-xs text-slate-450 text-slate-400">No timeline data currently loaded.</div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={timelinePerformanceData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F1F5F9" />
                  <XAxis dataKey="date" stroke="#94A3B8" fontSize={10} fontClassName="font-mono" />
                  <YAxis stroke="#94A3B8" fontSize={10} fontClassName="font-mono" />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#1E293B', borderRadius: '8px', border: 'none', color: '#F1F5F9', fontSize: '11px' }}
                    labelStyle={{ fontWeight: 'bold', color: '#FFFFFF' }}
                  />
                  <Legend wrapperStyle={{ fontSize: '10px', fontWeight: 'bold' }} />
                  <Line type="monotone" dataKey="Received" stroke="#10B981" strokeWidth={3} activeDot={{ r: 6 }} name="Repayments Collected (Inflows)" />
                  <Line type="monotone" dataKey="Disbursed" stroke="#F59E0B" strokeWidth={3} name="Capital Disbursed (Outflows)" />
                  <Line type="monotone" dataKey="Expenses" stroke="#94A3B8" strokeWidth={1.5} strokeDasharray="4 4" name="Office Overhead" />
                </LineChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        {/* Credit risk status breakdown pie graphic */}
        <div className="rounded-xl border border-gray-200 bg-white p-5 shadow-sm lg:col-span-1 space-y-3 flex flex-col justify-between">
          <div>
            <h3 className="text-xs font-bold font-sans text-gray-800 uppercase tracking-widest font-mono">Credit Risk Portfolio</h3>
            <p className="text-[10px] text-gray-400 font-medium">Branch loan accounts performance categorization status</p>
          </div>

          <div className="h-56 w-full relative flex items-center justify-center">
            {statusPieData.length === 0 ? (
              <p className="text-xs text-slate-400">Empty portfolio split.</p>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={statusPieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {statusPieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{ fontSize: '11px', fontWeight: 'bold' }} />
                </PieChart>
              </ResponsiveContainer>
            )}
            
            {/* Center percentage default rate */}
            <div className="absolute text-center mt-3.5">
              <span className="block text-2xl font-black font-mono text-red-500">{(defaultRate * 100).toFixed(1)}%</span>
              <span className="text-[9px] uppercase font-mono tracking-widest text-slate-400 font-bold block leading-none">Default Rate</span>
            </div>
          </div>

          {/* Ledger visual indicators */}
          <div className="space-y-1 text-xs pt-2 border-t border-gray-50 flex-col flex shrink-0">
            {statusPieData.map((item, idx) => (
              <div key={idx} className="flex justify-between items-center text-[11px] font-medium text-slate-700">
                <div className="flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full" style={{ backgroundColor: item.color }} />
                  <span>{item.name}</span>
                </div>
                <span className="font-bold font-mono text-slate-900">{item.value} ({((item.value / filteredRecords.length) * 100).toFixed(0)}%)</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Branch metrics distribution bar comparison */}
        <div className="rounded-xl border border-gray-200 bg-white p-5 shadow-sm space-y-4">
          <div>
            <h3 className="text-xs font-bold font-sans text-gray-800 uppercase tracking-widest font-mono">Branch Comparison Benchmarks</h3>
            <p className="text-[10px] text-gray-400 font-medium">Performance ranking of physical branches based on total investments and margins</p>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={branchChartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F1F5F9" />
                <XAxis dataKey="name" stroke="#94A3B8" fontSize={10} />
                <YAxis stroke="#94A3B8" fontSize={10} />
                <Tooltip contentStyle={{ fontSize: '11px', borderRadius: '4px' }} />
                <Legend wrapperStyle={{ fontSize: '9px', fontWeight: 'bold' }} />
                <Bar dataKey="Disbursed" fill="#F59E0B" radius={[4, 4, 0, 0]} name="Disbursed (Outflows)" />
                <Bar dataKey="Recovered" fill="#10B981" radius={[4, 4, 0, 0]} name="Recovered (Inflows)" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Alarm and Alerts triggers list */}
        <div className="rounded-xl border border-gray-200 bg-white p-5 shadow-sm space-y-4 flex flex-col justify-start">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xs font-bold font-sans text-gray-800 uppercase tracking-widest font-mono">Live Automated Alerts ({filteredAlerts.length})</h3>
              <p className="text-[10px] text-gray-400 font-medium">Active indicators triggering credit and operational safety alarms</p>
            </div>
            <button
              onClick={() => onNavigateToTab('sheet-analyzer')}
              className="text-[10px] font-bold text-blue-600 hover:underline"
            >
              Configure Alerters
            </button>
          </div>

          {filteredAlerts.length === 0 ? (
            <div className="flex-1 py-10 border border-dashed border-gray-150 rounded-xl flex items-center justify-center text-xs text-slate-400">
              No active warnings or alerts on current parameters.
            </div>
          ) : (
            <div className="space-y-2.5 max-h-64 overflow-y-auto">
              {filteredAlerts.map((a) => {
                const isCrit = a.severity === 'Critical';
                return (
                  <div key={a.id} className={`rounded-lg border p-3 text-xs ${
                    isCrit 
                      ? 'border-red-100 bg-red-50/20 text-red-900' 
                      : 'border-amber-100 bg-amber-50/25 text-amber-900'
                  }`}>
                    <div className="flex items-center gap-1.5 font-bold mb-1">
                      <AlertTriangle className={`h-4 w-4 shrink-0 ${isCrit ? 'text-red-500' : 'text-amber-500'}`} />
                      <span>{a.title}</span>
                    </div>
                    <p className="text-slate-650 leading-relaxed font-sans">{a.description}</p>
                    <div className="mt-1.5 flex items-center justify-between text-[9px] font-mono text-slate-400">
                      <span>{a.branchName || 'Central'}</span>
                      <span>{a.timestamp}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* ADMISSIONS & PEERS WORKFLOW FEED FOR ADMINS */}
      {isAdmin && (
        <div className="rounded-xl border border-gray-200 bg-white p-5 shadow-sm space-y-4">
          <div>
            <h3 className="text-xs font-bold font-sans text-gray-800 uppercase tracking-widest font-mono">Central Administrative Oversight</h3>
            <p className="text-[10px] text-gray-400 font-medium">Physical employee rosters, live logins, and credit logging operations</p>
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            {/* Registered Officers list */}
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-2 font-mono">Registered Office Employees ({users.length})</span>
              <div className="space-y-2 border border-slate-100 rounded-lg p-2.5 bg-slate-50/40 divide-y divide-slate-100">
                {users.map((u) => (
                  <div key={u.id} className="flex justify-between items-center py-2 text-xs">
                    <div className="flex items-center gap-2">
                      <div className="h-7 w-7 bg-blue-100 text-blue-700 font-bold rounded flex items-center justify-center shrink-0">
                        {u.name.charAt(0)}
                      </div>
                      <div>
                        <span className="block font-bold text-slate-800 truncate max-w-28">{u.name}</span>
                        <span className="block text-[9px] text-gray-400 leading-none">{u.position} ({u.branch})</span>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="inline-flex rounded-full bg-slate-100 border border-slate-200 px-2 py-0.2 text-[9px] font-mono text-slate-600 uppercase font-black">
                        {u.role}
                      </span>
                      <span className="block text-[8px] text-slate-400 font-mono mt-0.5 mt-1">{u.email}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Audit compliance activities */}
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-2 font-mono">Live Administrative Logins</span>
              <div className="space-y-2 border border-slate-100 rounded-lg p-2.5 bg-slate-50/40">
                {audits.slice(0, 5).map((aud) => (
                  <div key={aud.id} className="text-xs pt-1.5 pb-1 border-b border-gray-150 last:border-none">
                    <div className="flex items-center justify-between text-[11px] font-bold text-slate-900 leading-tight">
                      <span>{aud.userName}</span>
                      <span className="font-mono font-normal text-slate-400 text-[9px]">{new Date(aud.timestamp).toISOString().replace('T', ' ').substring(0, 16)}</span>
                    </div>
                    <p className="text-[10.5px] text-slate-600 mt-0.5 leading-normal font-medium">{aud.action}</p>
                    {aud.ipAddress && (
                      <span className="text-[8px] font-mono text-slate-400 block mt-0.5">Vetted Node IP: {aud.ipAddress}</span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* DETAILED LEDGERS LOGS GRID TABLE */}
      <div className="rounded-xl border border-gray-200 bg-white p-5 shadow-sm space-y-4">
        
        {/* INTERACTIVE SEARCH & EXPORT HUD */}
        <div className="bg-[#00923A]/5 border border-[#00923A]/15 p-4 rounded-xl space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h4 className="text-xs font-black text-[#00923A] uppercase tracking-wider flex items-center gap-1.5 font-sans">
                <Search className="h-4 w-4" />
                🏛️ Live Multi-Format Ledger Search Console
              </h4>
              <p className="text-[10px] text-gray-500 font-medium mt-0.5">
                Admin Audit Desk: Query dates, loan names, operating branches, collections, banked, disbursements, and export reports in PDF, CSV, or JSON.
              </p>
            </div>
            {globalSearchQuery && (
              <div className="flex items-center gap-2 bg-white px-2.5 py-1 rounded border border-[#00923A]/20">
                <span className="text-[9px] font-bold font-mono text-[#00923A] uppercase">Active Search Results:</span>
                <span className="text-[9.5px] font-bold text-slate-700 font-mono">
                  {queryMatchedRecords.length} Txns • {queryMatchedCashFlows.length} Balanced Days
                </span>
              </div>
            )}
          </div>

          <div className="flex flex-col md:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-[#00923A]" />
              <input
                type="text"
                value={globalSearchQuery}
                onChange={(e) => setGlobalSearchQuery(e.target.value)}
                placeholder="Type and query any date (e.g. 2026-05-26), loanee name, branch name, collection/received amount..."
                className="w-full pl-9 pr-8 py-2 bg-white text-xs text-slate-900 rounded-lg border border-gray-300 focus:border-[#00923A] focus:ring-1 focus:ring-[#00923A] outline-none transition-colors font-medium font-sans"
              />
              {globalSearchQuery && (
                <button
                  type="button"
                  onClick={() => setGlobalSearchQuery('')}
                  className="absolute right-3 top-2.5 text-gray-400 hover:text-red-500 transition-colors cursor-pointer"
                >
                  <X className="h-4 w-4" />
                </button>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={handleDownloadStandaloneReport}
                className="inline-flex h-9 items-center gap-1.5 rounded-lg bg-[#00923A] text-white hover:bg-emerald-700 font-sans font-bold text-xs px-3.5 shadow-sm hover:shadow active:scale-97 transition-all leading-none cursor-pointer"
                title="Generates a robust printable HTML document optimized for high-fidelity vector printing of the filtered dataset"
              >
                <Printer className="h-3.5 w-3.5" />
                <span>PDF Print Hub</span>
              </button>

              <button
                type="button"
                onClick={handleExportCSV}
                className="inline-flex h-9 items-center gap-1.5 rounded-lg bg-white border border-[#00923A] text-[#00923A] hover:bg-[#00923A]/5 font-sans font-bold text-xs px-3.5 hover:shadow active:scale-97 transition-all leading-none cursor-pointer"
                title="Saves matched records to standard CSV"
              >
                <Download className="h-3.5 w-3.5" />
                <span>Export CSV</span>
              </button>

              <button
                type="button"
                onClick={handleExportJSON}
                className="inline-flex h-9 items-center gap-1.5 rounded-lg bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 font-sans font-bold text-xs px-3.5 transition-all leading-none cursor-pointer"
                title="Saves system datastore as JSON payloads"
              >
                <FileText className="h-3.5 w-3.5" />
                <span>Export JSON</span>
              </button>
            </div>
          </div>

          {/* Preset Buttons */}
          <div className="flex flex-wrap items-center gap-1.5 pt-1 text-[10px]">
            <span className="text-gray-400 font-bold uppercase tracking-wide">Quick Query Suggestions:</span>
            {['Lilongwe', 'Zomba', 'Blantyre', 'Mzuzu', 'On Time', 'Delayed', 'Default'].map(tag => (
              <button
                type="button"
                key={tag}
                onClick={() => setGlobalSearchQuery(tag)}
                className={`px-2 py-0.5 rounded border text-[9px] font-bold transition-all cursor-pointer ${
                  globalSearchQuery === tag
                    ? 'bg-[#00923A] text-white border-[#00923A]'
                    : 'bg-white text-gray-500 border-gray-200 hover:border-[#00923A] hover:text-[#00923A]'
                }`}
              >
                {tag}
              </button>
            ))}
            {globalSearchQuery && (
              <button
                type="button"
                onClick={() => setGlobalSearchQuery('')}
                className="ml-2 text-red-600 hover:underline font-black uppercase text-[9px] tracking-widest cursor-pointer"
              >
                [Clear Filter]
              </button>
            )}
          </div>
        </div>

        {globalSearchQuery.trim() !== '' ? (
          <div className="space-y-6 pt-2">
            {/* Split layout or stacked tables for the matches */}
            <div className="space-y-6">
              {/* 📑 SUMMARY DAILY BALANCE SHEETS OF VAULT LIQUIDITY */}
              <div className="space-y-3">
                <div className="flex items-center justify-between border-b border-[#00923A]/20 pb-1.5">
                  <h4 className="text-[11.5px] font-black uppercase tracking-wider text-[#00923A] flex items-center gap-1.5 font-sans">
                    <span className="h-2 w-2 rounded-full bg-[#00923A] animate-pulse" />
                    1. Matched Daily Vault Cash Flow Balance Sheets summaries ({queryMatchedCashFlows.length})
                  </h4>
                  <span className="text-[9px] font-mono text-slate-400 font-bold">Chronological Cash Flow Projection</span>
                </div>

                {queryMatchedCashFlows.length === 0 ? (
                  <div className="py-8 border border-dashed border-gray-150 rounded-xl text-center text-xs text-gray-400">
                    No matching daily balance summaries found.
                  </div>
                ) : (
                  <div className="overflow-x-auto border border-gray-150 rounded-xl">
                    <table className="w-full text-left text-xs text-slate-700 border-collapse">
                      <thead>
                        <tr className="bg-[#00923A]/5 border-b border-[#00923A]/10 font-mono text-[9px] text-[#00923A] uppercase tracking-wider select-none font-bold">
                          <th className="px-4 py-2.5">Date Sheet</th>
                          <th className="px-4 py-2.5 text-right">Opening Cash</th>
                          <th className="px-4 py-2.5 text-right text-emerald-700 font-bold">Collections (Inflows)</th>
                          <th className="px-4 py-2.5 text-right text-amber-500 font-bold">Disbursements (Outflows)</th>
                          <th className="px-4 py-2.5 text-right">Banked Portion</th>
                          <th className="px-4 py-2.5 text-right font-black text-slate-900">Closing vault Cash</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-150">
                        {queryMatchedCashFlows.map((cf) => (
                          <tr key={cf.date} className="hover:bg-slate-50 transition-colors font-medium text-slate-800">
                            <td className="px-4 py-3 font-mono font-bold text-[#00923A]">{cf.date}</td>
                            <td className="px-4 py-3 text-right font-mono">MWK {cf.opening.toLocaleString()}</td>
                            <td className="px-4 py-3 text-right font-mono text-emerald-600 font-bold">MWK {cf.collected.toLocaleString()}</td>
                            <td className="px-4 py-3 text-right font-mono text-slate-500">MWK {cf.disbursed.toLocaleString()}</td>
                            <td className="px-4 py-3 text-right font-mono text-amber-600">MWK {cf.banked.toLocaleString()}</td>
                            <td className="px-4 py-3 text-right font-mono font-bold text-slate-950">MWK {cf.closing.toLocaleString()}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>

              {/* 📋 INDIVIDUAL TRANSACTION LOG MATCHES */}
              <div className="space-y-3">
                <div className="flex items-center justify-between border-b border-[#00923A]/20 pb-1.5">
                  <h4 className="text-[11.5px] font-black uppercase tracking-wider text-[#00923A] flex items-center gap-1.5 font-sans">
                    <span className="h-2 w-2 rounded-full bg-[#00923A] animate-pulse" />
                    2. Matched Individual Journal Ledger Credit Liabilities ({queryMatchedRecords.length})
                  </h4>
                  <span className="text-[9px] font-mono text-slate-400 font-bold">Detailed Audit Transactions</span>
                </div>

                {queryMatchedRecords.length === 0 ? (
                  <div className="py-8 border border-dashed border-gray-150 rounded-xl text-center text-xs text-gray-400">
                    No matching loan records found.
                  </div>
                ) : (
                  <div className="overflow-x-auto border border-gray-150 rounded-xl">
                    <table className="w-full text-left text-xs text-slate-700 border-collapse">
                      <thead>
                        <tr className="bg-slate-50 border-b border-gray-150 font-mono text-[9px] text-[#00923A] uppercase tracking-wider select-none font-bold">
                          <th className="px-4 py-3">Loanee Borrower</th>
                          <th className="px-4 py-3">Reporting Operating Station</th>
                          <th className="px-4 py-3 text-right">Disbursed (MWK)</th>
                          <th className="px-4 py-3 text-right">Expected (MWK)</th>
                          <th className="px-4 py-3 text-right text-emerald-600 font-bold">Recovered (MWK)</th>
                          <th className="px-4 py-3 text-center">Status</th>
                          {isAdmin && <th className="px-4 py-3 text-center">Actions</th>}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-150">
                        {queryMatchedRecords.map((r) => {
                          const statColor = r.status === 'On Time' 
                            ? 'text-emerald-700 bg-emerald-50 border-emerald-100/60' 
                            : r.status === 'Delayed' 
                              ? 'text-[#F59E0B] bg-amber-50 border-amber-100/60' 
                              : 'text-red-700 bg-red-50 border-red-100/60';
                          return (
                            <tr key={r.id} className="hover:bg-slate-50 transition-colors font-medium text-slate-800">
                              <td className="px-4 py-3 font-sans font-bold text-slate-900">{r.borrowerName}</td>
                              <td className="px-4 py-3 font-semibold text-slate-500">{r.branchName}</td>
                              <td className="px-4 py-3 text-right font-mono font-bold whitespace-nowrap">MWK {r.amountDisbursed.toLocaleString()}</td>
                              <td className="px-4 py-3 text-right font-mono text-slate-500 whitespace-nowrap">MWK {r.expectedRepayment.toLocaleString()}</td>
                              <td className="px-4 py-3 text-right font-mono font-bold text-[#00923A] whitespace-nowrap">MWK {r.actualRepayment.toLocaleString()}</td>
                              <td className="px-4 py-3 text-center">
                                <span className={`inline-flex rounded border px-2 py-0.5 text-[10px] font-bold ${statColor}`}>
                                  {r.status}
                                </span>
                              </td>
                              {isAdmin && (
                                <td className="px-4 py-3 text-center">
                                  <div className="flex items-center justify-center gap-1.5">
                                    <button
                                      type="button"
                                      onClick={() => handleStartEditRecord(r)}
                                      className="p-1 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors cursor-pointer"
                                      title="Edit record details"
                                    >
                                      <Edit2 className="h-3.5 w-3.5" />
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => handleDeleteRecordClick(r)}
                                      className="p-1 text-slate-500 hover:text-red-650 text-slate-500 hover:text-red-600 hover:bg-red-50 rounded transition-colors cursor-pointer"
                                      title="Delete this record"
                                    >
                                      <Trash2 className="h-3.5 w-3.5" />
                                    </button>
                                  </div>
                                </td>
                              )}
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
          </div>
        ) : (
          <>
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <h3 className="text-xs font-bold font-sans text-gray-800 uppercase tracking-widest font-mono font-black text-slate-805">Aggregated Microfinance Ledger Journal</h3>
                <p className="text-[10px] text-gray-400">Vetted credit records populated by active sheet linkages and direct CSV uploads</p>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold text-slate-500 font-sans uppercase">Record Count: <strong className="font-mono">{filteredRecords.length} units</strong></span>
              </div>
            </div>

        {filteredRecords.length === 0 ? (
          <div className="py-20 border border-dashed border-gray-150 rounded-xl text-center text-gray-400">
            <Briefcase className="h-8 w-8 mx-auto text-slate-300 mb-2" />
            <p className="text-xs font-bold text-slate-755 text-slate-700">Audit Desk is Clear</p>
            <p className="text-[10px] text-slate-405 mt-1 max-w-xs mx-auto text-slate-400 leading-normal">
              Please visit the Sheets & AI Analyzer portal to connect Google sheet journals or load CSV lists.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto border border-gray-150 rounded-xl">
            <table className="w-full text-left text-xs text-slate-700 border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-gray-150 font-mono text-[9px] text-slate-500 uppercase tracking-wider select-none">
                  <th className="px-4 py-3">Loanee Borrower</th>
                  {isAdmin && <th className="px-4 py-3">Reporting Station</th>
                   ? <th className="px-4 py-3">Operating Station</th> : <th className="px-4 py-3">Operating Station</th>}
                  <th className="px-4 py-3 text-right">Disbursed (MWK)</th>
                  <th className="px-4 py-3 text-right">Expected (MWK)</th>
                  <th className="px-4 py-3 text-right">Recovered Received (MWK)</th>
                  <th className="px-4 py-3 text-center">Audit Status</th>
                  {isAdmin && <th className="px-4 py-3 text-center">Actions</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-150">
                {filteredRecords.map((r) => {
                  const statColor = r.status === 'On Time' 
                    ? 'text-emerald-700 bg-emerald-50 border-emerald-100/60' 
                    : r.status === 'Delayed' 
                      ? 'text-amber-700 bg-amber-50 border-amber-100/60' 
                      : 'text-red-700 bg-red-50 border-red-100/60';
                  return (
                    <tr key={r.id} className="hover:bg-slate-50 transition-colors font-medium text-slate-800">
                      <td className="px-4 py-3 font-sans font-bold text-slate-900">{r.borrowerName}</td>
                      <td className="px-4 py-3 font-semibold text-slate-500">{r.branchName}</td>
                      <td className="px-4 py-3 text-right font-mono font-bold whitespace-nowrap">MWK {r.amountDisbursed.toLocaleString()}</td>
                      <td className="px-4 py-3 text-right font-mono text-slate-500 whitespace-nowrap">MWK {r.expectedRepayment.toLocaleString()}</td>
                      <td className="px-4 py-3 text-right font-mono font-bold text-emerald-600 whitespace-nowrap">MWK {r.actualRepayment.toLocaleString()}</td>
                      <td className="px-4 py-3 text-center">
                        <span className={`inline-flex rounded border px-2 py-0.5 text-[10px] font-bold ${statColor}`}>
                          {r.status}
                        </span>
                      </td>
                      {isAdmin && (
                        <td className="px-4 py-3 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            <button
                              onClick={() => handleStartEditRecord(r)}
                              className="p-1 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors"
                              title="Edit record details"
                            >
                              <Edit2 className="h-3.5 w-3.5" />
                            </button>
                            <button
                              onClick={() => handleDeleteRecordClick(r)}
                              className="p-1 text-slate-500 hover:text-red-600 hover:bg-red-50 rounded transition-colors"
                              title="Delete this record"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        </td>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
          </>
        )}
      </div>

      {/* RECORD EDITING DIALOG MODAL */}
      {editingRecord && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-slate-100 overflow-hidden relative my-8 text-left">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100 bg-slate-50">
              <h3 className="text-xs font-bold uppercase tracking-wider font-mono text-gray-700 flex items-center gap-1.5 font-sans">
                <Edit2 className="h-4 w-4 text-blue-600" />
                Edit Credit Ledger Record
              </h3>
              <button 
                onClick={() => setEditingRecord(null)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-full hover:bg-slate-100 transition-colors"
                type="button"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <form onSubmit={handleSaveRecord} className="p-6 space-y-4">
              <div>
                <label className="block text-[10px] font-bold uppercase text-gray-500 mb-1">Loanee Borrower</label>
                <input
                  type="text"
                  required
                  value={editBorrowerName}
                  onChange={(e) => setEditBorrowerName(e.target.value)}
                  className="w-full rounded-lg border border-gray-350 bg-white px-3 py-2 text-xs font-semibold text-gray-800 outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition-all"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase text-gray-500 mb-1">Reporting Operating Station</label>
                <select
                  required
                  value={editBranchName}
                  onChange={(e) => setEditBranchName(e.target.value)}
                  className="w-full rounded-lg border border-gray-350 bg-white px-3 py-2 text-xs font-semibold text-gray-800 outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition-all"
                >
                  <option value="" disabled>Select Branch</option>
                  {branches.map(b => (
                    <option key={b.id} value={b.name}>{b.name}</option>
                  ))}
                  {!branches.some(b => b.name === editBranchName) && editBranchName && (
                    <option value={editBranchName}>{editBranchName}</option>
                  )}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold uppercase text-gray-500 mb-1">Disbursed Amount (MWK)</label>
                  <input
                    type="number"
                    required
                    min={0}
                    value={editAmountDisbursed}
                    onChange={(e) => setEditAmountDisbursed(Number(e.target.value))}
                    className="w-full rounded-lg border border-gray-350 bg-white px-3 py-2 text-xs font-semibold text-gray-800 outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition-all font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold uppercase text-gray-500 mb-1">Expected Repayment (MWK)</label>
                  <input
                    type="number"
                    required
                    min={0}
                    value={editExpectedRepayment}
                    onChange={(e) => setEditExpectedRepayment(Number(e.target.value))}
                    className="w-full rounded-lg border border-gray-350 bg-white px-3 py-2 text-xs font-semibold text-gray-800 outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition-all font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold uppercase text-gray-500 mb-1">Recovered Repayment (MWK)</label>
                  <input
                    type="number"
                    required
                    min={0}
                    value={editActualRepayment}
                    onChange={(e) => setEditActualRepayment(Number(e.target.value))}
                    className="w-full rounded-lg border border-gray-355 bg-white px-3 py-2 text-xs font-semibold text-gray-800 outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition-all font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold uppercase text-gray-500 mb-1">Interest Rate (%)</label>
                  <input
                    type="number"
                    required
                    min={0}
                    max={100}
                    value={editInterestRate}
                    onChange={(e) => setEditInterestRate(Number(e.target.value))}
                    className="w-full rounded-lg border border-gray-350 bg-white px-3 py-2 text-xs font-semibold text-gray-800 outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition-all font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold uppercase text-gray-500 mb-1">Overhead Expenses (MWK)</label>
                  <input
                    type="number"
                    required
                    min={0}
                    value={editExpenses}
                    onChange={(e) => setEditExpenses(Number(e.target.value))}
                    className="w-full rounded-lg border border-gray-350 bg-white px-3 py-2 text-xs font-semibold text-gray-800 outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition-all font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold uppercase text-gray-500 mb-1">Audit Status</label>
                  <select
                    value={editStatus}
                    onChange={(e) => setEditStatus(e.target.value as any)}
                    className="w-full rounded-lg border border-gray-350 bg-white px-3 py-2 text-xs font-semibold text-gray-800 outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition-all"
                  >
                    <option value="On Time">On Time</option>
                    <option value="Delayed">Delayed</option>
                    <option value="Default">Default</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center gap-2 justify-end pt-3 border-t border-gray-100">
                <button
                  type="button"
                  onClick={() => setEditingRecord(null)}
                  className="rounded-lg border border-gray-200 px-4 py-2 text-xs font-bold text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-lg bg-blue-600 hover:bg-blue-700 px-4 py-2 text-xs font-bold text-white shadow-md active:scale-97 transition-all"
                >
                  Save Credit Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
