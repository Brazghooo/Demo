import React, { useState, useEffect } from 'react';
import {
  Menu,
  Bell,
  ChevronDown,
  LogOut,
  User,
  ShieldCheck,
  FileSpreadsheet,
  RefreshCw,
  Clock,
  Sun,
  Moon
} from 'lucide-react';
import { User as UserType, AlertNotification } from '../types';

interface HeaderProps {
  onMenuToggle: () => void;
  currentUser: UserType | null;
  alerts: AlertNotification[];
  onMarkNotificationRead: (id: string) => void;
  onNavigateToTab: (tab: string) => void;
  onLogout: () => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
}

export default function Header({
  onMenuToggle,
  currentUser,
  alerts,
  onMarkNotificationRead,
  onNavigateToTab,
  onLogout,
  darkMode,
  onToggleDarkMode
}: HeaderProps) {
  const [profileOpen, setProfileOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [systemTime, setSystemTime] = useState('2026-05-23 09:25:44Z');

  // Live clock synced to the metadata format
  useEffect(() => {
    const updateTime = () => {
      const date = new Date();
      const format = date.toISOString().replace('T', ' ').substring(0, 19).concat('Z');
      setSystemTime(format);
    };
    updateTime();
    const tick = setInterval(updateTime, 1000);
    return () => clearInterval(tick);
  }, []);

  // Filter unread alerts
  const unreadAlerts = alerts.filter(a => !a.isRead);

  return (
    <header
      id="header-app"
      className="sticky top-0 z-30 flex h-16 w-full items-center justify-between border-b border-gray-200 bg-white/95 px-6 backdrop-blur-md shrink-0"
    >
      {/* Menu burger & search placeholder / active branch breadcrumb */}
      <div className="flex items-center gap-4">
        <button
          id="mobile-sidebar-toggle"
          onClick={onMenuToggle}
          className="rounded-lg p-1.5 text-gray-500 hover:bg-gray-150 hover:text-gray-900 lg:hidden"
          aria-label="Toggle Sidebar"
        >
          <Menu className="h-5 w-5" />
        </button>

        <div className="flex items-center gap-2">
          <span className="inline-flex h-2.5 w-2.5 rounded-full bg-blue-500 animate-pulse" />
          <span className="font-mono text-xs font-semibold text-slate-500 uppercase tracking-widest leading-none">
            {currentUser?.role === 'Admin' ? 'Head Office' : (currentUser?.branch || 'Central Ledger Network')}
          </span>
        </div>
      </div>

      {/* Action Indicators & Profiles */}
      <div className="flex items-center gap-4">
        {/* Dynamic UTC Clock Indicator fitting for global audit */}
        <div className="hidden items-center gap-1.5 font-mono text-xs font-medium text-gray-500 bg-gray-100/90 border border-gray-200/60 px-3 py-1.2 rounded-md sm:flex">
          <Clock className="h-3.5 w-3.5 text-blue-500" />
          <span>{systemTime}</span>
        </div>

        {/* Dynamic theme switcher switch button */}
        <button
          onClick={onToggleDarkMode}
          className="rounded-lg p-1.5 text-gray-500 hover:bg-gray-150 transition-colors flex items-center justify-center border border-transparent hover:border-gray-200 bg-gray-100/50"
          title={darkMode ? 'Switch to Light Presets' : 'Switch to Dark Mode'}
          aria-label="Toggle theme profile"
        >
          {darkMode ? (
            <div className="flex items-center gap-1.5 px-0.5 text-amber-500 font-bold font-mono text-[10.5px]">
              <Sun className="h-3.8 w-3.8" />
              <span className="hidden sm:inline uppercase tracking-widest text-[9px]">LIGHT</span>
            </div>
          ) : (
            <div className="flex items-center gap-1.5 px-0.5 text-blue-500 font-bold font-mono text-[10.5px]">
              <Moon className="h-3.8 w-3.8" />
              <span className="hidden sm:inline uppercase tracking-widest text-[9px]">DARK</span>
            </div>
          )}
        </button>

        {/* Audit Notifications Alarm Bell */}
        <div className="relative">
          <button
            id="notifications-dropdown-toggle"
            onClick={() => {
              setNotificationsOpen(!notificationsOpen);
              setProfileOpen(false);
            }}
            className="relative rounded-lg p-2 text-gray-500 hover:bg-gray-100 hover:text-gray-900 transition-colors"
          >
            <Bell className="h-4.5 w-4.5" />
            {unreadAlerts.length > 0 && (
              <span className="absolute top-1 right-1 flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-red-400 opacity-75"></span>
                <span className="relative inline-flex h-2 w-2 rounded-full bg-red-600"></span>
              </span>
            )}
          </button>

          {notificationsOpen && (
            <div className="absolute right-0 mt-2 w-80 origin-top-right rounded-xl border border-gray-200 bg-white p-2 shadow-lg ring-1 ring-black/5 z-55 max-h-120 overflow-y-auto">
              <div className="px-3 py-2 border-b border-gray-100 mb-1.5 flex items-center justify-between">
                <span className="text-xs font-bold text-gray-800">Critical Alarms & Activity ({unreadAlerts.length})</span>
                <span className="text-[10px] text-gray-400 font-mono tracking-wider uppercase font-bold">Risk Triggers</span>
              </div>
              
              <div className="space-y-1.5">
                {alerts.length === 0 ? (
                  <p className="text-center py-4 text-xs text-slate-400">All metrics operational. No alerts found.</p>
                ) : (
                  alerts.slice(0, 10).map((a) => {
                    const sevColor = a.severity === 'Critical' 
                      ? 'border-red-200 bg-red-50/60 text-red-900' 
                      : a.severity === 'Warning' 
                        ? 'border-amber-200 bg-amber-50/40 text-amber-900' 
                        : 'border-blue-100 bg-blue-50/20 text-blue-900';
                    return (
                      <div
                        key={a.id}
                        onClick={() => onMarkNotificationRead(a.id)}
                        className={`group relative flex flex-col rounded-lg border p-2.5 text-left text-xs cursor-pointer transition-colors ${sevColor} ${
                          a.isRead ? 'opacity-55 hover:opacity-100 border-gray-150' : ''
                        }`}
                      >
                        <div className="flex items-start justify-between font-bold">
                          <span>{a.title}</span>
                          {!a.isRead && (
                            <span className="h-1.5 w-1.5 rounded-full bg-red-600 shrink-0 ml-1.5 mt-1" />
                          )}
                        </div>
                        <p className="mt-1 text-slate-650 leading-relaxed font-sans font-medium">{a.description}</p>
                        <div className="mt-1.5 flex items-center justify-between text-[9px] font-mono text-slate-500">
                          <span>{a.branchName || 'System'}</span>
                          <span>{a.timestamp}</span>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
              <div className="border-t border-gray-100 mt-2 pt-1.5 text-center">
                <button
                  onClick={() => {
                    onNavigateToTab('sheet-analyzer');
                    setNotificationsOpen(false);
                  }}
                  className="text-[11px] font-bold text-blue-600 hover:underline"
                >
                  Configure AI Alerters inside Analyzer
                </button>
              </div>
            </div>
          )}
        </div>

        {/* User Dropdown Profile Action Menu */}
        <div className="relative">
          <button
            id="user-profile-menu-toggle"
            onClick={() => {
              setProfileOpen(!profileOpen);
              setNotificationsOpen(false);
            }}
            className="flex items-center gap-2.5 rounded-lg p-1.5 text-left transition-colors hover:bg-gray-100"
          >
            <div className="relative h-8 w-8 overflow-hidden rounded-lg bg-blue-100 text-blue-700 font-bold flex items-center justify-center border border-blue-200 shadow-sm font-sans uppercase">
              {currentUser?.name.charAt(0)}
              <span className="absolute bottom-0 right-0 h-2 w-2 rounded-full bg-emerald-500 border-2 border-white" />
            </div>
            <div className="hidden lg:block">
              <div className="text-xs font-bold text-gray-900 leading-tight truncate max-w-28 uppercase">{currentUser?.name}</div>
              <div className="text-[10px] text-gray-400 font-mono tracking-wider leading-none mt-0.5">{currentUser?.role} Member</div>
            </div>
            <ChevronDown className="h-3.5 w-3.5 text-gray-400" />
          </button>

          {profileOpen && (
            <div className="absolute right-0 mt-2 w-56 origin-top-right rounded-xl border border-gray-200 bg-white p-1.5 shadow-lg ring-1 ring-black/5 z-55">
              <div className="px-3 py-2 border-b border-gray-100 mb-1.5">
                <p className="text-[9px] font-bold font-mono text-slate-400 tracking-wider uppercase">{currentUser?.position}</p>
                <p className="text-xs font-semibold text-gray-800 truncate mt-0.5">{currentUser?.email}</p>
              </div>
              <div className="space-y-0.5">
                <button
                  onClick={() => {
                    onNavigateToTab('branches-staff');
                    setProfileOpen(false);
                  }}
                  className="flex w-full items-center gap-2.5 rounded-lg px-2.5 py-1.8 text-left text-xs font-semibold text-gray-750 hover:bg-gray-50 transition-colors"
                >
                  <User className="h-3.8 w-3.8 text-gray-400" />
                  <span>Branch Colleagues</span>
                </button>
                <button
                  onClick={() => {
                    onNavigateToTab('system-settings');
                    setProfileOpen(false);
                  }}
                  className="flex w-full items-center gap-2.5 rounded-lg px-2.5 py-1.8 text-left text-xs font-semibold text-gray-750 hover:bg-gray-50 transition-colors"
                >
                  <FileSpreadsheet className="h-3.8 w-3.8 text-gray-400" />
                  <span>Export Ledgers</span>
                </button>
                <div className="h-px bg-gray-100 my-1.5" />
                <button
                  onClick={() => {
                    setProfileOpen(false);
                    onLogout();
                  }}
                  className="flex w-full items-center gap-2.5 rounded-lg px-2.5 py-1.8 text-left text-xs font-bold text-red-600 hover:bg-red-50 transition-colors"
                >
                  <LogOut className="h-3.8 w-3.8 text-red-500" />
                  <span>Sign Out Session</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
