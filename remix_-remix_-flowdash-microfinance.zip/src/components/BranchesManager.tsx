import React, { useState } from 'react';
import { Network, Building, UserPlus, ShieldAlert, KeyRound, Plus, Trash2, Edit2, ShieldCheck, Mail, Phone, MapPin } from 'lucide-react';
import { Branch, User } from '../types';

interface BranchesManagerProps {
  branches: Branch[];
  onAddBranch: (newBranch: Branch) => void;
  onDeleteBranch: (branchId: string) => void;
  onUpdateBranch: (updatedBranch: Branch) => void;
  users: User[];
  onUpdateUserRoleAndPermissions: (userId: string, role: User['role'], permissions: string[]) => void;
  onDeleteUser: (userId: string) => void;
  onUpdateUser: (updatedUser: User) => void;
  currentUser: User | null;
  onRunAuditLog: (action: string) => void;
}

export const COMM_PERMISSIONS = [
  { val: 'upload_reports', name: 'Upload Microfinance Reports' },
  { val: 'add_sheets', name: 'Insert Google Sheets Connections' },
  { val: 'view_branch_analytics', name: 'View Local Branch Metrics' },
  { val: 'update_tasks', name: 'Update Duties Progress' },
  { val: 'manage_branches', name: 'Operational Administration (Create Branches / Employees)' },
  { val: 'export_data', name: 'Export Journal Ledgers (CSV / PDF)' }
];

export default function BranchesManager({
  branches,
  onAddBranch,
  onDeleteBranch,
  onUpdateBranch,
  users,
  onUpdateUserRoleAndPermissions,
  onDeleteUser,
  onUpdateUser,
  currentUser,
  onRunAuditLog
}: BranchesManagerProps) {
  const isAdmin = currentUser?.role === 'Admin';

  // Branch creation fields
  const [bName, setBName] = useState('');
  const [bLocation, setBLocation] = useState('');
  const [bCode, setBCode] = useState('');
  const [branchFeedback, setBranchFeedback] = useState<string | null>(null);

  // Branch editing fields
  const [editingBranchId, setEditingBranchId] = useState<string | null>(null);
  const [editBranchName, setEditBranchName] = useState('');
  const [editBranchLocation, setEditBranchLocation] = useState('');
  const [editBranchCode, setEditBranchCode] = useState('');

  // Editing User state
  const [editingUserId, setEditingUserId] = useState<string | null>(null);
  const [editUserName, setEditUserName] = useState('');
  const [editUserPosition, setEditUserPosition] = useState('');
  const [editUserBranch, setEditUserBranch] = useState('');
  const [editUserPhone, setEditUserPhone] = useState('');
  const [editUserEmail, setEditUserEmail] = useState('');
  const [editRole, setEditRole] = useState<User['role']>('User');
  const [editPerms, setEditPerms] = useState<string[]>([]);

  const handleCreateBranch = (e: React.FormEvent) => {
    e.preventDefault();
    setBranchFeedback(null);

    if (!bName.trim() || !bLocation.trim() || !bCode.trim()) {
      setBranchFeedback('Please complete every detail sequence.');
      return;
    }

    const collision = branches.some(b => b.code.toUpperCase() === bCode.trim().toUpperCase() || b.name.toLowerCase() === bName.trim().toLowerCase());
    if (collision) {
      setBranchFeedback('A hub with this Name or unique Code is already seeded inside the index.');
      return;
    }

    const freshBranch: Branch = {
      id: `b-${Math.floor(100 + Math.random() * 900)}`,
      name: bName.trim(),
      location: bLocation.trim(),
      code: bCode.trim().toUpperCase(),
      createdDate: new Date().toISOString().split('T')[0]
    };

    onAddBranch(freshBranch);
    onRunAuditLog(`Created physical office branch station: ${freshBranch.name} (${freshBranch.code})`);
    
    setBName('');
    setBLocation('');
    setBCode('');
    setBranchFeedback(`Station hub "${freshBranch.name}" created and online!`);
    
    setTimeout(() => setBranchFeedback(null), 3000);
  };

  const handleTogglePerm = (perm: string) => {
    if (editPerms.includes(perm)) {
      setEditPerms(editPerms.filter(p => p !== perm));
    } else {
      setEditPerms([...editPerms, perm]);
    }
  };

  const handleSaveBranchEdit = (branchId: string) => {
    if (!editBranchName.trim() || !editBranchLocation.trim() || !editBranchCode.trim()) return;
    const originalBranch = branches.find(b => b.id === branchId);
    const updated: Branch = {
      id: branchId,
      name: editBranchName.trim(),
      location: editBranchLocation.trim(),
      code: editBranchCode.trim().toUpperCase(),
      createdDate: originalBranch?.createdDate || new Date().toISOString().split('T')[0]
    };
    onUpdateBranch(updated);
    onRunAuditLog(`Updated corporate branch office details: ${updated.name} (${updated.code})`);
    setEditingBranchId(null);
  };

  const handleSaveUserPermissions = (userId: string) => {
    const userToUpdate = users.find(u => u.id === userId);
    if (userToUpdate) {
      const updated: User = {
        ...userToUpdate,
        name: editUserName.trim() || userToUpdate.name,
        position: editUserPosition.trim() || userToUpdate.position,
        branch: editUserBranch || userToUpdate.branch,
        phone: editUserPhone.trim() || userToUpdate.phone,
        email: editUserEmail.trim() || userToUpdate.email,
        role: editRole,
        permissions: editPerms
      };
      onUpdateUser(updated);
      onRunAuditLog(`Adjusted user credentials & RBAC profile for employee: ${updated.name} (${editRole})`);
    }
    setEditingUserId(null);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold font-sans text-gray-950 tracking-tight">Branches & Staff Administrative Board</h1>
        <p className="text-xs text-gray-400 font-medium">Create new company branches, adjust staff positions, and manage role-based authorization parameters (RBAC)</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Left column: Manage physical branches list & Create if Admin */}
        <div className="space-y-6 lg:col-span-1">
          {/* Create Branch panel */}
          {isAdmin ? (
            <div className="rounded-xl border border-gray-200 bg-white p-5 shadow-sm">
              <h3 className="text-xs font-bold font-sans text-gray-800 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                <Building className="h-4.5 w-4.5 text-blue-600" />
                <span>Establish Fresh Hub Branch</span>
              </h3>
              <p className="text-[11px] text-gray-400 mb-4 leading-normal">
                Expand microfinance operations network coverage by registering corporate ledger station credentials.
              </p>

              {branchFeedback && (
                <div className={`mb-3 p-2.5 rounded text-xs font-semibold ${
                  branchFeedback.includes('online') 
                    ? 'bg-emerald-50 text-emerald-800 border border-emerald-150' 
                    : 'bg-red-50 text-red-800 border border-red-150'
                }`}>
                  {branchFeedback}
                </div>
              )}

              <form onSubmit={handleCreateBranch} className="space-y-3">
                <div>
                  <label className="block text-[10px] text-gray-500 font-bold mb-1">Branch Hub Name</label>
                  <input
                    type="text"
                    required
                    value={bName}
                    onChange={(e) => setBName(e.target.value)}
                    placeholder="e.g. Kasungu Plains Outlet"
                    className="w-full rounded-lg border border-gray-250 bg-gray-50 px-3 py-2 text-xs text-gray-850 outline-none focus:border-blue-500 focus:bg-white"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-gray-500 font-bold mb-1">Physical Location Address</label>
                  <input
                    type="text"
                    required
                    value={bLocation}
                    onChange={(e) => setBLocation(e.target.value)}
                    placeholder="e.g. M1 Highway, Central Kasungu"
                    className="w-full rounded-lg border border-gray-250 bg-gray-50 px-3 py-2 text-xs text-gray-850 outline-none focus:border-blue-500 focus:bg-white"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-gray-500 font-bold mb-1">Station Network Code</label>
                  <input
                    type="text"
                    required
                    value={bCode}
                    onChange={(e) => setBCode(e.target.value)}
                    placeholder="e.g. KS-05"
                    className="w-full rounded-lg border border-gray-250 bg-gray-50 px-3 py-2 text-xs text-gray-850 outline-none focus:border-blue-500 focus:bg-white font-mono uppercase"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full h-9 inline-flex items-center justify-center gap-1.5 rounded-lg bg-blue-650 bg-blue-600 text-xs font-bold text-white hover:bg-blue-700 shadow-sm transition-all"
                >
                  <Plus className="h-4 w-4" />
                  <span>Enlist Corporate Branch</span>
                </button>
              </form>
            </div>
          ) : (
            <div className="rounded-xl border border-gray-200 bg-gray-50 p-5 text-gray-500 select-none">
              <ShieldAlert className="h-8 w-8 text-amber-500 mb-2" />
              <h4 className="text-xs font-bold text-gray-800 uppercase tracking-wider">Officer Access Profile</h4>
              <p className="text-[11px] text-gray-400 leading-normal mt-1">
                You are registered on the **{currentUser?.branch}** station site network. Access privilege parameters (RBAC) are defined by Director MCHAGUNDA.
              </p>
            </div>
          )}

          {/* Physical branches list */}
          <div className="rounded-xl border border-gray-200 bg-white p-5 shadow-sm space-y-4">
            <div>
              <h3 className="text-xs font-bold font-sans text-gray-800 uppercase tracking-wider flex items-center gap-1.5">
                <Network className="h-4.5 w-4.5 text-blue-500" />
                <span>Station Network Hubs ({branches.length})</span>
              </h3>
              <p className="text-[10px] text-gray-400">Physical microfinance offices active on ledger index</p>
            </div>

            <div className="space-y-2 max-h-76 overflow-y-auto">
              {branches.map(b => {
                const isEditingBranch = editingBranchId === b.id;
                return (
                  <div key={b.id} className="p-3 border border-gray-150 bg-gray-50/50 rounded-lg text-xs space-y-2">
                    {isEditingBranch ? (
                      <div className="space-y-2">
                        <input
                          type="text"
                          value={editBranchName}
                          onChange={(e) => setEditBranchName(e.target.value)}
                          className="w-full rounded border px-2 py-1 text-xs outline-none bg-white font-bold"
                          placeholder="Branch Name"
                        />
                        <input
                          type="text"
                          value={editBranchLocation}
                          onChange={(e) => setEditBranchLocation(e.target.value)}
                          className="w-full rounded border px-2 py-1 text-xs outline-none bg-white"
                          placeholder="Location"
                        />
                        <input
                          type="text"
                          value={editBranchCode}
                          onChange={(e) => setEditBranchCode(e.target.value)}
                          className="w-full rounded border px-2 py-1 text-xs outline-none bg-white font-mono uppercase"
                          placeholder="Code"
                        />
                        <div className="flex justify-end gap-1.5 pt-1">
                          <button
                            onClick={() => setEditingBranchId(null)}
                            className="bg-white border rounded px-2 text-[10px] font-bold text-gray-600"
                          >
                            Cancel
                          </button>
                          <button
                            onClick={() => handleSaveBranchEdit(b.id)}
                            className="bg-blue-650 bg-blue-600 text-white rounded px-2.5 text-[10px] font-bold"
                          >
                            Save
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="flex justify-between items-start gap-2">
                        <div className="flex-1 min-w-0">
                          <span className="block font-bold text-gray-950 font-sans truncate">{b.name}</span>
                          <span className="block text-[10px] text-gray-400 font-medium mt-0.5 flex items-center gap-1">
                            <MapPin className="h-3 w-3 text-slate-400 shrink-0" />
                            <span className="truncate">{b.location}</span>
                          </span>
                          <span className="block text-[8px] text-slate-400 font-mono mt-2">Active Since: {b.createdDate}</span>
                          
                          {isAdmin && (
                            <div className="flex gap-2.5 mt-2">
                              <button
                                onClick={() => {
                                  setEditingBranchId(b.id);
                                  setEditBranchName(b.name);
                                  setEditBranchLocation(b.location);
                                  setEditBranchCode(b.code);
                                }}
                                className="text-[10px] font-bold text-blue-600 hover:underline flex items-center gap-0.5"
                              >
                                <Edit2 className="h-2.5 w-2.5" />
                                Edit Details
                              </button>
                            </div>
                          )}
                        </div>
                        <div className="flex flex-col items-end justify-between self-stretch shrink-0">
                          <span className="rounded bg-blue-550/10 bg-blue-50 text-blue-600 font-mono font-bold px-1.5 py-0.5 text-[9px] border border-blue-100 uppercase">
                            {b.code}
                          </span>
                          {isAdmin && (
                            <button
                              onClick={() => {
                                if (confirm(`Are you absolutely sure you want to delete branch "${b.name}"?`)) {
                                  onDeleteBranch(b.id);
                                  onRunAuditLog(`Deleted physical office branch station: ${b.name} (${b.code})`);
                                }
                              }}
                              className="text-red-600 hover:text-red-800 border border-transparent hover:border-red-150 p-1 rounded-lg hover:bg-red-50/75 transition-all flex items-center gap-1 text-[10px] font-bold mt-2.5 shadow-sm bg-white"
                              title={`Delete ${b.name}`}
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                              <span>Delete</span>
                            </button>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right column: Manage registered team rosters and permissions (RBAC) */}
        <div className="space-y-6 lg:col-span-2">
          <div className="rounded-xl border border-gray-200 bg-white p-5 shadow-sm">
            <div>
              <h3 className="text-xs font-bold font-sans text-gray-800 uppercase tracking-wider mb-1">Company Staff Directory & RBAC Control</h3>
              <p className="text-[11px] text-gray-400">View live active employees, audit administrative clearances, and adjust functional ledger permissions</p>
            </div>

            <div className="mt-4 space-y-3">
              {users.map((u) => {
                const isTargetEditing = editingUserId === u.id;
                return (
                  <div key={u.id} className="border border-gray-150 rounded-xl p-4 bg-gray-50/30 hover:bg-white transition-all space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-4">
                      <div className="flex items-start gap-2.5">
                        <div className="h-9 w-9 bg-blue-105 bg-blue-105 bg-blue-50 text-blue-600 font-black rounded-lg flex items-center justify-center shrink-0">
                          {u.name.charAt(0)}
                        </div>
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="text-xs font-bold text-gray-950 font-sans">{u.name}</span>
                            <span className={`inline-flex rounded-full px-2 py-0.1 text-[9px] font-mono font-semibold uppercase ${
                              u.role === 'Admin' ? 'bg-red-50 text-red-600 border border-red-100' : 'bg-slate-100 text-slate-600 border'
                            }`}>
                              {u.role}
                            </span>
                          </div>
                          <span className="block text-[10px] text-gray-400 font-medium mt-0.5">{u.position} • <strong className="font-semibold text-gray-600">{u.branch}</strong></span>
                        </div>
                      </div>

                      <div className="text-right flex items-center gap-4">
                        <div className="hidden sm:block">
                          <span className="block text-[10px] tracking-wide text-gray-400 flex items-center gap-1">
                            <Mail className="h-3 w-3 text-slate-450 text-slate-400" />
                            {u.email}
                          </span>
                          <span className="block text-[9px] tracking-wide text-gray-400 mt-1 flex items-center gap-1">
                            <Phone className="h-3 w-3 text-slate-400" />
                            {u.phone}
                          </span>
                        </div>                        {/* Edit Role Permission Actions button for Directors */}
                        {isAdmin && u.name !== 'MCHAGUNDA' && (
                          <button
                            onClick={() => {
                              if (isTargetEditing) {
                                setEditingUserId(null);
                              } else {
                                setEditingUserId(u.id);
                                setEditUserName(u.name);
                                setEditUserPosition(u.position);
                                setEditUserBranch(u.branch);
                                setEditUserPhone(u.phone);
                                setEditUserEmail(u.email);
                                setEditRole(u.role);
                                setEditPerms(u.permissions);
                              }
                            }}
                            className="p-2 text-slate-500 hover:text-blue-600 hover:bg-blue-50/50 border border-gray-150 rounded-lg bg-gray-50 font-sans text-xs font-bold transition-colors inline-flex items-center gap-1"
                          >
                            <Edit2 className="h-3 w-3" />
                            <span>Edit Staff</span>
                          </button>
                        )}
                      </div>
                    </div>
 
                    {/* RENDER CURRENT USER PRIVILEGES SLIDER */}
                    {isTargetEditing ? (
                      <div className="bg-slate-50 rounded-xl p-4 border border-blue-200/50 space-y-3.5 mt-3 duration-200">
                        <div className="flex items-center justify-between border-b pb-2">
                          <span className="text-xs font-bold text-gray-850 uppercase tracking-widest font-mono flex items-center gap-1">
                            <KeyRound className="h-4 w-4 text-blue-500" />
                            Edit Staff Credentials & Access parameters: {u.name}
                          </span>
                        </div>
 
                        {/* Core Staff Attributes Fields */}
                        <div className="grid gap-3 sm:grid-cols-2">
                          <div>
                            <label className="block text-[10px] text-gray-500 font-bold mb-1">Staff Member Name</label>
                            <input
                              type="text"
                              value={editUserName}
                              onChange={(e) => setEditUserName(e.target.value)}
                              className="w-full rounded-lg border border-gray-250 bg-white px-3 py-1.8 text-xs font-medium text-gray-800 outline-none focus:border-blue-500"
                            />
                          </div>
                          <div>
                            <label className="block text-[10px] text-gray-500 font-bold mb-1">Job Position / Title</label>
                            <input
                              type="text"
                              value={editUserPosition}
                              onChange={(e) => setEditUserPosition(e.target.value)}
                              className="w-full rounded-lg border border-gray-250 bg-white px-3 py-1.8 text-xs font-medium text-gray-800 outline-none focus:border-blue-500"
                            />
                          </div>
                          <div>
                            <label className="block text-[10px] text-gray-500 font-bold mb-1">Assigned Station Branch</label>
                            <select
                              value={editUserBranch}
                              onChange={(e) => setEditUserBranch(e.target.value)}
                              className="w-full rounded-lg border border-gray-250 bg-white px-2.5 py-1.8 text-xs font-medium text-gray-800 outline-none focus:border-blue-500"
                            >
                              {branches.map(br => (
                                <option key={br.id} value={br.name}>{br.name}</option>
                              ))}
                            </select>
                          </div>
                          <div>
                            <label className="block text-[10px] text-gray-500 font-bold mb-1">Phone Number</label>
                            <input
                              type="text"
                              value={editUserPhone}
                              onChange={(e) => setEditUserPhone(e.target.value)}
                              className="w-full rounded-lg border border-gray-250 bg-white px-3 py-1.8 text-xs font-medium text-gray-800 outline-none focus:border-blue-500"
                            />
                          </div>
                          <div className="sm:col-span-2">
                            <label className="block text-[10px] text-gray-500 font-bold mb-1">Login Email Address</label>
                            <input
                              type="email"
                              value={editUserEmail}
                              onChange={(e) => setEditUserEmail(e.target.value)}
                              className="w-full rounded-lg border border-gray-250 bg-white px-3 py-1.8 text-xs font-medium text-gray-800 outline-none focus:border-blue-500"
                            />
                          </div>
                        </div>

                        {/* Adjust Core Role */}
                        <div className="grid grid-cols-2 gap-4 border-t pt-3">
                          <div>
                            <label className="block text-[10px] text-gray-500 font-bold mb-1">Functional Security Role</label>
                            <select
                              value={editRole}
                              onChange={(e) => setEditRole(e.target.value as User['role'])}
                              className="w-full rounded-lg border border-gray-200 bg-white px-2.5 py-1.5 text-xs text-gray-850 outline-none focus:border-blue-500"
                            >
                              <option value="Admin">Admin (Global Director, Branch Creator)</option>
                              <option value="User">User (Station Clerk, Loanee Reviewer)</option>
                            </select>
                          </div>
                          
                          <div className="flex items-end text-[10px] text-gray-400 leading-normal font-medium">
                            Admins hold unrestricted operational control over all physical entries. Users are restricted to their stationed branch.
                          </div>
                        </div>
 
                        {/* Adjust Permission check array */}
                        <div className="space-y-1.5 pt-2 border-t">
                          <label className="block text-[10px] text-gray-500 font-bold mb-1">Clearance Checklists</label>
                          <div className="grid gap-2 sm:grid-cols-2">
                            {COMM_PERMISSIONS.map((perm) => {
                              const checked = editPerms.includes(perm.val);
                              return (
                                <label 
                                  key={perm.val} 
                                  onClick={() => handleTogglePerm(perm.val)}
                                  className={`flex items-start gap-2 p-2 rounded-lg border text-xs cursor-pointer select-none transition-all ${
                                    checked 
                                      ? 'bg-blue-50/60 border-blue-300 text-blue-900 font-bold' 
                                      : 'bg-white border-gray-150 text-gray-650'
                                  }`}
                                >
                                  <input
                                    type="checkbox"
                                    checked={checked}
                                    readOnly
                                    className="hidden"
                                  />
                                  <span className="leading-snug">{perm.name}</span>
                                </label>
                              );
                            })}
                          </div>
                        </div>
 
                        <div className="flex justify-between items-center pt-2 border-t mt-3">
                          <button
                            onClick={() => {
                              if (confirm(`Are you 100% sure you want to completely delete "${u.name}" from the system? The employee will lose all access.`)) {
                                onDeleteUser(u.id);
                                onRunAuditLog(`Deleted staff account completely: ${u.name} (${u.email})`);
                                setEditingUserId(null);
                              }
                            }}
                            className="px-3 h-8 text-xs font-bold text-red-600 hover:bg-red-50 rounded border border-red-100 flex items-center gap-1"
                          >
                            <Trash2 className="h-3.5 w-3.5 animate-pulse" />
                            <span>Delete Staff</span>
                          </button>
                          
                          <div className="flex gap-2">
                            <button
                              onClick={() => setEditingUserId(null)}
                              className="px-3 h-8 text-xs font-semibold text-gray-600 rounded bg-white hover:bg-gray-50 border"
                            >
                              Cancel
                            </button>
                            <button
                              onClick={() => handleSaveUserPermissions(u.id)}
                              className="px-4.5 h-8 text-xs font-bold text-white rounded bg-blue-600 hover:bg-blue-500 flex items-center gap-1"
                            >
                              <ShieldCheck className="h-4 w-4" />
                              <span>Save Changes</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    ) : (
                      /* Display static user clearances checklist */
                      <div className="flex flex-wrap gap-1 pt-1.5 select-none text-[10px] font-mono font-medium">
                        {u.permissions.map((p) => {
                          const name = COMM_PERMISSIONS.find(itm => itm.val === p)?.name || p;
                          return (
                            <span key={p} className="rounded bg-slate-100 border text-slate-500 px-2 py-0.5">
                              ✓ {name}
                            </span>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
