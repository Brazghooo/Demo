import React, { useState } from 'react';
import { MessageSquare, Send, CheckCircle, Mail, Megaphone, HelpCircle, FileText, Users, Building2 } from 'lucide-react';
import { CommunicationMessage, User, Branch } from '../types';

interface TeamCommsProps {
  messages: CommunicationMessage[];
  onSendMessage: (
    senderName: string,
    senderRole: string,
    content: string,
    channel: string,
    recipientEmail?: string,
    recipientName?: string
  ) => void;
  currentUser: User | null;
  onRunAuditLog: (action: string) => void;
  users: User[];
  branches: Branch[];
}

const ALL_CHANNELS = [
  { val: 'General Announcements', icon: Megaphone, desc: 'Official institutional memos & guidelines' },
  { val: 'Vetting Support', icon: HelpCircle, desc: 'Help with Google sheet formatting and CORS issues' },
  { val: 'Default Audits', icon: FileText, desc: 'Discuss accounts under delayed repayment risk' }
];

export default function TeamComms({
  messages,
  onSendMessage,
  currentUser,
  onRunAuditLog,
  users,
  branches
}: TeamCommsProps) {
  const [activeChannel, setActiveChannel] = useState('General Announcements');
  const [typedMessage, setTypedMessage] = useState('');

  // Target audience selection fields for Admins
  const [recipientType, setRecipientType] = useState<'All' | 'Branch' | 'User'>('All');
  const [selectedBranch, setSelectedBranch] = useState('');
  const [selectedUserEmail, setSelectedUserEmail] = useState('');

  const handlePostMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!typedMessage.trim() || !currentUser) return;

    let recipientEmail = 'All';
    let recipientName = 'All Staff Office';

    if (currentUser?.role === 'Admin') {
      if (recipientType === 'Branch') {
        recipientEmail = selectedBranch;
        recipientName = selectedBranch;
      } else if (recipientType === 'User') {
        recipientEmail = selectedUserEmail;
        const u = users.find(usr => usr.email === selectedUserEmail);
        recipientName = u ? u.name : selectedUserEmail;
      }
    }

    onSendMessage(currentUser.name, currentUser.role, typedMessage.trim(), activeChannel, recipientEmail, recipientName);
    onRunAuditLog(`Posted institutional team note in [${activeChannel}] targeting [${recipientName}]`);
    setTypedMessage('');
  };

  // Standard staff only see messages sent to "All", their exact branch name, or their personal email address
  const filteredMsgs = messages.filter(m => {
    if (m.channel !== activeChannel) return false;
    if (currentUser?.role === 'Admin') return true;

    const isRecipientAll = m.recipientEmail.toLowerCase() === 'all';
    const isRecipientMyEmail = m.recipientEmail.toLowerCase() === currentUser?.email.toLowerCase();
    const isRecipientMyBranch = m.recipientEmail === currentUser?.branch || m.recipientName === currentUser?.branch;
    
    const isSentByMe = m.senderEmail.toLowerCase() === currentUser?.email.toLowerCase();

    return isRecipientAll || isRecipientMyEmail || isRecipientMyBranch || isSentByMe;
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold font-sans text-gray-950 tracking-tight">Team Communication Channels</h1>
        <p className="text-xs text-gray-400 font-medium">Coordinate directly with fellow station clerks, post risk annotations, and coordinate regional microfinance actions</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-4">
        {/* Left: Channels selection lists */}
        <div className="space-y-3.5 lg:col-span-1">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1 font-mono">Available Channels</span>
          
          <div className="space-y-1.8 space-y-2">
            {ALL_CHANNELS.map((ch) => {
              const Icon = ch.icon;
              const isActive = activeChannel === ch.val;
              return (
                <button
                  key={ch.val}
                  onClick={() => setActiveChannel(ch.val)}
                  className={`w-full text-left rounded-xl p-3 border text-xs font-semibold transition-all ${
                    isActive 
                      ? 'bg-blue-600 border-blue-500 text-white shadow-md' 
                      : 'bg-white border-gray-200 hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <Icon className={`h-4.2 w-4.2 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                    <span>{ch.val}</span>
                  </div>
                  <p className={`text-[10px] font-medium leading-snug truncate ${isActive ? 'text-blue-100' : 'text-slate-400'}`}>
                    {ch.desc}
                  </p>
                </button>
              );
            })}
          </div>

          <div className="rounded-xl border border-gray-200 bg-blue-50/50 p-4 text-[10.5px] leading-relaxed text-blue-700 font-sans mt-3">
            <span className="font-bold block mb-1">🔐 Closed Communication Loop</span>
            <span>All conversations are securely archived internally. Communications do not leave Pacific Finance LTD parameters.</span>
          </div>
        </div>

        {/* Right: Message list & editor textfield */}
        <div className="rounded-xl border border-gray-200 bg-white shadow-sm lg:col-span-3 flex flex-col h-140 overflow-hidden">
          {/* Header of active channel */}
          <div className="px-5 py-4 border-b border-gray-150 bg-slate-50 flex items-center justify-between shrink-0">
            <div>
              <span className="text-xs font-bold text-gray-950 font-sans">{activeChannel}</span>
              <span className="block text-[10px] text-gray-400 font-medium mt-0.5">Physical network stream logs</span>
            </div>
            
            <span className="rounded bg-sky-100/10 text-slate-500 border px-2 py-0.5 font-mono text-[9px] font-bold">
              ✓ Active Hub
            </span>
          </div>

          {/* Messages block scrollable */}
          <div className="flex-1 overflow-y-auto p-5 space-y-4 bg-gray-50/20 custom-scrollbar">
            {filteredMsgs.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center text-gray-405 text-gray-400">
                <MessageSquare className="h-8 w-8 mb-2 text-gray-300" />
                <p className="text-xs font-bold text-gray-650">No notes posted on this channel yet</p>
                <p className="text-[10px] max-w-xs mt-1 leading-normal">Be the first to post local regional notes utilizing the text editor below.</p>
              </div>
            ) : (
              filteredMsgs.map((msg) => {
                const isMe = msg.senderName === currentUser?.name;
                return (
                  <div key={msg.id} className={`flex gap-3 max-w-[75%] ${isMe ? 'ml-auto flex-row-reverse' : 'mr-auto'}`}>
                    {/* Circle avatar */}
                    <div className="h-8 w-8 rounded-lg bg-blue-105 bg-slate-100 font-black text-xs text-slate-600 flex items-center justify-center border shrink-0">
                      {msg.senderName.charAt(0)}
                    </div>
                    
                    <div>
                      {/* Name metadata banner */}
                      <div className={`flex items-center gap-1.5 mb-1.5 text-[10.5px] font-bold text-slate-500 ${isMe ? 'justify-end' : ''}`}>
                        <span className="text-slate-800 font-sans">{msg.senderName}</span>
                        <span className="text-[9px] bg-slate-100 border px-1.2 py-0.2 rounded font-mono font-medium">{msg.senderRole}</span>
                        {msg.recipientEmail !== 'All' && (
                          <span className="text-[8.5px] bg-blue-50 text-blue-700 border border-blue-100/60 px-1 py-0.1 rounded font-mono font-bold uppercase shrink-0">
                            ✉ To: {msg.recipientName}
                          </span>
                        )}
                        <span className="text-[8.5px] font-mono font-normal text-slate-400">{msg.timestamp}</span>
                      </div>

                      {/* Chat text box */}
                      <div className={`rounded-xl p-3 text-xs leading-relaxed font-sans font-medium ${
                        isMe 
                          ? 'bg-blue-600 text-white rounded-tr-none shadow-sm' 
                          : 'bg-white border border-gray-150 text-gray-800 rounded-tl-none shadow-sm'
                      }`}>
                        {msg.message}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Text editor editor footer */}
          <form onSubmit={handlePostMessage} className="p-4 border-t border-gray-150 bg-white shrink-0 space-y-3">
            {currentUser?.role === 'Admin' && (
              <div className="flex flex-wrap items-center gap-2.5 pb-2 border-b border-gray-100 text-[10px]">
                <span className="font-bold text-slate-400 uppercase tracking-widest block font-mono">
                  Target Audience:
                </span>
                
                <div className="flex bg-gray-50 p-0.5 rounded-lg border border-gray-200">
                  <button
                    type="button"
                    onClick={() => setRecipientType('All')}
                    className={`px-2.5 py-1 text-[10px] font-bold rounded-md ${
                      recipientType === 'All' 
                        ? 'bg-white text-blue-650 shadow-sm' 
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    Whole Platform
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setRecipientType('Branch');
                      if (branches.length > 0 && !selectedBranch) {
                        setSelectedBranch(branches[0].name);
                      }
                    }}
                    className={`px-2.5 py-1 text-[10px] font-bold rounded-md ${
                      recipientType === 'Branch' 
                        ? 'bg-white text-blue-650 shadow-sm' 
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    Branch Outlet
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setRecipientType('User');
                      if (users.length > 0 && !selectedUserEmail) {
                        setSelectedUserEmail(users[0].email);
                      }
                    }}
                    className={`px-2.5 py-1 text-[10px] font-bold rounded-md ${
                      recipientType === 'User' 
                        ? 'bg-white text-blue-650 shadow-sm' 
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    Staff Employee
                  </button>
                </div>

                {recipientType === 'Branch' && (
                  <select
                    value={selectedBranch}
                    onChange={(e) => setSelectedBranch(e.target.value)}
                    className="rounded border border-gray-200 bg-white px-2 py-1 text-[10px] font-bold text-slate-700 outline-none focus:border-blue-500"
                  >
                    <option value="">-- Choose Target Branch --</option>
                    {branches.map(br => (
                      <option key={br.id} value={br.name}>{br.name}</option>
                    ))}
                  </select>
                )}

                {recipientType === 'User' && (
                  <select
                    value={selectedUserEmail}
                    onChange={(e) => setSelectedUserEmail(e.target.value)}
                    className="rounded border border-gray-200 bg-white px-2 py-1 text-[10px] font-bold text-slate-700 outline-none focus:border-blue-500 max-w-xs"
                  >
                    <option value="">-- Choose Target Employee --</option>
                    {users.map(u => (
                      <option key={u.id} value={u.email}>{u.name} ({u.position} - {u.branch})</option>
                    ))}
                  </select>
                )}
              </div>
            )}

            <div className="flex gap-2.5">
              <input
                type="text"
                required
                value={typedMessage}
                onChange={(e) => setTypedMessage(e.target.value)}
                placeholder={`Type a secure memo onto the [${activeChannel}] board...`}
                className="flex-1 bg-gray-50 rounded-lg border border-gray-250 px-4 py-2 text-xs text-gray-850 outline-none focus:bg-white focus:border-blue-500 font-medium"
              />
              <button
                type="submit"
                className="h-9 w-12 rounded-lg bg-blue-600 hover:bg-blue-500 text-white flex items-center justify-center shadow transition-all shrink-0 active:scale-95"
              >
                <Send className="h-4.2 w-4.2" />
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
