import React from 'react';
import {
  LayoutDashboard,
  FileSpreadsheet,
  Network,
  ClipboardCheck,
  MessageCircle,
  ShieldAlert,
  Sliders,
  LogOut,
  Sparkles,
  TrendingUp,
  UserCheck
} from 'lucide-react';
import { User } from '../types';

interface SidebarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  isOpen: boolean;
  setIsOpen: (open: boolean) => void;
  currentUser: User | null;
  onLogout: () => void;
  unreadAlertCount: number;
}

export default function Sidebar({
  currentTab,
  setCurrentTab,
  isOpen,
  setIsOpen,
  currentUser,
  onLogout,
  unreadAlertCount
}: SidebarProps) {
  
  // Define navigation layout based on permissions/role
  const menuSections = [
    {
      title: 'FINANCIAL INTELLIGENCE',
      items: [
        { id: 'dashboard', label: 'Overview Dashboard', icon: LayoutDashboard },
        { 
          id: 'sheet-analyzer', 
          label: 'Sheets & AI Analyzer', 
          icon: FileSpreadsheet,
          badge: 'AI Active',
          badgeColor: 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
        },
      ],
    },
    {
      title: 'MANAGEMENT RAIL',
      items: [
        { id: 'branches-staff', label: currentUser?.role === 'Admin' ? 'Branches & Staff' : 'Branch Roster', icon: Network },
        { id: 'task-board', label: 'Duties & Tasks', icon: ClipboardCheck },
        { id: 'communications', label: 'Team Channels', icon: MessageCircle, badge: 'Live', badgeColor: 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' }
      ]
    },
    {
      title: 'SECURITY & PRESETS',
      items: [
        { id: 'security-audits', label: 'Data Privacy Logs', icon: ShieldAlert },
        { id: 'system-settings', label: 'Export & Config', icon: Sliders }
      ]
    }
  ];

  if (!currentUser) return null;

  return (
    <>
      {/* Mobile Sidebar overlay */}
      {isOpen && (
        <div
          id="sidebar-overlay"
          className="fixed inset-0 z-40 bg-slate-950/60 backdrop-blur-sm lg:hidden transition-opacity duration-300"
          onClick={() => setIsOpen(false)}
        />
      )}

      {/* Sidebar container */}
      <aside
        id="sidebar-container"
        className={`fixed top-0 bottom-0 left-0 z-50 flex w-68 flex-col border-r border-slate-800 bg-slate-900 text-slate-300 transition-transform duration-300 ease-in-out lg:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Branding header */}
        <div className="flex h-16 items-center justify-between px-6 border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-600 font-bold text-white shadow-md shadow-emerald-500/25">
              {/* Leaf design SVG */}
              <svg className="h-5 w-5 fill-white" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path d="M12,2A10,10,0,0,0,2,12a10,10,0,0,0,10,10,10,10,0,0,0,10,-10A10,10,0,0,0,12,2Zm1.5,14c-1.2,-1.5,-1.8,-3.3,-1.2,-5.1c0.3,-1,0.9,-2.1,0.9,-2.1c0,0,0.1,0.9,0.3,1.9c0.4,1.8,-0.1,3.3,-1,4.3C12,14.6,12.7,14,12.8,13.7c1.3,-1.1,1.7,-2.7,1.3,-4.6c0.5,1.2,0.4,2.7,-0.6,4.4C13.2,14,12.8,14.5,12.5,15ZM8.5,12.6c-1,-1.3,-0.9,-3,0.2,-4.7c-0.5,1.2,-0.4,2.7,0.6,4.4C9.5,12.5,9,13.2,8.5,12.6Z" />
              </svg>
            </div>
            <div>
              <span className="font-sans text-base font-extrabold text-[#f1f5f9] tracking-tight">Pacific Finance</span>
              <span className="block text-[8px] font-mono text-[#10b981] tracking-widest uppercase font-bold">LIMITED</span>
            </div>
          </div>
        </div>

        {/* Active Logged In Context Panel */}
        <div className="bg-slate-950/40 border-b border-slate-800/80 p-4 shrink-0">
          <div className="flex items-center gap-3">
            <div className="relative h-9 w-9 overflow-hidden rounded-lg bg-blue-100/10 text-blue-400 flex items-center justify-center font-bold font-sans border border-blue-500/20">
              {currentUser.name.charAt(0)}
              <span className="absolute bottom-0 right-0 h-2.5 w-2.5 rounded-full bg-emerald-500 border-2 border-slate-900" />
            </div>
            <div className="flex-1 min-w-0">
              <span className="block text-xs font-bold text-slate-200 truncate font-sans">{currentUser.name}</span>
              <span className="block text-[10px] text-slate-450 truncate font-mono text-slate-400">{currentUser.position}</span>
            </div>
          </div>
          <div className="mt-2 text-center">
            <span className="inline-flex items-center gap-1 rounded bg-blue-500/10 px-2 py-0.5 text-[9px] font-bold text-blue-400 border border-blue-500/20">
              <UserCheck className="h-2.5 w-2.5" />
              Role: {currentUser.role}
            </span>
          </div>
        </div>

        {/* Navigation scrollable menu */}
        <div className="flex-1 overflow-y-auto py-5 px-4 space-y-6 custom-scrollbar">
          {menuSections.map((section, idx) => (
            <div key={idx} className="space-y-1.5">
              <h3 className="px-3 font-mono text-[9px] font-bold tracking-widest text-slate-500 uppercase">
                {section.title}
              </h3>
              <ul className="space-y-1">
                {section.items.map((item) => {
                  const Icon = item.icon;
                  const isActive = currentTab === item.id;
                  
                  // Hide Audits from non-admin if desired, but let's show privacy audit to both (roles filter inside the route)
                  
                  return (
                    <li key={item.id}>
                      <button
                        id={`sidebar-item-${item.id}`}
                        onClick={() => {
                          setCurrentTab(item.id);
                          setIsOpen(false);
                        }}
                        className={`group flex w-full items-center justify-between rounded-lg px-3 py-2 text-xs font-semibold transition-all duration-150 ${
                          isActive
                            ? 'bg-slate-850 bg-slate-800 text-white shadow-sm'
                            : 'hover:bg-slate-800/40 hover:text-white text-slate-400'
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          <Icon
                            className={`h-4.2 w-4.2 transition-colors ${
                              isActive ? 'text-blue-400' : 'text-slate-400 group-hover:text-slate-250'
                            }`}
                          />
                          <span>{item.label}</span>
                        </div>
                        {item.badge && (
                          <span className={`rounded-full px-1.5 py-0.2 text-[9px] font-bold tracking-wide ${item.badgeColor}`}>
                            {item.badge}
                          </span>
                        )}
                      </button>
                    </li>
                  );
                })}
              </ul>
            </div>
          ))}
        </div>

        {/* Footer actions */}
        <div className="border-t border-slate-800 p-4 bg-slate-900/40 shrink-0">
          <button
            id="sidebar-logout-btn"
            onClick={onLogout}
            className="flex items-center gap-2.5 w-full rounded-lg px-3 py-2 text-xs font-semibold hover:bg-rose-500/10 hover:text-rose-450 text-slate-400 transition-colors"
          >
            <LogOut className="h-4.2 w-4.2 text-rose-500" />
            <span>Sign Out</span>
          </button>
          
          <div className="bg-slate-950/40 rounded-lg p-3 border border-slate-800/80 mt-3 text-[11px] text-slate-400">
            <div className="flex items-center gap-1.5 text-slate-200 font-bold mb-1">
              <Sparkles className="h-3.5 w-3.5 text-blue-400" />
              <span>Security Protocol</span>
            </div>
            <p className="leading-normal select-none">All sessions are audited. Privacy is protected under the FIS-304 banking act.</p>
          </div>
        </div>
      </aside>
    </>
  );
}
