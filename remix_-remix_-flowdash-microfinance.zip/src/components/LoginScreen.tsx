import React, { useState } from 'react';
import { ShieldCheck, UserCheck, KeyRound, Building, UserPlus, Sparkles, Phone, Compass, ArrowRight } from 'lucide-react';
import { User, Branch } from '../types';

interface LoginScreenProps {
  onLoginSuccess: (user: User) => void;
  branches: Branch[];
  users: User[];
  onRegisterUser: (newUser: User) => void;
}

export default function LoginScreen({ onLoginSuccess, branches, users, onRegisterUser }: LoginScreenProps) {
  const [isLogin, setIsLogin] = useState(true);
  
  // Login fields
  const [usernameOrEmail, setUsernameOrEmail] = useState('');
  const [password, setPassword] = useState('');
  
  // Signup fields
  const [signupName, setSignupName] = useState('');
  const [signupEmail, setSignupEmail] = useState('');
  const [signupPhone, setSignupPhone] = useState('');
  const [signupPosition, setSignupPosition] = useState('');
  const [signupBranch, setSignupBranch] = useState('');
  const [signupPassword, setSignupPassword] = useState('');
  
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // Submissions
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const term = usernameOrEmail.trim();
    const pass = password;

    if (!term || !pass) {
      setError('Please provide all credentials correctly To continue.');
      return;
    }

    // Checking Admin credentials (user: MCHAGUNDA password: ^Bosst1%1900)
    if (term.toUpperCase() === 'MCHAGUNDA' && pass === '^Bosst1%1900') {
      const adminUser: User = users.find(u => u.name === 'MCHAGUNDA') || {
        id: 'u-admin-direct',
        name: 'MCHAGUNDA',
        position: 'Chief Financial Director',
        branch: 'Blantyre Central Branch',
        email: 'mchagunda@microfinance.co.mw',
        phone: '+265 88-123456',
        role: 'Admin' as const,
        permissions: ['all_access'],
        activeStatus: 'Active' as const,
        createdDate: '2023-11-01'
      };
      onLoginSuccess(adminUser);
      return;
    }

    // Checking email/username inside users registry
    const matched = users.find(
      u => (u.email.toLowerCase() === term.toLowerCase() || u.name.toLowerCase() === term.toLowerCase()) && 
      u.password === pass
    );

    if (matched) {
      if (matched.activeStatus === 'Inactive') {
        setError('This employee record has been suspended. Please request Admin vetting.');
        return;
      }
      onLoginSuccess(matched);
    } else if (term.toUpperCase() === 'MCHAGUNDA') {
      setError('Invalid admin credentials. Check your security keystroke.');
    } else {
      setError('User record not recognized or password mismatch. Please review details.');
    }
  };

  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    if (!signupName || !signupEmail || !signupPhone || !signupPosition || !signupBranch || !signupPassword) {
      setError('Please fill in every single personnel registry field.');
      return;
    }

    // Check if email already registered
    const exists = users.some(u => u.email.toLowerCase() === signupEmail.toLowerCase());
    if (exists) {
      setError('This email journal sequence is already linked to a registered clerk.');
      return;
    }

    const newUser: User = {
      id: `u-${Math.floor(1000 + Math.random() * 9000)}`,
      name: signupName.trim(),
      position: signupPosition.trim(),
      branch: signupBranch,
      email: signupEmail.trim().toLowerCase(),
      phone: signupPhone.trim(),
      password: signupPassword,
      role: 'User', // Signup delegates as standard officer first. Admin defines specific role/permissions.
      permissions: ['upload_reports', 'view_branch_analytics'],
      activeStatus: 'Active',
      createdDate: new Date().toISOString().split('T')[0],
      lastActive: new Date().toISOString()
    };

    onRegisterUser(newUser);
    setSuccess(`Registration successful! You have joined ${signupBranch}. Welcome to the Central tracking network.`);
    
    // Reset signup state
    setSignupName('');
    setSignupEmail('');
    setSignupPhone('');
    setSignupPosition('');
    setSignupBranch('');
    setSignupPassword('');
    
    // Direct back to login view
    setTimeout(() => {
      setIsLogin(true);
      setUsernameOrEmail(newUser.email);
    }, 2000);
  };

  return (
    <div className="flex min-h-screen bg-slate-50 font-sans text-slate-800 items-center justify-center p-6 relative overflow-hidden select-none">
      {/* Custom Styles Inject for animations */}
      <style>{`
        @keyframes customFloat1 {
          0% { transform: translateY(0px) rotate(0deg) scale(1); }
          50% { transform: translateY(-20px) rotate(3deg) scale(1.02); }
          100% { transform: translateY(0px) rotate(0deg) scale(1); }
        }
        @keyframes customFloat2 {
          0% { transform: translateY(0px) rotate(0deg) scale(1); }
          50% { transform: translateY(25px) rotate(-4deg) scale(0.98); }
          100% { transform: translateY(0px) rotate(0deg) scale(1); }
        }
        @keyframes customFloat3 {
          0% { transform: translate(0px, 0px) rotate(0deg); }
          50% { transform: translate(-15px, -15px) rotate(5deg); }
          100% { transform: translate(0px, 0px) rotate(0deg); }
        }
        @keyframes drawGrid {
          0% { background-position: 0 0; }
          100% { background-position: 60px 60px; }
        }
        .finance-grid {
          background-size: 60px 60px;
          background-image: 
            linear-gradient(to right, rgba(0,0,0,0.012) 1px, transparent 1px),
            linear-gradient(to bottom, rgba(0,0,0,0.012) 1px, transparent 1px);
          animation: drawGrid 30s linear infinite;
        }
      `}</style>

      {/* Background visual components */}
      <div className="absolute inset-0 finance-grid pointer-events-none" />
      
      {/* Absolute ambient glows */}
      <div className="absolute top-[-10%] right-[-10%] w-[600px] h-[600px] bg-blue-400/10 rounded-full blur-[160px] pointer-events-none" />
      <div className="absolute bottom-[-10%] left-[-10%] w-[500px] h-[500px] bg-emerald-400/10 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute top-1/3 left-1/4 w-[300px] h-[300px] bg-indigo-400/10 rounded-full blur-[120px] pointer-events-none" />

      {/* Floating Finance widgets in background (hidden on tiny screens to avoid layout overlaps) */}
      <div 
        className="absolute top-12 left-12 bg-white/45 backdrop-blur-md border border-slate-200/60 p-4.5 rounded-xl shadow-md pointer-events-none hidden md:block"
        style={{ animation: 'customFloat1 8s ease-in-out infinite' }}
      >
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-lg bg-emerald-50 border border-emerald-250 text-[#00923A]">
            <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
            </svg>
          </div>
          <div>
            <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest block">Pacific Yield Index</span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-xs font-black text-slate-900">+24.85%</span>
              <span className="text-[8px] text-emerald-650 font-bold font-mono">LIVE TRACK</span>
            </div>
          </div>
        </div>
      </div>

      <div 
        className="absolute bottom-16 right-12 bg-white/45 backdrop-blur-md border border-slate-200/60 p-4.5 rounded-xl shadow-md pointer-events-none hidden md:block"
        style={{ animation: 'customFloat2 10s ease-in-out infinite' }}
      >
        <div className="space-y-2">
          <div className="flex items-center justify-between gap-8">
            <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">Regional Report Syncs</span>
            <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
          </div>
          <div className="flex items-end gap-1 font-mono">
            <div className="w-1.5 bg-blue-500/15 h-4 rounded-sm" />
            <div className="w-1.5 bg-blue-500/25 h-7 rounded-sm" />
            <div className="w-1.5 bg-blue-500/40 h-5 rounded-sm" />
            <div className="w-1.5 bg-emerald-500 h-9 rounded-sm animate-pulse" />
          </div>
        </div>
      </div>

      <div 
        className="absolute top-1/4 right-16 bg-white/30 backdrop-blur-sm border border-slate-200/40 px-4.5 py-3 rounded-xl pointer-events-none hidden lg:block"
        style={{ animation: 'customFloat3 9s ease-in-out infinite' }}
      >
        <div className="flex items-center gap-2">
          <span className="text-[14px] font-bold text-blue-600">$</span>
          <div>
            <span className="text-[9px] text-slate-500 font-bold block leading-none">CUSTODIAN VALUATION</span>
            <span className="text-xs font-black text-slate-800 mt-0.5 block font-mono">1.48B MWK</span>
          </div>
        </div>
      </div>

      <div 
        className="absolute bottom-24 left-16 bg-white/30 backdrop-blur-sm border border-slate-200/40 px-4 py-2.5 rounded-xl pointer-events-none hidden lg:block"
        style={{ animation: 'customFloat2 12s ease-in-out infinite' }}
      >
        <div className="flex items-center gap-2 text-slate-600">
          <div className="h-2 w-2 rounded-full bg-blue-500 animate-pulse" />
          <span className="text-[9px] font-mono font-bold uppercase tracking-wider">Reserve Desk Sync Active</span>
        </div>
      </div>

      <div className="w-full max-w-md bg-white/75 backdrop-blur-2xl border border-white/90 p-8 rounded-2xl shadow-xl shadow-slate-200/50 relative z-10 text-slate-800">
        
        {/* Header Title branding */}
        <div className="text-center mb-8">
          <div className="flex flex-col items-center select-none max-w-sm mx-auto mb-2">
            {/* Corporate Title Group */}
            <div className="text-center w-full py-2">
              <h1 className="text-2xl font-black tracking-tight text-[#1e1b4b] uppercase leading-snug font-sans">
                Pacific Finance
              </h1>
              <span className="block text-xs font-black tracking-[0.2em] text-[#00923A] uppercase mt-1">
                Reporting Portal
              </span>
            </div>
          </div>
          <p className="text-xs text-slate-500 mt-2.5 uppercase font-mono tracking-widest bg-slate-100/60 border border-slate-200/40 py-1.5 px-3 rounded-lg">Central Vault & Compliance Engine</p>
        </div>

        {/* Custom tabs selector for seamless flow */}
        <div className="flex bg-slate-100/70 border border-slate-200/40 p-1.5 rounded-xl mb-6">
          <button
            onClick={() => { setError(null); setIsLogin(true); }}
            className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
              isLogin ? 'bg-white text-slate-900 shadow-sm border border-slate-200/20' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            Terminal Sign In
          </button>
          <button
            onClick={() => { setError(null); setIsLogin(false); }}
            className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
              !isLogin ? 'bg-white text-slate-900 shadow-sm border border-slate-200/20' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            Officer Enlistment
          </button>
        </div>

        {error && (
          <div className="mb-4 rounded-lg bg-red-50 border border-red-200 p-3 text-xs text-red-600 font-medium">
            {error}
          </div>
        )}

        {success && (
          <div className="mb-4 rounded-lg bg-emerald-50 border border-emerald-250 p-3 text-xs text-emerald-700 font-medium font-sans">
            {success}
          </div>
        )}

        {isLogin ? (
          /* LOGIN PANEL FORM */
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-[10px] font-mono tracking-widest text-slate-500 uppercase mb-1.5">User Identity or Email</label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                  <UserCheck className="h-4 w-4 text-slate-400" />
                </span>
                <input
                  type="text"
                  required
                  value={usernameOrEmail}
                  onChange={(e) => setUsernameOrEmail(e.target.value)}
                  placeholder="Log In"
                  className="w-full bg-slate-50/60 rounded-lg border border-slate-200 pl-10 pr-4 py-2 text-xs text-slate-800 placeholder-slate-400 focus:border-blue-500 focus:bg-white focus:outline-hidden focus:ring-1 focus:ring-blue-500 font-medium transition-all"
                />
              </div>
            </div>

            <div>
              <label className="block text-[10px] font-mono tracking-widest text-slate-500 uppercase mb-1.5">Security Password</label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                  <KeyRound className="h-4 w-4 text-slate-400" />
                </span>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full bg-slate-50/60 rounded-lg border border-slate-200 pl-10 pr-4 py-2 text-xs text-slate-800 placeholder-slate-400 focus:border-blue-500 focus:bg-white focus:outline-hidden focus:ring-1 focus:ring-blue-500 font-mono transition-all"
                />
              </div>
            </div>



            <button
              type="submit"
              className="w-full h-10 mt-2 inline-flex items-center justify-center gap-2 rounded-lg bg-blue-600 text-xs font-bold text-white hover:bg-blue-700 hover:shadow-lg active:scale-98 transition-all cursor-pointer"
            >
              <span>Unlock Central Portal</span>
              <ArrowRight className="h-4.2 w-4.2" />
            </button>
          </form>
        ) : (
          /* WORKER SIGNUP PANEL FORM */
          <form onSubmit={handleSignup} className="space-y-3.5">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[10px] font-mono tracking-wider text-slate-500 uppercase mb-1">Full Legal Name</label>
                <input
                  type="text"
                  required
                  value={signupName}
                  onChange={(e) => setSignupName(e.target.value)}
                  placeholder="e.g. Chisomo Tembo"
                  className="w-full bg-slate-50/60 rounded-lg border border-slate-200 px-3 py-2 text-xs text-slate-800 placeholder-slate-400 focus:border-blue-500 focus:bg-white focus:outline-hidden transition-all"
                />
              </div>
              <div>
                <label className="block text-[10px] font-mono tracking-wider text-slate-500 uppercase mb-1">Staff Position</label>
                <input
                  type="text"
                  required
                  value={signupPosition}
                  onChange={(e) => setSignupPosition(e.target.value)}
                  placeholder="e.g. Desk Assessor"
                  className="w-full bg-slate-50/60 rounded-lg border border-slate-200 px-3 py-2 text-xs text-slate-800 placeholder-slate-400 focus:border-blue-500 focus:bg-white focus:outline-hidden transition-all"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[10px] font-mono tracking-wider text-slate-500 uppercase mb-1">Company Email</label>
                <input
                  type="email"
                  required
                  value={signupEmail}
                  onChange={(e) => setSignupEmail(e.target.value)}
                  placeholder="name@gmail.com"
                  className="w-full bg-slate-50/60 rounded-lg border border-slate-200 px-3 py-2 text-xs text-slate-800 placeholder-slate-400 focus:border-blue-500 focus:bg-white focus:outline-hidden transition-all"
                />
              </div>
              <div>
                <label className="block text-[10px] font-mono tracking-wider text-slate-500 uppercase mb-1">Phone Number</label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-2">
                    <Phone className="h-3 w-3 text-slate-400" />
                  </span>
                  <input
                    type="tel"
                    required
                    value={signupPhone}
                    onChange={(e) => setSignupPhone(e.target.value)}
                    placeholder="+265 88-..."
                    className="w-full bg-slate-50/60 rounded-lg border border-slate-200 pl-7 pr-3 py-2 text-xs text-slate-800 placeholder-slate-400 focus:border-blue-500 focus:bg-white focus:outline-hidden transition-all"
                  />
                </div>
              </div>
            </div>

            <div>
              <label className="block text-[10px] font-mono tracking-wider text-slate-500 uppercase mb-1">Institution Branch Station</label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                  <Building className="h-4 w-4 text-slate-400" />
                </span>
                {branches.length === 0 ? (
                  <input
                    type="text"
                    required
                    value={signupBranch}
                    onChange={(e) => setSignupBranch(e.target.value)}
                    placeholder="Type name of physical branch station"
                    className="w-full bg-slate-50/60 rounded-lg border border-slate-200 pl-9 pr-3 py-2 text-xs text-slate-800 placeholder-slate-400 focus:border-blue-500 focus:bg-white focus:outline-hidden focus:ring-1 focus:ring-blue-500 font-medium transition-all"
                  />
                ) : (
                  <select
                    required
                    value={signupBranch}
                    onChange={(e) => setSignupBranch(e.target.value)}
                    className="w-full bg-slate-50/60 rounded-lg border border-slate-200 pl-9 pr-3 py-2 text-xs text-slate-705 focus:border-blue-500 focus:bg-white focus:outline-hidden appearance-none transition-all cursor-pointer"
                  >
                    <option value="" disabled className="bg-white text-slate-400">Select physical branch site</option>
                    {branches.map((b) => (
                      <option key={b.id} value={b.name} className="bg-white text-slate-800">
                        {b.name} ({b.location})
                      </option>
                    ))}
                  </select>
                )}
              </div>
            </div>

            <div>
              <label className="block text-[10px] font-mono tracking-wider text-slate-500 uppercase mb-1">Establish Password</label>
              <input
                type="password"
                required
                value={signupPassword}
                onChange={(e) => setSignupPassword(e.target.value)}
                placeholder="Secure alphanumeric passphrase"
                className="w-full bg-slate-50/60 rounded-lg border border-slate-200 px-3 py-2 text-xs text-slate-800 placeholder-slate-400 focus:border-blue-500 focus:bg-white focus:outline-hidden font-mono transition-all"
              />
            </div>

            <button
              type="submit"
              className="w-full h-10 mt-3 inline-flex items-center justify-center gap-2 rounded-lg bg-emerald-600 text-xs font-bold text-white hover:bg-emerald-500 hover:shadow-lg active:scale-98 transition-all cursor-pointer"
            >
              <UserPlus className="h-4.2 w-4.2" />
              <span>Submit Registry Enlistment</span>
            </button>
          </form>
        )}

        <div className="mt-6 text-center text-[10px] text-slate-400 border-t border-slate-200/50 pt-4 font-mono leading-relaxed select-none">
          <span>🔒 SHA-256 local verification protocols active. Unauthorized entries are reported directly to the central Reserve Bank auditor under legal sequence.</span>
        </div>

      </div>
    </div>
  );
}
