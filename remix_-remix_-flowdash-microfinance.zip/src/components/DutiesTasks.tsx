import React, { useState } from 'react';
import { ClipboardList, Plus, Trash2, CheckCircle2, AlertCircle, Clock, Calendar, User, UserCheck, Play, Check } from 'lucide-react';
import { Task, User as UserType } from '../types';

interface DutiesTasksProps {
  tasks: Task[];
  onAddTask: (newTask: Task) => void;
  onUpdateTaskStatus: (taskId: string, status: Task['status']) => void;
  onDeleteTask: (taskId: string) => void;
  users: UserType[];
  currentUser: UserType | null;
  onRunAuditLog: (action: string) => void;
}

export default function DutiesTasks({
  tasks,
  onAddTask,
  onUpdateTaskStatus,
  onDeleteTask,
  users,
  currentUser,
  onRunAuditLog
}: DutiesTasksProps) {
  const isAdmin = currentUser?.role === 'Admin';

  // Task creation fields
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [assignedTo, setAssignedTo] = useState('');
  const [priority, setPriority] = useState<Task['priority']>('Medium');
  const [dueDate, setDueDate] = useState('');
  const [feebackMsg, setFeedbackMsg] = useState<string | null>(null);

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedbackMsg(null);

    if (!title.trim() || !description.trim() || !assignedTo || !dueDate) {
      setFeedbackMsg('All task details parameters must be fully established.');
      return;
    }

    const assignedUserObj = users.find(u => u.email === assignedTo);
    const assignedName = assignedUserObj ? assignedUserObj.name : assignedTo;

    const freshTask: Task = {
      id: `task-${Math.floor(100 + Math.random() * 900)}`,
      title: title.trim(),
      description: description.trim(),
      assignedTo: assignedName,
      assignedToName: assignedName,
      assignedToEmail: assignedTo,
      assignedBy: currentUser?.name || 'Director General',
      dueDate: dueDate,
      priority: priority,
      status: 'Pending',
      progress: 0,
      activityLog: [],
      createdDate: new Date().toISOString().split('T')[0]
    };

    onAddTask(freshTask);
    onRunAuditLog(`Assigned company duty to [${assignedName}]: "${freshTask.title}"`);
    
    setTitle('');
    setDescription('');
    setAssignedTo('');
    setDueDate('');
    setFeedbackMsg(`Duty successfully delegated to ${assignedName}!`);

    setTimeout(() => setFeedbackMsg(null), 3000);
  };

  // Filter tasks based on role limits: Admin sees all, User sees tasks assigned specifically to their email
  const displayTasks = isAdmin 
    ? tasks 
    : tasks.filter(t => t.assignedToEmail?.toLowerCase() === currentUser?.email.toLowerCase() || t.assignedTo === currentUser?.name);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold font-sans text-gray-950 tracking-tight">Active Duty & Task Allocator</h1>
          <p className="text-xs text-gray-400 font-medium">Delegate credit assessments, manage administrative compliance, and track task resolution milestones</p>
        </div>
        <div className="text-xs font-bold text-slate-500 bg-slate-100 px-3 py-1.5 rounded border">
          My Operational Duties: <strong className="font-mono text-blue-600">{displayTasks.length} assigned</strong>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Left column: Assign New Task (Admins Only) */}
        <div className="space-y-6 lg:col-span-1">
          {isAdmin ? (
            <div className="rounded-xl border border-gray-200 bg-white p-5 shadow-sm">
              <h3 className="text-xs font-bold font-sans text-gray-800 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                <ClipboardList className="h-4.5 w-4.5 text-blue-600" />
                <span>Delegate Fresh Duty Task</span>
              </h3>
              <p className="text-[11px] text-gray-400 mb-4 leading-normal">
                Issue a directed command tasking station officers to audit accounts, follow up defaults, or compile ledgers.
              </p>

              {feebackMsg && (
                <div className="mb-3 p-2 text-xs font-semibold rounded bg-emerald-50 text-emerald-800 border border-emerald-150">
                  {feebackMsg}
                </div>
              )}

              <form onSubmit={handleCreateTask} className="space-y-3.5">
                <div>
                  <label className="block text-[10px] text-gray-500 font-bold mb-1">Duty Title Header</label>
                  <input
                    type="text"
                    required
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g. Audit Blantyre Credit Vault"
                    className="w-full rounded-lg border border-gray-250 bg-gray-50 px-3 py-2 text-xs text-gray-850 outline-none focus:border-blue-500 focus:bg-white"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-gray-500 font-bold mb-1">Detailed Operational Command</label>
                  <textarea
                    required
                    rows={3}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Describe specific loanees to verify or sheets to compile..."
                    className="w-full rounded-lg border border-gray-250 bg-gray-50 px-3 py-2 text-xs text-gray-850 outline-none focus:border-blue-500 focus:bg-white resize-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] text-gray-500 font-bold mb-1">Assign User Officer</label>
                    <select
                      required
                      value={assignedTo}
                      onChange={(e) => setAssignedTo(e.target.value)}
                      className="w-full rounded-lg border border-gray-250 bg-gray-50 px-2 py-2 text-xs text-gray-850 outline-none focus:border-blue-500 cursor-pointer"
                    >
                      <option value="">Select Clerk</option>
                      {users.map(u => (
                        <option key={u.id} value={u.email}>{u.name} ({u.position})</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-[10px] text-gray-500 font-bold mb-1">Priority Rating</label>
                    <select
                      value={priority}
                      onChange={(e) => setPriority(e.target.value as Task['priority'])}
                      className="w-full rounded-lg border border-gray-250 bg-gray-50 px-2 py-2 text-xs text-gray-850 outline-none focus:border-blue-500 cursor-pointer"
                    >
                      <option value="High">🔴 Urgent/High</option>
                      <option value="Medium">🟡 Operational/Medium</option>
                      <option value="Low">🟢 Baseline/Low</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] text-gray-500 font-bold mb-1 font-sans">Milestone Target Due Date</label>
                  <input
                    type="date"
                    required
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    className="w-full rounded-lg border border-gray-250 bg-gray-50 px-3 py-2 text-xs text-gray-850 outline-none focus:border-blue-500"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full h-9 inline-flex items-center justify-center gap-1.5 rounded-lg bg-blue-600 text-xs font-bold text-white hover:bg-blue-700 shadow-sm transition-all"
                >
                  <Plus className="h-4 w-4" />
                  <span>Distribute Duty Task</span>
                </button>
              </form>
            </div>
          ) : (
            <div className="rounded-xl border border-gray-200 bg-gray-50 p-5 text-gray-500 space-y-3">
              <UserCheck className="h-8 w-8 text-blue-500" />
              <h4 className="text-xs font-bold text-gray-800 uppercase tracking-wider">Duties Dashboard Roster</h4>
              <p className="text-[11px] text-gray-400 leading-normal">
                This sidebar captures tasks assigned specifically to you by administrative directors.
              </p>
              <div className="p-3 bg-white rounded-lg border text-[10.5px] text-slate-600 font-medium">
                Make sure to update state checklists in the target panel as soon as disbursements are verified or sheet uploads complete.
              </div>
            </div>
          )}
        </div>

        {/* Right column: Main Board displays */}
        <div className="space-y-4 lg:col-span-2">
          {displayTasks.length === 0 ? (
            <div className="rounded-xl border border-dashed border-gray-200 p-10 bg-white text-center text-gray-400">
              <ClipboardList className="h-8 w-8 mx-auto text-slate-300 mb-2" />
              <h4 className="text-xs font-bold text-slate-700">All duties resolved!</h4>
              <p className="text-[10px] text-slate-400 mt-1 max-w-sm mx-auto leading-normal">
                No active outstanding tasks are registered on your feed sequence. Relax, or prepare spreadsheet sync loops on the Analyzer.
              </p>
            </div>
          ) : (
            <div className="grid gap-3.5 sm:grid-cols-1">
              {displayTasks.map((t) => {
                const isUrgent = t.priority === 'High';
                const isComp = t.status === 'Completed';
                const isProg = t.status === 'In Progress';
                
                const prioColor = isUrgent 
                  ? 'bg-rose-50 text-rose-700 border border-rose-100' 
                  : t.priority === 'Low' 
                    ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' 
                    : 'bg-amber-50 text-amber-700 border border-amber-100';

                return (
                  <div key={t.id} className={`rounded-xl border border-gray-150 p-4 bg-white transition-all shadow-sm flex flex-col justify-between h-full relative overflow-hidden ${
                    isComp ? 'opacity-65 hover:opacity-100' : ''
                  }`}>
                    {/* Urgency side stripe */}
                    <div className={`absolute top-0 bottom-0 left-0 w-1 ${isUrgent ? 'bg-rose-500' : isComp ? 'bg-emerald-400' : 'bg-amber-400'}`} />

                    <div className="pl-1.5">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <span className={`rounded px-1.5 py-0.2 text-[9px] font-mono font-bold tracking-wider uppercase ${prioColor}`}>
                          {t.priority} priority
                        </span>
                        
                        <div className="flex gap-1.5 select-none">
                          <span className={`inline-flex rounded border px-2 py-0.2 text-[9px] font-bold ${
                            isComp 
                              ? 'text-emerald-700 bg-emerald-50 border-emerald-100' 
                              : isProg 
                                ? 'text-blue-700 bg-blue-50 border-blue-100' 
                                : 'text-slate-600 bg-slate-100 border'
                          }`}>
                            {t.status}
                          </span>
                        </div>
                      </div>

                      <h4 className="text-xs font-bold text-gray-900 font-sans mt-2.5 flex items-center gap-1">
                        {t.title}
                      </h4>
                      <p className="text-[11.5px] text-gray-500 mt-1 leading-relaxed font-sans font-medium">{t.description}</p>
                      
                      <div className="grid grid-cols-2 gap-4 mt-4 border-t border-gray-100 pt-3 text-[10px] text-gray-400 font-mono">
                        <div>
                          <span className="block text-[8px] uppercase tracking-wider text-slate-400">Assigned To:</span>
                          <span className="font-bold text-slate-700 font-sans leading-none block mt-1">{t.assignedTo}</span>
                        </div>
                        <div>
                          <span className="block text-[8px] uppercase tracking-wider text-slate-400">Due Milestone:</span>
                          <span className="font-bold text-slate-700 leading-none block mt-1 flex items-center gap-1 font-sans">
                            <Calendar className="h-3 w-3 text-blue-500" />
                            {t.dueDate}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Progress manipulation trigger buttons */}
                    <div className="pl-1.5 mt-4 pt-3 border-t border-gray-100/60 flex items-center justify-between">
                      <span className="text-[9px] text-slate-400 font-mono">Issued by: {t.assignedBy} • {t.createdDate}</span>

                      <div className="flex items-center gap-1.5">
                        {!isComp && (
                          <>
                            {!isProg && (
                              <button
                                onClick={() => {
                                  onUpdateTaskStatus(t.id, 'In Progress');
                                  onRunAuditLog(`Started work sequence on assigned Task: "${t.title}"`);
                                }}
                                className="h-7 px-2.5 rounded bg-blue-550 bg-blue-50 hover:bg-blue-100 text-blue-700 text-[10px] font-bold inline-flex items-center gap-1 border border-blue-200"
                              >
                                <Play className="h-3 w-3" />
                                <span>Start work</span>
                              </button>
                            )}
                            <button
                              onClick={() => {
                                onUpdateTaskStatus(t.id, 'Completed');
                                onRunAuditLog(`Finished assigned microfinance duty Task: "${t.title}"`);
                              }}
                              className="h-7 px-3 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-[10px] font-bold inline-flex items-center gap-1"
                            >
                              <Check className="h-3 w-3" />
                              <span>Done</span>
                            </button>
                          </>
                        )}

                        {isAdmin && (
                          <button
                            onClick={() => {
                              onDeleteTask(t.id);
                              onRunAuditLog(`Deleted delegated Task item: "${t.title}"`);
                            }}
                            className="p-1.5 text-gray-400 hover:text-red-650 hover:bg-rose-50 rounded"
                            title="Hard purge Task"
                          >
                            <Trash2 className="h-3.5 w-3.5 text-red-500" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
