import { Branch, User, SheetLink, FinancialRecord, Task, AlertNotification, CommunicationMessage, AuditLog } from './types';

// Predefined microfinance branches
export const INITIAL_BRANCHES: Branch[] = [
  { id: 'b-1', name: 'Blantyre Central Branch', location: 'Victoria Avenue, Blantyre', code: 'BT-01', createdDate: '2024-01-15' },
  { id: 'b-2', name: 'Lilongwe Plaza Branch', location: 'City Centre, Sector 3, Lilongwe', code: 'LL-02', createdDate: '2024-03-10' },
  { id: 'b-3', name: 'Zomba District Desk', location: 'Kamuzu Highway, Zomba', code: 'ZB-03', createdDate: '2024-06-20' },
  { id: 'b-4', name: 'Mzuzu Northern Station', location: 'Orthodox Street, Mzuzu', code: 'MZ-04', createdDate: '2025-02-01' }
];

// Predefined user profiles (Admin uses credentials specified: MCHAGUNDA / ^Bosst1%1900)
export const INITIAL_USERS: User[] = [
  {
    id: 'u-1',
    name: 'MCHAGUNDA',
    position: 'Chief Financial Director',
    branch: 'Blantyre Central Branch',
    email: 'mchagunda@microfinance.co.mw',
    phone: '+265 88-123456',
    password: '^Bosst1%1900',
    role: 'Admin',
    permissions: ['all_access', 'manage_branches', 'assign_tasks', 'write_reports', 'export_data'],
    activeStatus: 'Active',
    createdDate: '2023-11-01',
    lastActive: '2026-05-23T09:12:00Z'
  },
  {
    id: 'u-2',
    name: 'Chisomo Tembo',
    position: 'Zomba District Manager',
    branch: 'Zomba District Desk',
    email: 'chisomotembo842@gmail.com', // Logged in user in metadata
    phone: '+265 88-842000',
    password: 'tembo',
    role: 'User',
    permissions: ['add_sheets', 'upload_reports', 'view_branch_analytics', 'update_tasks'],
    activeStatus: 'Active',
    createdDate: '2024-06-21',
    lastActive: '2026-05-23T09:20:00Z'
  },
  {
    id: 'u-3',
    name: 'Marcus Aurelius',
    position: 'Junior Credit Assessor',
    branch: 'Lilongwe Plaza Branch',
    email: 'marcus@microfinance.co.mw',
    phone: '+265 88-111222',
    password: 'marcus',
    role: 'User',
    permissions: ['upload_reports', 'view_branch_analytics'],
    activeStatus: 'Active',
    createdDate: '2025-01-05',
    lastActive: '2026-05-23T08:15:00Z'
  },
  {
    id: 'u-4',
    name: 'Sarah Jenkins',
    position: 'Blantyre Credit Supervisor',
    branch: 'Blantyre Central Branch',
    email: 'sarah@microfinance.co.mw',
    phone: '+265 88-333444',
    password: 'sarah',
    role: 'User',
    permissions: ['upload_reports', 'view_branch_analytics', 'update_tasks'],
    activeStatus: 'Active',
    createdDate: '2024-02-18',
    lastActive: '2026-05-22T16:40:00Z'
  }
];

// Seeded connected Google Sheet Links
export const INITIAL_SHEET_LINKS: SheetLink[] = [
  {
    id: 's-1',
    title: 'Q1 Blantyre Disbursement Journal',
    url: 'https://docs.google.com/spreadsheets/d/1BxiMVs0XRA5eFMdKvVYQK0pxbRnUXh04E07_7_TuxL0/edit',
    addedBy: 'sarah@microfinance.co.mw',
    addedDate: '2026-03-31',
    lastUpdated: '2026-05-23 08:30',
    recordCount: 12
  },
  {
    id: 's-2',
    title: 'Lilongwe Agricultural Micro-loans Log',
    url: 'https://docs.google.com/spreadsheets/d/1tYCS5W8yWJ8v5E5XzM1vWn0S_H0e6B9O/edit',
    addedBy: 'marcus@microfinance.co.mw',
    addedDate: '2026-04-15',
    lastUpdated: '2026-05-22 17:10',
    recordCount: 15
  }
];

// Mocked live financial entries compiled from connected logs
export const INITIAL_RECORDS: FinancialRecord[] = [
  // Blantyre CENTRAL records
  { id: 'rec-101', date: '2026-05-01', borrowerName: 'Grace Gondwe', branchName: 'Blantyre Central Branch', amountDisbursed: 1500, expectedRepayment: 1725, actualRepayment: 1725, interestRate: 15, expenses: 80, status: 'On Time', uploadedBy: 'sarah@microfinance.co.mw', sheetSourceId: 's-1' },
  { id: 'rec-102', date: '2026-05-02', borrowerName: 'Limbani Phiri', branchName: 'Blantyre Central Branch', amountDisbursed: 3000, expectedRepayment: 3450, actualRepayment: 3450, interestRate: 15, expenses: 150, status: 'On Time', uploadedBy: 'sarah@microfinance.co.mw', sheetSourceId: 's-1' },
  { id: 'rec-103', date: '2026-05-04', borrowerName: 'Tiyamike Banda', branchName: 'Blantyre Central Branch', amountDisbursed: 2200, expectedRepayment: 2530, actualRepayment: 1100, interestRate: 15, expenses: 110, status: 'Delayed', uploadedBy: 'sarah@microfinance.co.mw', sheetSourceId: 's-1' },
  { id: 'rec-104', date: '2026-05-06', borrowerName: 'Dumisani Moyo', branchName: 'Blantyre Central Branch', amountDisbursed: 1000, expectedRepayment: 1150, actualRepayment: 0, interestRate: 15, expenses: 50, status: 'Default', uploadedBy: 'sarah@microfinance.co.mw', sheetSourceId: 's-1' },
  { id: 'rec-105', date: '2026-05-10', borrowerName: 'Cecilia Chimwaza', branchName: 'Blantyre Central Branch', amountDisbursed: 4500, expectedRepayment: 5175, actualRepayment: 5175, interestRate: 15, expenses: 220, status: 'On Time', uploadedBy: 'sarah@microfinance.co.mw' },
  
  // Lilongwe records
  { id: 'rec-201', date: '2026-05-01', borrowerName: 'Aliko Msowoya', branchName: 'Lilongwe Plaza Branch', amountDisbursed: 2000, expectedRepayment: 2360, actualRepayment: 2360, interestRate: 18, expenses: 120, status: 'On Time', uploadedBy: 'marcus@microfinance.co.mw', sheetSourceId: 's-2' },
  { id: 'rec-202', date: '2026-05-03', borrowerName: 'Wezi Mtambo', branchName: 'Lilongwe Plaza Branch', amountDisbursed: 5000, expectedRepayment: 5900, actualRepayment: 5900, interestRate: 18, expenses: 280, status: 'On Time', uploadedBy: 'marcus@microfinance.co.mw', sheetSourceId: 's-2' },
  { id: 'rec-203', date: '2026-05-07', borrowerName: 'Blessings Kalua', branchName: 'Lilongwe Plaza Branch', amountDisbursed: 1200, expectedRepayment: 1416, actualRepayment: 600, interestRate: 18, expenses: 90, status: 'Delayed', uploadedBy: 'marcus@microfinance.co.mw', sheetSourceId: 's-2' },
  { id: 'rec-204', date: '2026-05-12', borrowerName: 'Fiona Chalamanda', branchName: 'Lilongwe Plaza Branch', amountDisbursed: 3500, expectedRepayment: 4130, actualRepayment: 0, interestRate: 18, expenses: 190, status: 'Default', uploadedBy: 'marcus@microfinance.co.mw' },
  { id: 'rec-205', date: '2026-05-15', borrowerName: 'Geoffrey Manda', branchName: 'Lilongwe Plaza Branch', amountDisbursed: 4000, expectedRepayment: 4720, actualRepayment: 4720, interestRate: 18, expenses: 210, status: 'On Time', uploadedBy: 'marcus@microfinance.co.mw' },

  // Zomba records
  { id: 'rec-301', date: '2026-05-02', borrowerName: 'Tiyelekeze Chidothi', branchName: 'Zomba District Desk', amountDisbursed: 800, expectedRepayment: 920, actualRepayment: 920, interestRate: 15, expenses: 40, status: 'On Time', uploadedBy: 'chisomotembo842@gmail.com' },
  { id: 'rec-302', date: '2026-05-05', borrowerName: 'Patuma Hassan', branchName: 'Zomba District Desk', amountDisbursed: 1300, expectedRepayment: 1495, actualRepayment: 1495, interestRate: 15, expenses: 65, status: 'On Time', uploadedBy: 'chisomotembo842@gmail.com' },
  { id: 'rec-303', date: '2026-05-09', borrowerName: 'Esnart Chunga', branchName: 'Zomba District Desk', amountDisbursed: 1800, expectedRepayment: 2070, actualRepayment: 2070, interestRate: 15, expenses: 95, status: 'On Time', uploadedBy: 'chisomotembo842@gmail.com' },
  { id: 'rec-304', date: '2026-05-14', borrowerName: 'Wyson Chimombo', branchName: 'Zomba District Desk', amountDisbursed: 2500, expectedRepayment: 2875, actualRepayment: 1000, interestRate: 15, expenses: 130, status: 'Delayed', uploadedBy: 'chisomotembo842@gmail.com' },

  // Mzuzu records (Fresh operational)
  { id: 'rec-401', date: '2026-05-10', borrowerName: 'Robert Mkandawire', branchName: 'Mzuzu Northern Station', amountDisbursed: 1500, expectedRepayment: 1740, actualRepayment: 1740, interestRate: 16, expenses: 120, status: 'On Time', uploadedBy: 'mchagunda@microfinance.co.mw' },
  { id: 'rec-402', date: '2026-05-15', borrowerName: 'Kondwani Msonda', branchName: 'Mzuzu Northern Station', amountDisbursed: 2800, expectedRepayment: 3248, actualRepayment: 0, interestRate: 16, expenses: 240, status: 'Default', uploadedBy: 'mchagunda@microfinance.co.mw' },
];

// Seeded tasks assigned to employees
export const INITIAL_TASKS: Task[] = [
  {
    id: 'tsk-1',
    title: 'Audit default accounts in Lilongwe Plaza',
    description: 'Verify why the rural agricultural crop loans logged inside the May journal have defaulted. Formulate physical audit notices.',
    assignedToEmail: 'marcus@microfinance.co.mw',
    assignedToName: 'Marcus Aurelius',
    assignedBy: 'mchagunda@microfinance.co.mw',
    status: 'In Progress',
    progress: 45,
    dueDate: '2026-05-28',
    createdDate: '2026-05-20',
    activityLog: [
      { timestamp: '2026-05-20T09:00:00Z', note: 'Task was registered and assigned.', author: 'MCHAGUNDA' },
      { timestamp: '2026-05-21T14:30:00Z', note: 'Marcus started contacting loanees. Three reported delays due to pest infestation.', author: 'Marcus Aurelius' }
    ]
  },
  {
    id: 'tsk-2',
    title: 'Upload Q2 Repayment excel sheet links',
    description: 'Establish Google Sheets connection for the upcoming quarterly evaluation of Zomba desk operations',
    assignedToEmail: 'chisomotembo842@gmail.com',
    assignedToName: 'Chisomo Tembo',
    assignedBy: 'mchagunda@microfinance.co.mw',
    status: 'Pending',
    progress: 0,
    dueDate: '2026-05-25',
    createdDate: '2026-05-23',
    activityLog: [
      { timestamp: '2026-05-23T08:00:00Z', note: 'Task of connected sheet delivery was initiated.', author: 'MCHAGUNDA' }
    ]
  },
  {
    id: 'tsk-3',
    title: 'Review Blantyre Central ledger overhead costs',
    description: 'Operational expenses rose by 14% this month. Submit detailed invoice breakdown.',
    assignedToEmail: 'sarah@microfinance.co.mw',
    assignedToName: 'Sarah Jenkins',
    assignedBy: 'mchagunda@microfinance.co.mw',
    status: 'Completed',
    progress: 100,
    dueDate: '2026-05-22',
    createdDate: '2026-05-18',
    activityLog: [
      { timestamp: '2026-05-18T10:00:00Z', note: 'Overhead investigation tasked.', author: 'MCHAGUNDA' },
      { timestamp: '2026-05-21T16:00:00Z', note: 'Submitted compiled digital expense audits via dashboard attachment.', author: 'Sarah Jenkins' }
    ]
  }
];

// Seeded Alerts (automated warning metrics triggers)
export const INITIAL_ALERTS: AlertNotification[] = [
  {
    id: 'alt-1',
    title: 'High Cumulative Default warning',
    description: 'Kondwani Msonda (Mzuzu) defaulted on rural microloan MWK 2,800. Net exposure represents >10% of Mzuzu capital.',
    type: 'default',
    severity: 'Critical',
    timestamp: '2026-05-22 15:40',
    isRead: false,
    branchName: 'Mzuzu Northern Station'
  },
  {
    id: 'alt-2',
    title: 'Overhead cost limits overflow',
    description: 'Mzuzu station recorded operating expenses of MWK 360 on interest income of MWK 0 in early disbursements. Negative operational leverage.',
    type: 'expense',
    severity: 'Warning',
    timestamp: '2026-05-21 11:15',
    isRead: false,
    branchName: 'Mzuzu Northern Station'
  },
  {
    id: 'alt-3',
    title: 'Google Sheet Linked and synced',
    description: 'Sarah Jenkins successfully linked a live Google Spreadsheets file: Blantyre Disbursements Journal Q1.',
    type: 'system',
    severity: 'Info',
    timestamp: '2026-05-23 08:30',
    isRead: true,
    branchName: 'Blantyre Central Branch'
  }
];

// Initial preseeded chat logs for internal communication
export const INITIAL_COMMUNICATIONS: CommunicationMessage[] = [
  {
    id: 'msg-1',
    senderEmail: 'mchagunda@microfinance.co.mw',
    senderName: 'MCHAGUNDA',
    recipientEmail: 'All',
    recipientName: 'All Staff Office',
    message: 'Welcome everyone to the Pacific Finance LTD central tracking dashboard. All staff are logged in terms of their physical branches. Please paste public link of sheets log for daily evaluation.',
    timestamp: '2026-05-23T08:00:00Z'
  },
  {
    id: 'msg-2',
    senderEmail: 'chisomotembo842@gmail.com',
    senderName: 'Chisomo Tembo',
    recipientEmail: 'mchagunda@microfinance.co.mw',
    recipientName: 'MCHAGUNDA',
    message: 'Greetings Executive Director! I am registering the new Zomba rural market ledger database details. Will paste sheet link shortly.',
    timestamp: '2026-05-23T08:10:00Z'
  },
  {
    id: 'msg-3',
    senderEmail: 'mchagunda@microfinance.co.mw',
    senderName: 'MCHAGUNDA',
    recipientEmail: 'chisomotembo842@gmail.com',
    recipientName: 'Chisomo Tembo',
    message: 'Understood Chisomo, please keep tracking the repayment performance in Zomba carefully. The micro-finance market is quite tight there.',
    timestamp: '2026-05-23T08:15:00Z'
  }
];

// Default initial audit tracker (Security and Compliance auditing logs)
export const INITIAL_AUDITS: AuditLog[] = [
  { id: 'aud-1', userEmail: 'mchagunda@microfinance.co.mw', userName: 'MCHAGUNDA', action: 'System Setup and Admin seed configuration verified', timestamp: '2026-05-23T07:15:00Z', ipAddress: '197.221.32.4' },
  { id: 'aud-2', userEmail: 'chisomotembo842@gmail.com', userName: 'Chisomo Tembo', action: 'Branch login from Zomba District Desk validated', timestamp: '2026-05-23T08:05:00Z', ipAddress: '197.221.40.12' },
  { id: 'aud-3', userEmail: 'sarah@microfinance.co.mw', userName: 'Sarah Jenkins', action: 'Google Spreadsheet file URL s-1 synced successfully', timestamp: '2026-05-23T08:30:00Z', ipAddress: '197.221.32.14' }
];
